<?php 
session_start(); 
require_once '../config/config.php'; 
require_once '../includes/functions.php'; 
require_once __DIR__ . '/../vendor/autoload.php';
require_once __DIR__ . '/../config/email_config.php';

// Redirect if already logged in 
if (isset($_SESSION['user_id'])) { 
    header("Location: ../index.php"); 
    exit(); 
} 

$error = ''; 
$success = ''; 

// Get referral ID from URL if present 
$referralId = $_GET['ref'] ?? ''; 

if ($_SERVER['REQUEST_METHOD'] === 'POST') { 
    $username = $_POST['username'] ?? ''; 
    $firstName = $_POST['firstname'] ?? ''; 
    $lastName = $_POST['lastname'] ?? ''; 
    $email = $_POST['email'] ?? ''; 
    $phone = $_POST['phone'] ?? ''; 
    $password = $_POST['password'] ?? ''; 
    $confirmPassword = $_POST['confirm_password'] ?? ''; 
    $country = $_POST['country'] ?? ''; 
    $referralId = $_POST['referral_id'] ?? ''; 
    $termsAccepted = isset($_POST['terms_accepted']) ? true : false; 
    
    // Validate input 
    if (empty($username) || empty($firstName) || empty($lastName) || empty($email) || empty($phone) || empty($password) || empty($confirmPassword) || empty($country)) { 
        $error = "All required fields must be filled"; 
    } elseif ($password !== $confirmPassword) { 
        $error = "Passwords do not match"; 
    } elseif (strlen($password) < 8) { 
        $error = "Password must be at least 8 characters long"; 
    } elseif (!$termsAccepted) { 
        $error = "You must accept the Terms and Privacy Policy"; 
    } else { 
        // Check if username already exists 
        $stmt = $conn->prepare("SELECT * FROM users WHERE username = ?"); 
        $stmt->bind_param("s", $username); 
        $stmt->execute(); 
        $result = $stmt->get_result(); 
        
        if ($result->num_rows > 0) { 
            $error = "Username already exists"; 
        } else { 
            // Check if email already exists 
            $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?"); 
            $stmt->bind_param("s", $email); 
            $stmt->execute(); 
            $result = $stmt->get_result(); 
            
            if ($result->num_rows > 0) { 
                $error = "Email already exists"; 
            } else { 
                // Hash password 
                $hashedPassword = password_hash($password, PASSWORD_DEFAULT); 
                
                // Generate verification token 
                $verificationToken = bin2hex(random_bytes(32)); 
                
                // Get referrer ID if referral code is provided 
                $referrerId = null; 
                if (!empty($referralId)) { 
                    $stmt = $conn->prepare("SELECT id FROM users WHERE referral_code = ?"); 
                    $stmt->bind_param("s", $referralId); 
                    $stmt->execute(); 
                    $result = $stmt->get_result(); 
                    if ($result->num_rows > 0) { 
                        $referrer = $result->fetch_assoc(); 
                        $referrerId = $referrer['id']; 
                    } 
                } 
                
                // Generate unique referral code for new user 
                $newReferralCode = generateReferralCode(); 
                
                // Insert user (updated to match your table structure)
                $stmt = $conn->prepare("INSERT INTO users (username, first_name, last_name, email, phone, password, country, referred_by, referral_code, verification_token, role, status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'user', 'active', NOW())");
                $stmt->bind_param("ssssssisss", $username, $firstName, $lastName, $email, $phone, $hashedPassword, $country, $referrerId, $newReferralCode, $verificationToken);


                if ($stmt->execute()) { 
                
                // Send verification email using SwiftMailer
                require_once '../vendor/autoload.php'; // Adjust path if needed
                
                $verificationLink = APP_URL . "/auth/verify_email.php?token=" . $verificationToken;
                $subject = "Verify Your Email Address - " . APP_NAME;
                $message = "
                    <html>
                    <head>
                        <title>Email Verification</title>
                    </head>
                    <body>
                        <h2>Welcome to " . APP_NAME . "!</h2>
                        <p>Thank you for registering. Please click the link below to verify your email address:</p>
                        <p><a href='" . $verificationLink . "'>Verify Email Address</a></p>
                        <p>If you did not create an account, no further action is required.</p>
                        <p>Regards,<br>" . APP_NAME . " Team</p>
                    </body>
                    </html>
                ";
                
                // Configure SwiftMailer transport
                $transport = (new Swift_SmtpTransport('mail.jetfxgrowth.online', 587, 'tls'))
                    ->setUsername('authenticate@jetfxgrowth.online')
                    ->setPassword('yE8kNd?qhzVQ');
                
                // Create the Mailer using your created Transport
                $mailer = new Swift_Mailer($transport);
                
                // Create a message
                $emailMessage = (new Swift_Message($subject))
                    ->setFrom(['authenticate@jetfxgrowth.online' => APP_NAME])
                    ->setTo([$email])
                    ->setBody($message, 'text/html');
                
                // Send the message
                try {
                    $result = $mailer->send($emailMessage);
                    if ($result > 0) {
                        $success = "Registration successful! Please check your email to verify your account.";
                    } else {
                        $error = "Registration successful but failed to send verification email. Please contact support.";
                    }
                } catch (Exception $e) {
                    $error = "Registration successful but failed to send verification email. Please contact support.";
                }
                // ... existing code ...
                            
                    try {
                        $transport = (new Swift_SmtpTransport(SMTP_HOST, SMTP_PORT, SMTP_ENCRYPTION))
                            ->setUsername(SMTP_USERNAME)
                            ->setPassword(SMTP_PASSWORD);
                    
                        $mailer = new Swift_Mailer($transport);
                    
                        $emailMessage = (new Swift_Message($subject))
                            ->setFrom([MAIL_FROM_ADDRESS => MAIL_FROM_NAME])
                            ->setTo([$email])
                            ->setBody($message, 'text/html');
                    
                        $result = $mailer->send($emailMessage);
                    
                        if ($result > 0) {
                            $success = "Registration successful! Please check your email to verify your account.";
                        } else {
                            $error = "Registration successful but failed to send verification email. Please contact support.";
                        }
                    } catch (Exception $e) {
                        $error = "Registration successful but failed to send verification email. Please contact support.";
                        error_log("SwiftMailer error: " . $e->getMessage());
                    }
                }
            } 
        } 
    } 
} 

// Get countries list 
$countries = [ 
    'US' => 'United States', 
    'GB' => 'United Kingdom', 
    'CA' => 'Canada', 
    'AU' => 'Australia', 
    'DE' => 'Germany', 
    'FR' => 'France', 
    'IT' => 'Italy', 
    'ES' => 'Spain', 
    'JP' => 'Japan', 
    'CN' => 'China', 
    'IN' => 'India', 
    'BR' => 'Brazil', 
    'ZA' => 'South Africa', 
    'NG' => 'Nigeria', 
    'KE' => 'Kenya', 
    'GH' => 'Ghana', 
    // Add more countries as needed 
]; 
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - <?php echo APP_NAME; ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/auth.css">
</head>
<body>
    <div class="container">
        <div class="row justify-content-center align-items-center py-5">
            <div class="col-md-6">
                <div class="auth-card">
                    <div class="text-center mb-4">
                        <h2 class="auth-title">Create an Account</h2>
                    </div>
                    
                    <?php if (!empty($error)): ?>
                        <div class="alert alert-danger"><?php echo $error; ?></div>
                    <?php endif; ?>
                    
                    <?php if (!empty($success)): ?>
                        <div class="alert alert-success"><?php echo $success; ?></div>
                    <?php endif; ?>
                    
                    <form method="POST" action="">
    <div class="mb-3">
        <label for="username" class="form-label">Username <span class="text-danger">*</span></label>
        <div class="input-group">
            <span class="input-group-text"><i class="fas fa-user"></i></span>
            <input type="text" class="form-control" id="username" name="username" placeholder="Enter Unique Username" required>
        </div>
    </div>

    <div class="mb-3">
        <label for="firstname" class="form-label">First Name <span class="text-danger">*</span></label>
        <div class="input-group">
            <span class="input-group-text"><i class="fas fa-user"></i></span>
            <input type="text" class="form-control" id="firstname" name="firstname" placeholder="Enter First Name" required>
        </div>
    </div>

    <div class="mb-3">
        <label for="lastname" class="form-label">Last Name <span class="text-danger">*</span></label>
        <div class="input-group">
            <span class="input-group-text"><i class="fas fa-user"></i></span>
            <input type="text" class="form-control" id="lastname" name="lastname" placeholder="Enter Last Name" required>
        </div>
    </div>

    <div class="mb-3">
        <label for="email" class="form-label">Your Email <span class="text-danger">*</span></label>
        <div class="input-group">
            <span class="input-group-text"><i class="fas fa-envelope"></i></span>
            <input type="email" class="form-control" id="email" name="email" placeholder="name@example.com" required>
        </div>
    </div>

    <div class="mb-3">
        <label for="phone" class="form-label">Phone Number <span class="text-danger">*</span></label>
        <div class="input-group">
            <span class="input-group-text"><i class="fas fa-phone"></i></span>
            <input type="text" class="form-control" id="phone" name="phone" placeholder="Enter Phone number" required>
        </div>
    </div>

    <div class="mb-3">
        <label for="password" class="form-label">Password <span class="text-danger">*</span></label>
        <div class="input-group">
            <span class="input-group-text"><i class="fas fa-lock"></i></span>
            <input type="password" class="form-control" id="password" name="password" placeholder="••••••••" required>
        </div>
    </div>

    <div class="mb-3">
        <label for="confirm_password" class="form-label">Confirm Password <span class="text-danger">*</span></label>
        <div class="input-group">
            <span class="input-group-text"><i class="fas fa-lock"></i></span>
            <input type="password" class="form-control" id="confirm_password" name="confirm_password" placeholder="Confirm Password" required>
        </div>
    </div>

    <div class="mb-3">
        <label for="country" class="form-label">Country <span class="text-danger">*</span></label>
        <div class="input-group">
            <span class="input-group-text"><i class="fas fa-globe"></i></span>
            <select class="form-select" id="country" name="country" required>
                <option value="">Choose Country</option>
                <?php foreach ($countries as $code => $name): ?>
                    <option value="<?php echo $code; ?>"><?php echo $name; ?></option>
                <?php endforeach; ?>
            </select>
        </div>
    </div>

    <div class="mb-3">
        <label for="referral_id" class="form-label">Referral ID</label>
        <div class="input-group">
            <span class="input-group-text"><i class="fas fa-user-plus"></i></span>
            <input type="text" class="form-control" id="referral_id" name="referral_id" placeholder="optional referral id" value="<?php echo htmlspecialchars($referralId); ?>">
        </div>
    </div>

    <div class="mb-4">
        <div class="form-check">
            <input class="form-check-input" type="checkbox" id="terms_accepted" name="terms_accepted" required>
            <label class="form-check-label" for="terms_accepted">
                I Accept the <a href="../terms.php" class="text-decoration-none">Terms</a> And <a href="../privacy.php" class="text-decoration-none">Privacy Policy</a>
            </label>
        </div>
    </div>

    <div class="d-grid">
        <button type="submit" class="btn btn-primary">Register</button>
    </div>
</form>
                    
                    <div class="text-center">
                        <p>Already have an account? <a href="login.php" class="text-decoration-none">Sign In</a></p>
                    </div>
                    
                    <div class="text-center mt-4">
                        <p class="small text-muted">© Copyright 2025 JetFx Growth All Rights Reserved.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Password match validation
        document.getElementById('confirm_password').addEventListener('input', function() {
            const password = document.getElementById('password').value;
            const confirmPassword = this.value;
            
            if (password !== confirmPassword) {
                this.setCustomValidity('Passwords do not match');
            } else {
                this.setCustomValidity('');
            }
        });
    </script>
</body>
</html>
