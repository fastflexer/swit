<?php
session_start();
require_once '../config/config.php';
require_once '../includes/functions.php';
require_once '../includes/auth_check.php';

// Get user information
$user = getUserById($_SESSION['user_id']);

// Get user's trades
$stmt = $conn->prepare("SELECT * FROM trades WHERE user_id = ? ORDER BY created_at DESC");
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$result = $stmt->get_result();

$trades = [];
while ($row = $result->fetch_assoc()) {
    $trades[] = $row;
}

// Get user's copy trades
$stmt = $conn->prepare("SELECT uct.*, t.name as trader_name FROM user_copy_trades uct JOIN traders t ON uct.trader_id = t.id WHERE uct.user_id = ? ORDER BY uct.created_at DESC");
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$result = $stmt->get_result();

$copyTrades = [];
while ($row = $result->fetch_assoc()) {
    $copyTrades[] = $row;
}

// Calculate trade statistics
$totalTrades = count($trades) + count($copyTrades);
$winTrades = 0;
$lossTrades = 0;
$totalProfit = 0;
$totalLoss = 0;

foreach ($trades as $trade) {
    if ($trade['result'] === 'win') {
        $winTrades++;
        $totalProfit += $trade['profit'];
    } elseif ($trade['result'] === 'loss') {
        $lossTrades++;
        $totalLoss += $trade['loss'];
    }
}

foreach ($copyTrades as $trade) {
    if ($trade['result'] === 'win') {
        $winTrades++;
        $totalProfit += $trade['profit'];
    } elseif ($trade['result'] === 'loss') {
        $lossTrades++;
        $totalLoss += $trade['loss'];
    }
}

$winRate = $totalTrades > 0 ? ($winTrades / $totalTrades) * 100 : 0;
$netProfitLoss = $totalProfit - $totalLoss;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Trades - <?php echo APP_NAME; ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/dashboard.css">
</head>
<body>
    <div class="dashboard-container">
        <?php include '../includes/sidebar.php'; ?>
        
        <div class="dashboard-content">
            <?php include '../includes/header.php'; ?>
            
            <div class="container mt-4">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card mb-4">
                            <div class="card-header">
                                <h5 class="card-title">Trade Statistics</h5>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-3">
                                        <div class="stat-card">
                                            <div class="stat-card-body">
                                                <div class="stat-card-icon bg-primary">
                                                    <i class="fas fa-chart-line"></i>
                                                </div>
                                                <div class="stat-card-info">
                                                    <p class="stat-card-title">Total Trades</p>
                                                    <p class="stat-card-value"><?php echo $totalTrades; ?></p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="stat-card">
                                            <div class="stat-card-body">
                                                <div class="stat-card-icon bg-success">
                                                    <i class="fas fa-trophy"></i>
                                                </div>
                                                <div class="stat-card-info">
                                                    <p class="stat-card-title">Win Rate</p>
                                                    <p class="stat-card-value"><?php echo number_format($winRate, 2); ?>%</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="stat-card">
                                            <div class="stat-card-body">
                                                <div class="stat-card-icon bg-info">
                                                    <i class="fas fa-dollar-sign"></i>
                                                </div>
                                                <div class="stat-card-info">
                                                    <p class="stat-card-title">Total Profit</p>
                                                    <p class="stat-card-value"><?php echo formatCurrency($totalProfit); ?></p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="stat-card">
                                            <div class="stat-card-body">
                                                <div class="stat-card-icon <?php echo $netProfitLoss >= 0 ? 'bg-success' : 'bg-danger'; ?>">
                                                    <i class="fas fa-balance-scale"></i>
                                                </div>
                                                <div class="stat-card-info">
                                                    <p class="stat-card-title">Net P/L</p>
                                                    <p class="stat-card-value"><?php echo formatCurrency($netProfitLoss); ?></p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <ul class="nav nav-tabs mb-4" id="tradesTab" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="my-trades-tab" data-bs-toggle="tab" data-bs-target="#my-trades" type="button" role="tab" aria-controls="my-trades" aria-selected="true">My Trades</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="copy-trades-tab" data-bs-toggle="tab" data-bs-target="#copy-trades" type="button" role="tab" aria-controls="copy-trades" aria-selected="false">Copy Trades</button>
                    </li>
                </ul>
                
                <div class="tab-content" id="tradesTabContent">
                    <div class="tab-pane fade show active" id="my-trades" role="tabpanel" aria-labelledby="my-trades-tab">
                        <div class="card">
                            <div class="card-header d-flex justify-content-between align-items-center">
                                <h5 class="card-title mb-0">My Trades</h5>
                            </div>
                            <div class="card-body">
                                <?php if (empty($trades)): ?>
                                    <p class="text-center">No trades found.</p>
                                <?php else: ?>
                                    <div class="table-responsive">
                                        <table class="table table-striped table-hover">
                                            <thead>
                                                <tr>
                                                    <th>ID</th>
                                                    <th>Symbol</th>
                                                    <th>Type</th>
                                                    <th>Entry Price</th>
                                                    <th>Exit Price</th>
                                                    <th>Volume</th>
                                                    <th>Result</th>
                                                    <th>Profit/Loss</th>
                                                    <th>Open Time</th>
                                                    <th>Close Time</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php foreach ($trades as $trade): ?>
                                                    <tr>
                                                        <td><?php echo $trade['id']; ?></td>
                                                        <td><?php echo $trade['symbol']; ?></td>
                                                        <td><?php echo strtoupper($trade['type']); ?></td>
                                                        <td><?php echo $trade['entry_price']; ?></td>
                                                        <td><?php echo $trade['exit_price'] ?: '-'; ?></td>
                                                        <td><?php echo $trade['volume']; ?></td>
                                                        <td>
                                                            <?php if ($trade['status'] === 'open'): ?>
                                                                <span class="badge bg-warning">Open</span>
                                                            <?php elseif ($trade['result'] === 'win'): ?>
                                                                <span class="badge bg-success">Win</span>
                                                            <?php elseif ($trade['result'] === 'loss'): ?>
                                                                <span class="badge bg-danger">Loss</span>
                                                            <?php endif; ?>
                                                        </td>
                                                        <td>
                                                            <?php if ($trade['status'] === 'open'): ?>
                                                                -
                                                            <?php elseif ($trade['result'] === 'win'): ?>
                                                                <span class="text-success">+<?php echo formatCurrency($trade['profit']); ?></span>
                                                            <?php elseif ($trade['result'] === 'loss'): ?>
                                                                <span class="text-danger">-<?php echo formatCurrency($trade['loss']); ?></span>
                                                            <?php endif; ?>
                                                        </td>
                                                        <td><?php echo date('M d, Y H:i', strtotime($trade['open_time'])); ?></td>
                                                        <td>
                                                            <?php echo $trade['close_time'] ? date('M d, Y H:i', strtotime($trade['close_time'])) : '-'; ?>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    
                    <div class="tab-pane fade" id="copy-trades" role="tabpanel" aria-labelledby="copy-trades-tab">
                        <div class="card">
                            <div class="card-header d-flex justify-content-between align-items-center">
                                <h5 class="card-title mb-0">Copy Trades</h5>
                                <a href="copy_traders.php" class="btn btn-sm btn-primary">Copy New Trader</a>
                            </div>
                            <div class="card-body">
                                <?php if (empty($copyTrades)): ?>
                                    <p class="text-center">No copy trades found. Start copying traders to see their trades here.</p>
                                <?php else: ?>
                                    <div class="table-responsive">
                                        <table class="table table-striped table-hover">
                                            <thead>
                                                <tr>
                                                    <th>ID</th>
                                                    <th>Trader</th>
                                                    <th>Symbol</th>
                                                    <th>Type</th>
                                                    <th>Entry Price</th>
                                                    <th>Exit Price</th>
                                                    <th>Volume</th>
                                                    <th>Result</th>
                                                    <th>Profit/Loss</th>
                                                    <th>Open Time</th>
                                                    <th>Close Time</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php foreach ($copyTrades as $trade): ?>
                                                    <tr>
                                                        <td><?php echo $trade['id']; ?></td>
                                                        <td><?php echo $trade['trader_name']; ?></td>
                                                        <td><?php echo $trade['symbol']; ?></td>
                                                        <td><?php echo strtoupper($trade['type']); ?></td>
                                                        <td><?php echo $trade['entry_price']; ?></td>
                                                        <td><?php echo $trade['exit_price'] ?: '-'; ?></td>
                                                        <td><?php echo $trade['volume']; ?></td>
                                                        <td>
                                                            <?php if ($trade['status'] === 'open'): ?>
                                                                <span class="badge bg-warning">Open</span>
                                                            <?php elseif ($trade['result'] === 'win'): ?>
                                                                <span class="badge bg-success">Win</span>
                                                            <?php elseif ($trade['result'] === 'loss'): ?>
                                                                <span class="badge bg-danger">Loss</span>
                                                            <?php endif; ?>
                                                        </td>
                                                        <td>
                                                            <?php if ($trade['status'] === 'open'): ?>
                                                                -
                                                            <?php elseif ($trade['result'] === 'win'): ?>
                                                                <span class="text-success">+<?php echo formatCurrency($trade['profit']); ?></span>
                                                            <?php elseif ($trade['result'] === 'loss'): ?>
                                                                <span class="text-danger">-<?php echo formatCurrency($trade['loss']); ?></span>
                                                            <?php endif; ?>
                                                        </td>
                                                        <td><?php echo date('M d, Y H:i', strtotime($trade['open_time'])); ?></td>
                                                        <td>
                                                            <?php echo $trade['close_time'] ? date('M d, Y H:i', strtotime($trade['close_time'])) : '-'; ?>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/dashboard.js"></script>
</body>
</html>
