<?php
session_start();
require_once '../config/config.php';
require_once '../includes/auth_check.php';
require_once '../includes/functions.php';

// Check if user is admin
requireAdmin();
requireOTPVerification();

// Get all loan plans
$loanPlans = getAllLoanPlans();

// Process messages
$message = '';
$messageType = '';

if (isset($_SESSION['plan_message'])) {
    $message = $_SESSION['plan_message'];
    $messageType = $_SESSION['plan_message_type'] ?? 'success';
    unset($_SESSION['plan_message']);
    unset($_SESSION['plan_message_type']);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Loan Plans - <?php echo APP_NAME; ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <?php include 'includes/sidebar.php'; ?>
            
            <!-- Main Content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Loan Plans</h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <button type="button" class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#addLoanPlanModal">
                            <i class="fas fa-plus-circle"></i> Add New Plan
                        </button>
                    </div>
                </div>
                
                <?php if (!empty($message)): ?>
                <div class="alert alert-<?php echo $messageType; ?> alert-dismissible fade show" role="alert">
                    <?php echo $message; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <?php endif; ?>
                
                <!-- Loan Plans Table -->
                <div class="card">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Name</th>
                                        <th>Amount Range</th>
                                        <th>Interest Rate</th>
                                        <th>Duration</th>
                                        <th>Processing Fee</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (empty($loanPlans)): ?>
                                    <tr>
                                        <td colspan="8" class="text-center">No loan plans found</td>
                                    </tr>
                                    <?php else: ?>
                                    <?php foreach ($loanPlans as $plan): ?>
                                    <tr>
                                        <td><?php echo $plan['id']; ?></td>
                                        <td><?php echo $plan['name']; ?></td>
                                        <td>$<?php echo number_format($plan['min_amount'], 2); ?> - $<?php echo number_format($plan['max_amount'], 2); ?></td>
                                        <td><?php echo $plan['interest_rate']; ?>%</td>
                                        <td><?php echo $plan['duration']; ?> days</td>
                                        <td><?php echo $plan['processing_fee']; ?>%</td>
                                        <td>
                                            <span class="badge bg-<?php echo $plan['status'] === 'active' ? 'success' : 'danger'; ?>">
                                                <?php echo ucfirst($plan['status']); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <button type="button" class="btn btn-sm btn-primary edit-plan-btn" data-bs-toggle="modal" data-bs-target="#editLoanPlanModal" 
                                                data-id="<?php echo $plan['id']; ?>"
                                                data-name="<?php echo $plan['name']; ?>"
                                                data-min="<?php echo $plan['min_amount']; ?>"
                                                data-max="<?php echo $plan['max_amount']; ?>"
                                                data-interest="<?php echo $plan['interest_rate']; ?>"
                                                data-duration="<?php echo $plan['duration']; ?>"
                                                data-fee="<?php echo $plan['processing_fee']; ?>"
                                                data-status="<?php echo $plan['status']; ?>">
                                                <i class="fas fa-edit"></i>
                                            </button>
                                            <a href="delete_loan_plan.php?id=<?php echo $plan['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this loan plan?')">
                                                <i class="fas fa-trash"></i>
                                            </a>
                                            <?php if ($plan['status'] === 'active'): ?>
                                            <a href="toggle_loan_plan.php?id=<?php echo $plan['id']; ?>&status=inactive" class="btn btn-sm btn-warning" onclick="return confirm('Are you sure you want to deactivate this loan plan?')">
                                                <i class="fas fa-ban"></i>
                                            </a>
                                            <?php else: ?>
                                            <a href="toggle_loan_plan.php?id=<?php echo $plan['id']; ?>&status=active" class="btn btn-sm btn-success" onclick="return confirm('Are you sure you want to activate this loan plan?')">
                                                <i class="fas fa-check"></i>
                                            </a>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>
    
    <!-- Add Loan Plan Modal -->
    <div class="modal fade" id="addLoanPlanModal" tabindex="-1" aria-labelledby="addLoanPlanModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addLoanPlanModalLabel">Add New Loan Plan</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="add_loan_plan.php" method="post">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="name" class="form-label">Plan Name</label>
                            <input type="text" class="form-control" id="name" name="name" required>
                        </div>
                        
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="min_amount" class="form-label">Minimum Amount</label>
                                <div class="input-group">
                                    <span class="input-group-text">$</span>
                                    <input type="number" class="form-control" id="min_amount" name="min_amount" min="1" step="0.01" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <label for="max_amount" class="form-label">Maximum Amount</label>
                                <div class="input-group">
                                    <span class="input-group-text">$</span>
                                    <input type="number" class="form-control" id="max_amount" name="max_amount" min="1" step="0.01" required>
                                </div>
                            </div>
                        </div>
                        
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="interest_rate" class="form-label">Interest Rate</label>
                                <div class="input-group">
                                    <input type="number" class="form-control" id="interest_rate" name="interest_rate" min="0" step="0.01" required>
                                    <span class="input-group-text">%</span>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <label for="processing_fee" class="form-label">Processing Fee</label>
                                <div class="input-group">
                                    <input type="number" class="form-control" id="processing_fee" name="processing_fee" min="0" step="0.01" required>
                                    <span class="input-group-text">%</span>
                                </div>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="duration" class="form-label">Duration (Days)</label>
                            <input type="number" class="form-control" id="duration" name="duration" min="1" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="status" class="form-label">Status</label>
                            <select class="form-select" id="status" name="status" required>
                                <option value="active">Active</option>
                                <option value="inactive">Inactive</option>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Add Plan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Edit Loan Plan Modal -->
    <div class="modal fade" id="editLoanPlanModal" tabindex="-1" aria-labelledby="editLoanPlanModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editLoanPlanModalLabel">Edit Loan Plan</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="update_loan_plan.php" method="post">
                    <input type="hidden" id="edit_id" name="id">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="edit_name" class="form-label">Plan Name</label>
                            <input type="text" class="form-control" id="edit_name" name="name" required>
                        </div>
                        
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="edit_min_amount" class="form-label">Minimum Amount</label>
                                <div class="input-group">
                                    <span class="input-group-text">$</span>
                                    <input type="number" class="form-control" id="edit_min_amount" name="min_amount" min="1" step="0.01" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <label for="edit_max_amount" class="form-label">Maximum Amount</label>
                                <div class="input-group">
                                    <span class="input-group-text">$</span>
                                    <input type="number" class="form-control" id="edit_max_amount" name="max_amount" min="1" step="0.01" required>
                                </div>
                            </div>
                        </div>
                        
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="edit_interest_rate" class="form-label">Interest Rate</label>
                                <div class="input-group">
                                    <input type="number" class="form-control" id="edit_interest_rate" name="interest_rate" min="0" step="0.01" required>
                                    <span class="input-group-text">%</span>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <label for="edit_processing_fee" class="form-label">Processing Fee</label>
                                <div class="input-group">
                                    <input type="number" class="form-control" id="edit_processing_fee" name="processing_fee" min="0" step="0.01" required>
                                    <span class="input-group-text">%</span>
                                </div>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="edit_duration" class="form-label">Duration (Days)</label>
                            <input type="number" class="form-control" id="edit_duration" name="duration" min="1" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="edit_status" class="form-label">Status</label>
                            <select class="form-select" id="edit_status" name="status" required>
                                <option value="active">Active</option>
                                <option value="inactive">Inactive</option>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Update Plan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Handle edit loan plan button click
        document.querySelectorAll('.edit-plan-btn').forEach(button => {
            button.addEventListener('click', function() {
                const id = this.getAttribute('data-id');
                const name = this.getAttribute('data-name');
                const minAmount = this.getAttribute('data-min');
                const maxAmount = this.getAttribute('data-max');
                const interestRate = this.getAttribute('data-interest');
                const duration = this.getAttribute('data-duration');
                const processingFee = this.getAttribute('data-fee');
                const status = this.getAttribute('data-status');
                
                document.getElementById('edit_id').value = id;
                document.getElementById('edit_name').value = name;
                document.getElementById('edit_min_amount').value = minAmount;
                document.getElementById('edit_max_amount').value = maxAmount;
                document.getElementById('edit_interest_rate').value = interestRate;
                document.getElementById('edit_duration').value = duration;
                document.getElementById('edit_processing_fee').value = processingFee;
                document.getElementById('edit_status').value = status;
            });
        });
    </script>
</body>
</html>
