<?php
session_start();
require_once '../config/config.php';
require_once '../includes/auth_check.php';
require_once '../includes/functions.php';

// Check if user is admin
requireAdmin();
requireOTPVerification();

// Check if payment ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    $_SESSION['loan_detail_message'] = "Invalid payment ID.";
    $_SESSION['loan_detail_message_type'] = "danger";
    header("Location: manage_loans.php");
    exit;
}

$paymentId = intval($_GET['id']);

// Get payment details
$payment = getLoanPaymentById($paymentId);

// Check if payment exists
if (!$payment) {
    $_SESSION['loan_detail_message'] = "Payment not found.";
    $_SESSION['loan_detail_message_type'] = "danger";
    header("Location: manage_loans.php");
    exit;
}

// Get loan details
$loan = getLoanById($payment['loan_id']);

// Check if loan exists
if (!$loan) {
    $_SESSION['loan_detail_message'] = "Loan not found.";
    $_SESSION['loan_detail_message_type'] = "danger";
    header("Location: manage_loans.php");
    exit;
}

// Confirm payment
$result = confirmLoanPayment($paymentId);

if ($result) {
    // Get user details
    $user = getUserById($loan['user_id']);
    
    // Send email notification
    $paymentDetails = [
        'loan_id' => $loan['loan_id'],
        'amount' => $payment['amount'],
        'payment_method' => $payment['payment_method'],
        'transaction_id' => $payment['transaction_id'],
        'created_at' => $payment['created_at']
    ];
    
    sendLoanPaymentConfirmationNotification($user, $paymentDetails);
    
    // Check if loan is fully paid
    $remainingAmount = $loan['total_repayment'] - $loan['amount_paid'];
    if ($remainingAmount <= 0) {
        // Mark loan as paid
        updateLoanStatus($loan['id'], 'paid');
    }
    
    $_SESSION['loan_detail_message'] = "Payment has been confirmed successfully.";
    $_SESSION['loan_detail_message_type'] = "success";
} else {
    $_SESSION['loan_detail_message'] = "Failed to confirm payment. Please try again.";
    $_SESSION['loan_detail_message_type'] = "danger";
}

// Redirect back to loan details page
header("Location: loan_details.php?id=" . $loan['id']);
exit;
?>
