<nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-dark sidebar collapse">
    <div class="position-sticky pt-3">
        <div class="text-center mb-3">
            <h5 class="text-white">JetFx Growth</h5>
        </div>
        <div class="text-center mb-3">
            <span class="badge bg-primary"><?php echo $user['first_name'] . ' ' . $user['last_name']; ?></span>
        </div>
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'active' : ''; ?>" href="dashboard.php">
                    <i class="fas fa-tachometer-alt me-2"></i>
                    Dashboard
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'deposit.php' ? 'active' : ''; ?>" href="deposit.php">
                    <i class="fas fa-money-bill-wave me-2"></i>
                    Deposit
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'withdraw.php' ? 'active' : ''; ?>" href="withdraw.php">
                    <i class="fas fa-money-bill-transfer me-2"></i>
                    Withdraw
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'investments.php' || basename($_SERVER['PHP_SELF']) == 'subscribe.php' ? 'active' : ''; ?>" href="investments.php">
                    <i class="fas fa-chart-line me-2"></i>
                    Investments
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'trading_accounts.php' ? 'active' : ''; ?>" href="trading_accounts.php">
                    <i class="fas fa-wallet me-2"></i>
                    Trading Accounts
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'copy_trade.php' ? 'active' : ''; ?>" href="copy_trade.php">
                    <i class="fas fa-copy me-2"></i>
                    Copy Trade
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'subscribe.php' ? 'active' : ''; ?>" href="subscribe.php">
                    <i class="fas fa-star me-2"></i>
                    Subscribe
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'signals.php' ? 'active' : ''; ?>" href="signals.php">
                    <i class="fas fa-signal me-2"></i>
                    Signals
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'nfts.php' || basename($_SERVER['PHP_SELF']) == 'create_nft.php' || basename($_SERVER['PHP_SELF']) == 'my_nfts.php' || basename($_SERVER['PHP_SELF']) == 'nft_details.php' ? 'active' : ''; ?>" href="nfts.php">
                    <i class="fas fa-image me-2"></i>
                    NFTs
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'loans.php' ? 'active' : ''; ?>" href="loans.php">
                    <i class="fas fa-hand-holding-usd me-2"></i>
                    Loans
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'profile.php' ? 'active' : ''; ?>" href="profile.php">
                    <i class="fas fa-user me-2"></i>
                    Profile
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="../auth/logout.php">
                    <i class="fas fa-sign-out-alt me-2"></i>
                    Logout
                </a>
            </li>
        </ul>
    </div>
</nav>
