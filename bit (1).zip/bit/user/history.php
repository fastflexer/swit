<?php
session_start();
require_once '../config/config.php';
require_once '../includes/auth_check.php';
require_once '../includes/functions.php';

// Check if user is logged in
requireLogin();

// Get user data
$user = getUserById($_SESSION['user_id']);

// Get user's theme preference
$theme = $user['theme'] ?? 'dark';

// Get user's trading history
$stmt = $conn->prepare("SELECT * FROM trading_history WHERE user_id = ? ORDER BY trade_date DESC");
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$result = $stmt->get_result();
$trades = [];
while ($row = $result->fetch_assoc()) {
    $trades[] = $row;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trading History - <?php echo APP_NAME; ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <?php if ($theme === 'dark'): ?>
    <link rel="stylesheet" href="../assets/css/dark-theme.css">
    <?php else: ?>
    <link rel="stylesheet" href="../assets/css/light-theme.css">
    <?php endif; ?>
</head>
<body class="<?php echo $theme; ?>-theme">
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <?php include 'includes/sidebar.php'; ?>
            
            <!-- Main Content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
                <!-- Top Navigation Bar -->
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3">
                    <div class="d-flex align-items-center">
                        <?php if (!empty($user['profile_image'])): ?>
                            <img src="../uploads/profile/<?php echo $user['profile_image']; ?>" alt="Profile" class="rounded-circle me-2" style="width: 40px; height: 40px; object-fit: cover;">
                        <?php else: ?>
                            <div class="rounded-circle bg-secondary text-white d-flex align-items-center justify-content-center me-2" style="width: 40px; height: 40px;">
                                <?php echo strtoupper(substr($user['first_name'], 0, 1)); ?>
                            </div>
                        <?php endif; ?>
                        <div>
                            <h6 class="mb-0"><?php echo $user['first_name'] . ' ' . $user['last_name']; ?></h6>
                            <small class="text-muted"><?php echo $user['email']; ?></small>
                        </div>
                    </div>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <a href="account.php" class="btn btn-sm btn-primary me-2">
                            <i class="fas fa-user-circle"></i> Account
                        </a>
                        <a href="deposit.php" class="btn btn-sm btn-success me-2">
                            <i class="fas fa-money-bill-wave"></i> Make Deposit
                        </a>
                        <a href="withdraw.php" class="btn btn-sm btn-warning me-2">
                            <i class="fas fa-money-bill-transfer"></i> Withdraw Funds
                        </a>
                        <a href="contact.php" class="btn btn-sm btn-info me-2">
                            <i class="fas fa-envelope"></i> Mail Us
                        </a>
                        <a href="settings.php" class="btn btn-sm btn-danger">
                            <i class="fas fa-cog"></i> Settings
                        </a>
                    </div>
                </div>
                
                <!-- Market Ticker -->
                <div class="market-ticker mb-4">
                    <div class="ticker-item">
                        <span class="ticker-symbol">Nasdaq 100:</span>
                        <span class="ticker-value">19,445.4</span>
                        <span class="ticker-change positive">+209.8 (+1.09%)</span>
                    </div>
                    <div class="ticker-item">
                        <span class="ticker-symbol">EUR/USD:</span>
                        <span class="ticker-value">1.13640</span>
                        <span class="ticker-change negative">-0.00220 (-0.19%)</span>
                    </div>
                    <div class="ticker-item">
                        <span class="ticker-symbol">BTC/USD:</span>
                        <span class="ticker-value">93,852</span>
                        <span class="ticker-change negative">-810 (-0.86%)</span>
                    </div>
                    <div class="ticker-item">
                        <span class="ticker-symbol">ETH/USD:</span>
                        <span class="ticker-value">1,901.5</span>
                        <span class="ticker-change positive">+15.5 (+0.82%)</span>
                    </div>
                </div>
                
                <!-- History Content -->
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">HISTORY</h5>
                        <button class="btn btn-sm btn-outline-secondary" id="exportBtn">
                            <i class="fas fa-download"></i> Export
                        </button>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Asset</th>
                                        <th>Amount</th>
                                        <th>Type</th>
                                        <th>Date created</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (empty($trades)): ?>
                                    <tr>
                                        <td colspan="4" class="text-center">No trading history found</td>
                                    </tr>
                                    <?php else: ?>
                                    <?php foreach ($trades as $trade): ?>
                                    <tr>
                                        <td><?php echo $trade['symbol']; ?></td>
                                        <td>$<?php echo number_format($trade['amount'], 2); ?></td>
                                        <td>
                                            <span class="badge bg-<?php echo $trade['trade_type'] === 'buy' ? 'success' : 'danger'; ?>">
                                                <?php echo ucfirst($trade['trade_type']); ?>
                                            </span>
                                        </td>
                                        <td><?php echo date('M j, Y g:i A', strtotime($trade['trade_date'])); ?></td>
                                    </tr>
                                    <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.getElementById('exportBtn').addEventListener('click', function() {
            // Simple export to CSV
            let csv = 'Asset,Amount,Type,Date\n';
            
            const rows = document.querySelectorAll('table tbody tr');
            rows.forEach(row => {
                if (!row.querySelector('td[colspan]')) {
                    const asset = row.cells[0].textContent.trim();
                    const amount = row.cells[1].textContent.trim();
                    const type = row.cells[2].textContent.trim();
                    const date = row.cells[3].textContent.trim();
                    
                    csv += `"${asset}","${amount}","${type}","${date}"\n`;
                }
            });
            
            const blob = new Blob([csv], { type: 'text/csv' });
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.setAttribute('hidden', '');
            a.setAttribute('href', url);
            a.setAttribute('download', 'trading_history.csv');
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
        });
    </script>
</body>
</html>
