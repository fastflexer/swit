<?php
session_start();
require_once '../config/config.php';
require_once '../includes/auth_check.php';
require_once '../includes/functions.php';

// Check if user is admin
requireAdmin();
requireOTPVerification();

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate inputs
    $loanId = isset($_POST['loan_id']) ? intval($_POST['loan_id']) : 0;
    $adminComment = isset($_POST['admin_comment']) ? trim($_POST['admin_comment']) : '';
    
    // Validate required fields
    if (empty($loanId)) {
        $_SESSION['loan_detail_message'] = "Invalid loan ID.";
        $_SESSION['loan_detail_message_type'] = "danger";
        header("Location: manage_loans.php");
        exit;
    }
    
    // Get loan details
    $loan = getLoanById($loanId);
    
    // Check if loan exists
    if (!$loan) {
        $_SESSION['loan_detail_message'] = "Loan not found.";
        $_SESSION['loan_detail_message_type'] = "danger";
        header("Location: manage_loans.php");
        exit;
    }
    
    // Update loan comment
    $result = updateLoanComment($loanId, $adminComment);
    
    if ($result) {
        $_SESSION['loan_detail_message'] = "Loan comment updated successfully.";
        $_SESSION['loan_detail_message_type'] = "success";
    } else {
        $_SESSION['loan_detail_message'] = "Failed to update loan comment. Please try again.";
        $_SESSION['loan_detail_message_type'] = "danger";
    }
    
    // Redirect back to loan details page
    header("Location: loan_details.php?id=" . $loanId);
    exit;
} else {
    // If not POST request, redirect to manage loans page
    header("Location: manage_loans.php");
    exit;
}
?>
