<?php
session_start();
require_once '../config/config.php';
require_once '../includes/auth_check.php';
require_once '../includes/functions.php';

// Check if user is logged in
requireLogin();

// Get user data
$user = getUserById($_SESSION['user_id']);

// Get user's theme preference
$theme = $user['theme'] ?? 'dark';

// Check if loan ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    $_SESSION['loan_message'] = "Invalid loan ID.";
    $_SESSION['loan_message_type'] = "danger";
    header("Location: loans.php");
    exit;
}

$loanId = intval($_GET['id']);

// Get loan details
$loan = getLoanById($loanId);

// Check if loan exists, belongs to the user, and is approved
if (!$loan || $loan['user_id'] != $_SESSION['user_id'] || $loan['status'] !== 'approved') {
    $_SESSION['loan_message'] = "Loan not found, not approved, or you don't have permission to repay it.";
    $_SESSION['loan_message_type'] = "danger";
    header("Location: loans.php");
    exit;
}

// Get payment methods
$paymentMethods = getPaymentMethods();

// Process form submission
$message = '';
$messageType = '';

if (isset($_SESSION['repay_message'])) {
    $message = $_SESSION['repay_message'];
    $messageType = $_SESSION['repay_message_type'] ?? 'success';
    unset($_SESSION['repay_message']);
    unset($_SESSION['repay_message_type']);
}

// Calculate remaining amount
$remainingAmount = $loan['total_repayment'] - $loan['amount_paid'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Repay Loan - <?php echo APP_NAME; ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <?php if ($theme === 'dark'): ?>
    <link rel="stylesheet" href="../assets/css/dark-theme.css">
    <?php else: ?>
    <link rel="stylesheet" href="../assets/css/light-theme.css">
    <?php endif; ?>
</head>
<body class="<?php echo $theme; ?>-theme">
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <?php include 'includes/sidebar.php'; ?>
            
            <!-- Main Content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Repay Loan</h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <a href="loan_details.php?id=<?php echo $loan['id']; ?>" class="btn btn-secondary">
                            <i class="fas fa-arrow-left me-2"></i>Back to Loan Details
                        </a>
                    </div>
                </div>
                
                <?php if (!empty($message)): ?>
                <div class="alert alert-<?php echo $messageType; ?> alert-dismissible fade show" role="alert">
                    <?php echo $message; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <?php endif; ?>
                
                <div class="row">
                    <div class="col-md-6">
                        <div class="card mb-4">
                            <div class="card-header">
                                <h5 class="mb-0">Loan Summary</h5>
                            </div>
                            <div class="card-body">
                                <p><strong>Loan ID:</strong> <?php echo $loan['loan_id']; ?></p>
                                <p><strong>Total Amount:</strong> $<?php echo number_format($loan['total_repayment'], 2); ?></p>
                                <p><strong>Amount Paid:</strong> $<?php echo number_format($loan['amount_paid'], 2); ?></p>
                                <p><strong>Remaining Amount:</strong> $<?php echo number_format($remainingAmount, 2); ?></p>
                                <p><strong>Due Date:</strong> <?php echo date('M d, Y', strtotime($loan['due_date'])); ?></p>
                                
                                <?php
                                $daysLeft = floor((strtotime($loan['due_date']) - time()) / (60 * 60 * 24));
                                $statusClass = $daysLeft < 0 ? 'text-danger' : ($daysLeft < 3 ? 'text-warning' : 'text-success');
                                $daysText = $daysLeft < 0 ? abs($daysLeft) . ' days overdue' : $daysLeft . ' days left';
                                ?>
                                
                                <p><strong>Status:</strong> <span class="<?php echo $statusClass; ?>"><?php echo $daysText; ?></span></p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <div class="card mb-4">
                            <div class="card-header">
                                <h5 class="mb-0">Make Payment</h5>
                            </div>
                            <div class="card-body">
                                <form action="process_loan_payment.php" method="post" enctype="multipart/form-data">
                                    <input type="hidden" name="loan_id" value="<?php echo $loan['id']; ?>">
                                    
                                    <div class="mb-3">
                                        <label for="payment_amount" class="form-label">Payment Amount</label>
                                        <div class="input-group">
                                            <span class="input-group-text">$</span>
                                            <input type="number" class="form-control" id="payment_amount" name="payment_amount" min="1" max="<?php echo $remainingAmount; ?>" step="0.01" value="<?php echo $remainingAmount; ?>" required>
                                        </div>
                                        <div class="form-text">Maximum amount: $<?php echo number_format($remainingAmount, 2); ?></div>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="payment_method" class="form-label">Payment Method</label>
                                        <select class="form-select" id="payment_method" name="payment_method" required>
                                            <option value="">Select Payment Method</option>
                                            <?php foreach ($paymentMethods as $method): ?>
                                            <option value="<?php echo $method['id']; ?>" data-instructions="<?php echo htmlspecialchars($method['instructions']); ?>" data-address="<?php echo $method['wallet_address']; ?>" data-qr="<?php echo $method['qr_code']; ?>">
                                                <?php echo $method['name']; ?>
                                            </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                    
                                    <div id="payment_instructions" class="mb-3 p-3 rounded" style="display: none; background-color: rgba(0,0,0,0.05);">
                                        <h6>Payment Instructions</h6>
                                        <div id="instructions_text"></div>
                                        
                                        <div class="mt-3" id="wallet_address_div" style="display: none;">
                                            <label class="form-label">Wallet Address</label>
                                            <div class="input-group mb-2">
                                                <input type="text" class="form-control" id="wallet_address" readonly>
                                                <button class="btn btn-outline-secondary" type="button" onclick="copyToClipboard('wallet_address')">
                                                    <i class="fas fa-copy"></i>
                                                </button>
                                            </div>
                                        </div>
                                        
                                        <div class="mt-3 text-center" id="qr_code_div" style="display: none;">
                                            <img id="qr_code_img" src="/placeholder.svg" alt="QR Code" class="img-fluid" style="max-width: 200px;">
                                        </div>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="transaction_id" class="form-label">Transaction ID / Reference</label>
                                        <input type="text" class="form-control" id="transaction_id" name="transaction_id" required>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="proof_image" class="form-label">Payment Proof (Screenshot)</label>
                                        <input type="file" class="form-control" id="proof_image" name="proof_image" accept="image/*" required>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="notes" class="form-label">Additional Notes (Optional)</label>
                                        <textarea class="form-control" id="notes" name="notes" rows="2"></textarea>
                                    </div>
                                    
                                    <button type="submit" class="btn btn-primary w-100">Submit Payment</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Handle payment method selection
        document.getElementById('payment_method').addEventListener('change', function() {
            const selectedOption = this.options[this.selectedIndex];
            const instructions = selectedOption.dataset.instructions;
            const walletAddress = selectedOption.dataset.address;
            const qrCode = selectedOption.dataset.qr;
            
            const instructionsDiv = document.getElementById('payment_instructions');
            const instructionsText = document.getElementById('instructions_text');
            const walletAddressDiv = document.getElementById('wallet_address_div');
            const walletAddressInput = document.getElementById('wallet_address');
            const qrCodeDiv = document.getElementById('qr_code_div');
            const qrCodeImg = document.getElementById('qr_code_img');
            
            if (this.value) {
                instructionsDiv.style.display = 'block';
                instructionsText.innerHTML = instructions;
                
                if (walletAddress) {
                    walletAddressDiv.style.display = 'block';
                    walletAddressInput.value = walletAddress;
                } else {
                    walletAddressDiv.style.display = 'none';
                }
                
                if (qrCode) {
                    qrCodeDiv.style.display = 'block';
                    qrCodeImg.src = '../uploads/qr_codes/' + qrCode;
                } else {
                    qrCodeDiv.style.display = 'none';
                }
            } else {
                instructionsDiv.style.display = 'none';
            }
        });
        
        // Copy to clipboard function
        function copyToClipboard(elementId) {
            const element = document.getElementById(elementId);
            element.select();
            document.execCommand('copy');
            
            // Show copied message
            const button = element.nextElementSibling;
            const originalHTML = button.innerHTML;
            button.innerHTML = '<i class="fas fa-check"></i> Copied';
            
            setTimeout(function() {
                button.innerHTML = originalHTML;
            }, 2000);
        }
    </script>
</body>
</html>
