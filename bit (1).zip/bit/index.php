<?php
session_start();
require_once 'config/config.php';
require_once 'includes/auth_check.php';

// Redirect to login if not authenticated
if (!isLoggedIn()) {
    header("Location: auth/login.php");
    exit();
}

// Redirect to admin dashboard if admin
if (isAdmin()) {
    header("Location: admin/dashboard.php");
    exit();
}

// Redirect to user dashboard if regular user
header("Location: user/dashboard.php");
exit();
?>
