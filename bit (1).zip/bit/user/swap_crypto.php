<?php
session_start();
require_once '../config/config.php';
require_once '../includes/auth_check.php';
require_once '../includes/functions.php';

// Check if user is logged in
requireLogin();
requireOTPVerification();

// Get user data
$user = getUserById($_SESSION['user_id']);

// Define available cryptocurrencies
$cryptocurrencies = [
    'BTC' => ['name' => 'Bitcoin', 'balance' => 0, 'icon' => 'bitcoin'],
    'ETH' => ['name' => 'Ethereum', 'balance' => 0, 'icon' => 'ethereum'],
    'LTC' => ['name' => 'Litecoin', 'balance' => 0, 'icon' => 'litecoin-sign'],
    'LINK' => ['name' => 'Chainlink', 'balance' => 0, 'icon' => 'link'],
    'BNB' => ['name' => 'Binance Coin', 'balance' => 0, 'icon' => 'b'],
    'ADA' => ['name' => 'Cardano', 'balance' => 0, 'icon' => 'a'],
    'USDT' => ['name' => 'Tether', 'balance' => 0, 'icon' => 'dollar-sign'],
    'BCH' => ['name' => 'Bitcoin Cash', 'balance' => 0, 'icon' => 'bitcoin'],
    'XRP' => ['name' => 'Ripple', 'balance' => 0, 'icon' => 'r'],
    'XLM' => ['name' => 'Stellar', 'balance' => 0, 'icon' => 's'],
    'AAVE' => ['name' => 'Aave', 'balance' => 0, 'icon' => 'a'],
];

$error = '';
$success = '';

// Handle swap submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $sourceAsset = $_POST['source_asset'] ?? '';
    $destinationAsset = $_POST['destination_asset'] ?? '';
    $amount = $_POST['amount'] ?? 0;
    
    // Validate input
    if (empty($sourceAsset) || empty($destinationAsset)) {
        $error = "Please select source and destination assets";
    } elseif (empty($amount) || !is_numeric($amount) || $amount <= 0) {
        $error = "Please enter a valid amount";
    } elseif ($sourceAsset === $destinationAsset) {
        $error = "Source and destination assets cannot be the same";
    } else {
        // For demo purposes, just show success message
        $success = "Swap request submitted successfully. $amount $sourceAsset has been converted to $destinationAsset.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Swap Crypto - <?php echo APP_NAME; ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        :root {
            --primary-color: #7000FF;
            --secondary-color: #8F00FF;
            --accent-color: #A020F0;
            --text-color: #FFFFFF;
            --bg-light: #F8F9FA;
            --card-bg: #FFFFFF;
        }
        
        body {
            background-color: var(--primary-color);
            color: var(--text-color);
            font-family: 'Roboto', sans-serif;
        }
        
        .sidebar {
            background-color: var(--primary-color);
            min-height: 100vh;
        }
        
        .main-content {
            background-color: var(--primary-color);
            min-height: 100vh;
            padding: 20px;
        }
        
        .card {
            background-color: var(--card-bg);
            border-radius: 15px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
            border: none;
        }
        
        .card-header {
            background-color: var(--card-bg);
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
            border-radius: 15px 15px 0 0 !important;
            padding: 15px 20px;
        }
        
        .card-body {
            padding: 20px;
        }
        
        .btn-primary {
            background-color: var(--accent-color);
            border-color: var(--accent-color);
        }
        
        .btn-primary:hover {
            background-color: var(--secondary-color);
            border-color: var(--secondary-color);
        }
        
        .nav-link {
            color: var(--text-color);
            padding: 10px 15px;
            margin: 5px 0;
            border-radius: 5px;
        }
        
        .nav-link:hover, .nav-link.active {
            background-color: rgba(255, 255, 255, 0.1);
        }
        
        .nav-link i {
            margin-right: 10px;
        }
        
        .user-profile {
            text-align: center;
            padding: 20px 0;
        }
        
        .user-avatar {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            background-color: #FFFFFF;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 10px;
        }
        
        .user-avatar i {
            font-size: 40px;
            color: var(--primary-color);
        }
        
        .balance-display {
            background-color: rgba(255, 255, 255, 0.1);
            border-radius: 30px;
            padding: 8px 15px;
            display: inline-block;
            margin-top: 10px;
        }
        
        .crypto-balance-card {
            background-color: #f8f9fa;
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 15px;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        
        .crypto-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background-color: var(--primary-color);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            margin-right: 15px;
        }
        
        .crypto-details {
            flex-grow: 1;
        }
        
        .trading-chart {
            width: 100%;
            height: 300px;
            background-color: #f8f9fa;
            border-radius: 10px;
            margin-bottom: 20px;
            overflow: hidden;
        }
        
        .swap-form {
            background-color: #f8f9fa;
            border-radius: 10px;
            padding: 20px;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 sidebar p-0">
                <div class="user-profile">
                    <div class="user-avatar">
                        <i class="fas fa-user"></i>
                    </div>
                    <h5 class="mb-0"><?php echo $user['first_name'] . ' ' . $user['last_name']; ?></h5>
                    <p class="text-light mb-2">online</p>
                    <div class="balance-display">
                        <i class="fas fa-wallet me-2"></i> $<?php echo number_format($user['balance'], 2); ?>
                    </div>
                </div>
                
                <ul class="nav flex-column mt-4">
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php">
                            <i class="fas fa-home"></i> Home
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="deposit.php">
                            <i class="fas fa-arrow-circle-down"></i> Deposit
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="withdraw.php">
                            <i class="fas fa-arrow-circle-up"></i> Withdraw
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="my_trades.php">
                            <i class="fas fa-chart-line"></i> Transactions
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="swap_crypto.php">
                            <i class="fas fa-exchange-alt"></i> Swap Crypto
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="investments.php">
                            <i class="fas fa-project-diagram"></i> Investments
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="referrals.php">
                            <i class="fas fa-user-plus"></i> Referrals
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="profile.php">
                            <i class="fas fa-user-cog"></i> Profile
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../auth/logout.php">
                            <i class="fas fa-sign-out-alt"></i> Logout
                        </a>
                    </li>
                </ul>
            </div>
            
            <!-- Main Content -->
            <div class="col-md-9 col-lg-10 main-content">
                <div class="card">
                    <div class="card-body">
                        <h2 class="mb-4 text-dark">Swap Crypto</h2>
                        
                        <?php if (!empty($error)): ?>
                            <div class="alert alert-danger"><?php echo $error; ?></div>
                        <?php endif; ?>
                        
                        <?php if (!empty($success)): ?>
                            <div class="alert alert-success"><?php echo $success; ?></div>
                        <?php endif; ?>
                        
                        <div class="row">
                            <div class="col-md-12 mb-4">
                                <p class="text-dark">Earn even more when you swap your Account balance to and from crypto.</p>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-3 mb-4">
                                <div class="crypto-balance-card">
                                    <div class="d-flex align-items-center">
                                        <div class="crypto-icon">
                                            <i class="fas fa-dollar-sign"></i>
                                        </div>
                                        <div class="crypto-details">
                                            <h6 class="mb-0 text-dark">Account Balance</h6>
                                            <h5 class="mb-0 text-dark">$<?php echo number_format($user['balance'], 2); ?></h5>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <?php foreach (array_slice($cryptocurrencies, 0, 3) as $symbol => $crypto): ?>
                                <div class="col-md-3 mb-4">
                                    <div class="crypto-balance-card">
                                        <div class="d-flex align-items-center">
                                            <div class="crypto-icon">
                                                <i class="fab fa-<?php echo $crypto['icon']; ?>"></i>
                                            </div>
                                            <div class="crypto-details">
                                                <h6 class="mb-0 text-dark"><?php echo $symbol; ?></h6>
                                                <h5 class="mb-0 text-dark"><?php echo $crypto['balance']; ?></h5>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                        
                        <div class="row">
                            <?php foreach (array_slice($cryptocurrencies, 3, 8) as $symbol => $crypto): ?>
                                <div class="col-md-3 mb-4">
                                    <div class="crypto-balance-card">
                                        <div class="d-flex align-items-center">
                                            <div class="crypto-icon">
                                                <i class="fab fa-<?php echo $crypto['icon']; ?>"></i>
                                            </div>
                                            <div class="crypto-details">
                                                <h6 class="mb-0 text-dark"><?php echo $symbol; ?></h6>
                                                <h5 class="mb-0 text-dark"><?php echo $crypto['balance']; ?></h5>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-12 mb-4">
                                <div class="trading-chart">
                                    <img src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/User_swap%20crypto-zvnafPAMHFwOoidt8EmyYHjW4vmYNC.png" alt="Trading Chart" class="img-fluid" style="width: 100%; height: 100%; object-fit: cover;">
                                </div>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="swap-form">
                                    <h5 class="text-dark mb-4">Swap Assets</h5>
                                    <form method="POST" action="">
                                        <div class="mb-3">
                                            <label for="source_asset" class="form-label text-dark">Source Account</label>
                                            <select class="form-select" id="source_asset" name="source_asset" required>
                                                <option value="">Select Source Asset</option>
                                                <option value="USD">USD (Account Balance)</option>
                                                <?php foreach ($cryptocurrencies as $symbol => $crypto): ?>
                                                    <option value="<?php echo $symbol; ?>"><?php echo $symbol; ?> (<?php echo $crypto['name']; ?>)</option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                        
                                        <div class="mb-3">
                                            <label for="destination_asset" class="form-label text-dark">Destination Account</label>
                                            <select class="form-select" id="destination_asset" name="destination_asset" required>
                                                <option value="">Select Destination Asset</option>
                                                <option value="USD">USD (Account Balance)</option>
                                                <?php foreach ($cryptocurrencies as $symbol => $crypto): ?>
                                                    <option value="<?php echo $symbol; ?>"><?php echo $symbol; ?> (<?php echo $crypto['name']; ?>)</option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                        
                                        <div class="mb-3">
                                            <label for="amount" class="form-label text-dark">Amount</label>
                                            <input type="number" class="form-control" id="amount" name="amount" step="0.00001" required>
                                            <div class="form-text">Enter amount of source asset to swap</div>
                                        </div>
                                        
                                        <div class="mb-3">
                                            <label class="form-label text-dark">You will get</label>
                                            <div class="input-group">
                                                <input type="text" class="form-control" id="result_amount" readonly>
                                                <span class="input-group-text" id="result_currency">USD</span>
                                            </div>
                                        </div>
                                        
                                        <div class="mb-3">
                                            <div class="d-flex justify-content-between">
                                                <span class="text-dark">Fees = 2%</span>
                                            </div>
                                        </div>
                                        
                                        <div class="d-grid">
                                            <button type="submit" class="btn btn-primary">Swap</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="text-center mt-3 text-light">
                    <p>All Rights Reserved © JetFx Growth 2025</p>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const sourceAssetSelect = document.getElementById('source_asset');
            const destinationAssetSelect = document.getElementById('destination_asset');
            const amountInput = document.getElementById('amount');
            const resultAmountInput = document.getElementById('result_amount');
            const resultCurrencySpan = document.getElementById('result_currency');
            
            // Exchange rates (simplified for demo)
            const exchangeRates = {
                'USD': 1,
                'BTC': 60000,
                'ETH': 3000,
                'LTC': 200,
                'LINK': 15,
                'BNB': 400,
                'ADA': 1.2,
                'USDT': 1,
                'BCH': 500,
                'XRP': 0.8,
                'XLM': 0.3,
                'AAVE': 150
            };
            
            function updateResult() {
                const sourceAsset = sourceAssetSelect.value;
                const destinationAsset = destinationAssetSelect.value;
                const amount = parseFloat(amountInput.value) || 0;
                
                if (sourceAsset && destinationAsset && amount > 0) {
                    // Calculate conversion with 2% fee
                    const sourceRate = exchangeRates[sourceAsset];
                    const destRate = exchangeRates[destinationAsset];
                    
                    const usdValue = amount * sourceRate;
                    const feeAmount = usdValue * 0.02;
                    const finalUsdValue = usdValue - feeAmount;
                    
                    const result = finalUsdValue / destRate;
                    
                    resultAmountInput.value = result.toFixed(8);
                    resultCurrencySpan.textContent = destinationAsset;
                } else {
                    resultAmountInput.value = '';
                    resultCurrencySpan.textContent = 'USD';
                }
            }
            
            sourceAssetSelect.addEventListener('change', updateResult);
            destinationAssetSelect.addEventListener('change', updateResult);
            amountInput.addEventListener('input', updateResult);
        });
    </script>
</body>
</html>
