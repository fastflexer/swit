<?php
session_start();
require_once '../config/config.php';
require_once '../includes/auth_check.php';
require_once '../includes/functions.php';

// Check if user is logged in
requireLogin();
requireOTPVerification();

// Check if there's a withdrawal request in session
if (!isset($_SESSION['withdrawal_request'])) {
    header("Location: withdraw.php");
    exit();
}

// Get user data
$user = getUserById($_SESSION['user_id']);
$withdrawalRequest = $_SESSION['withdrawal_request'];

$error = '';
$success = '';

// Check if OTP has expired
if (time() > $withdrawalRequest['otp_expiry']) {
    $error = "OTP has expired. Please request a new withdrawal.";
    unset($_SESSION['withdrawal_request']);
}

// Process OTP verification
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $enteredOTP = $_POST['otp'] ?? '';
    
    if (empty($enteredOTP)) {
        $error = "Please enter the OTP";
    } elseif ($enteredOTP !== $withdrawalRequest['otp']) {
        $error = "Invalid OTP. Please try again.";
    } else {
        // OTP is valid, process the withdrawal
        $amount = $withdrawalRequest['amount'];
        $paymentMethod = $withdrawalRequest['payment_method'];
        $walletAddress = $withdrawalRequest['wallet_address'];
        
        // Calculate fee (2%)
        $fee = $amount * 0.02;
        $netAmount = $amount - $fee;
        
        // Start transaction
        $conn->begin_transaction();
        
        try {
            // Deduct amount from user's balance
            $stmt = $conn->prepare("UPDATE users SET balance = balance - ? WHERE id = ?");
            $stmt->bind_param("di", $amount, $_SESSION['user_id']);
            $stmt->execute();
            
            // Insert withdrawal request
            $stmt = $conn->prepare("INSERT INTO withdrawals (user_id, amount, fee, payment_method, wallet_address, status, created_at) VALUES (?, ?, ?, ?, ?, 'pending', NOW())");
            $stmt->bind_param("iddss", $_SESSION['user_id'], $amount, $fee, $paymentMethod, $walletAddress);
            $stmt->execute();
            $withdrawalId = $conn->insert_id;
            
            // Commit transaction
            $conn->commit();
            
            // Send withdrawal confirmation email
            $subject = APP_NAME . " - Withdrawal Request Confirmation";
            $message = "
                <html>
                <head>
                    <title>Withdrawal Request Confirmation</title>
                </head>
                <body>
                    <h2>Withdrawal Request Confirmation</h2>
                    <p>Your withdrawal request has been submitted successfully and is pending approval.</p>
                    <p><strong>Amount:</strong> $" . number_format($amount, 2) . "</p>
                    <p><strong>Fee:</strong> $" . number_format($fee, 2) . "</p>
                    <p><strong>Net Amount:</strong> $" . number_format($netAmount, 2) . "</p>
                    <p><strong>Payment Method:</strong> " . $paymentMethod . "</p>
                    <p><strong>Wallet Address:</strong> " . $walletAddress . "</p>
                    <p><strong>Status:</strong> Pending</p>
                    <p>You will receive another email once your withdrawal has been processed.</p>
                    <p>Regards,<br>" . APP_NAME . " Team</p>
                </body>
                </html>
            ";
            
            sendEmail($user['email'], $subject, $message);
            
            // Clear withdrawal request from session
            unset($_SESSION['withdrawal_request']);
            
            $success = "Withdrawal request submitted successfully. Your withdrawal is pending approval.";
        } catch (Exception $e) {
            // Rollback transaction on error
            $conn->rollback();
            $error = "Failed to process withdrawal. Please try again.";
        }
    }
}

// Resend OTP
if (isset($_GET['resend']) && $_GET['resend'] === '1') {
    // Generate new OTP
    $newOTP = generateOTP();
    
    // Update OTP in session
    $_SESSION['withdrawal_request']['otp'] = $newOTP;
    $_SESSION['withdrawal_request']['otp_expiry'] = time() + (OTP_EXPIRY_MINUTES * 60);
    
    // Send new OTP to user's email
    $subject = APP_NAME . " - New Withdrawal Verification OTP";
    $message = "
        <html>
        <head>
            <title>Withdrawal Verification</title>
        </head>
        <body>
            <h2>Withdrawal Verification</h2>
            <p>You have requested a new OTP for your withdrawal of $" . number_format($withdrawalRequest['amount'], 2) . ".</p>
            <p>Your new OTP code for withdrawal verification is: <strong>" . $newOTP . "</strong></p>
            <p>This code will expire in " . OTP_EXPIRY_MINUTES . " minutes.</p>
            <p>If you did not request this withdrawal, please contact support immediately.</p>
            <p>Regards,<br>" . APP_NAME . " Team</p>
        </body>
        </html>
    ";
    
    if (sendEmail($user['email'], $subject, $message)) {
        $success = "A new OTP has been sent to your email.";
    } else {
        $error = "Failed to send OTP. Please try again.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verify Withdrawal - <?php echo APP_NAME; ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <?php include 'includes/sidebar.php'; ?>
            
            <!-- Main Content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Verify Withdrawal</h1>
                </div>
                
                <div class="row justify-content-center">
                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="mb-0">OTP Verification</h5>
                            </div>
                            <div class="card-body">
                                <?php if (!empty($error)): ?>
                                    <div class="alert alert-danger"><?php echo $error; ?></div>
                                <?php endif; ?>
                                
                                <?php if (!empty($success)): ?>
                                    <div class="alert alert-success"><?php echo $success; ?></div>
                                <?php endif; ?>
                                
                                <?php if (empty($success)): ?>
                                    <div class="alert alert-info">
                                        <p class="mb-0"><i class="fas fa-info-circle me-2"></i> A One-Time Password (OTP) has been sent to your email address.</p>
                                        <p class="mb-0"><i class="fas fa-info-circle me-2"></i> Please enter the OTP below to verify your withdrawal request.</p>
                                    </div>
                                    
                                    <div class="withdrawal-details mb-4">
                                        <h6>Withdrawal Details:</h6>
                                        <ul class="list-group">
                                            <li class="list-group-item d-flex justify-content-between">
                                                <span>Amount:</span>
                                                <strong>$<?php echo number_format($withdrawalRequest['amount'], 2); ?></strong>
                                            </li>
                                            <li class="list-group-item d-flex justify-content-between">
                                                <span>Fee (2%):</span>
                                                <strong>$<?php echo number_format($withdrawalRequest['amount'] * 0.02, 2); ?></strong>
                                            </li>
                                            <li class="list-group-item d-flex justify-content-between">
                                                <span>Net Amount:</span>
                                                <strong>$<?php echo number_format($withdrawalRequest['amount'] - ($withdrawalRequest['amount'] * 0.02), 2); ?></strong>
                                            </li>
                                            <li class="list-group-item d-flex justify-content-between">
                                                <span>Payment Method:</span>
                                                <strong><?php echo $withdrawalRequest['payment_method']; ?></strong>
                                            </li>
                                        </ul>
                                    </div>
                                    
                                    <form method="POST" action="">
                                        <div class="mb-3">
                                            <label for="otp" class="form-label">Enter OTP</label>
                                            <input type="text" class="form-control form-control-lg text-center" id="otp" name="otp" placeholder="Enter 6-digit OTP" maxlength="6" required>
                                        </div>
                                        
                                        <div class="d-grid gap-2">
                                            <button type="submit" class="btn btn-primary">Verify & Submit Withdrawal</button>
                                            <a href="?resend=1" class="btn btn-outline-secondary">Resend OTP</a>
                                        </div>
                                    </form>
                                    
                                    <div class="mt-3 text-center">
                                        <p class="text-muted">OTP expires in <?php echo OTP_EXPIRY_MINUTES; ?> minutes</p>
                                        <a href="withdraw.php" class="btn btn-link">Cancel Withdrawal</a>
                                    </div>
                                <?php else: ?>
                                    <div class="text-center">
                                        <i class="fas fa-check-circle text-success" style="font-size: 4rem;"></i>
                                        <h4 class="mt-3">Withdrawal Request Submitted</h4>
                                        <p>Your withdrawal request has been submitted successfully and is pending approval.</p>
                                        <a href="withdraw.php" class="btn btn-primary mt-3">Back to Withdrawals</a>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
