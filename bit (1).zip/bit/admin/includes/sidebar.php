<nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-dark sidebar collapse">
    <div class="position-sticky pt-3">
        <div class="text-center mb-3">
            <h5 class="text-white">Admin Dashboard</h5>
        </div>
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'active' : ''; ?>" href="dashboard.php">
                    <i class="fas fa-tachometer-alt me-2"></i>
                    Dashboard
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'manage_users.php' || basename($_SERVER['PHP_SELF']) == 'user_details.php' ? 'active' : ''; ?>" href="manage_users.php">
                    <i class="fas fa-users me-2"></i>
                    Manage Users
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'manage_deposits.php' || basename($_SERVER['PHP_SELF']) == 'process_deposit.php' ? 'active' : ''; ?>" href="manage_deposits.php">
                    <i class="fas fa-money-bill-wave me-2"></i>
                    Manage Deposits
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'manage_withdrawals.php' || basename($_SERVER['PHP_SELF']) == 'process_withdrawal.php' ? 'active' : ''; ?>" href="manage_withdrawals.php">
                    <i class="fas fa-money-bill-transfer me-2"></i>
                    Manage Withdrawals
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'manage_accounts.php' ? 'active' : ''; ?>" href="manage_accounts.php">
                    <i class="fas fa-wallet me-2"></i>
                    Manage Accounts
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'investment.php' ? 'active' : ''; ?>" href="investment.php">
                    <i class="fas fa-chart-line me-2"></i>
                    Investments
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'manage_traders.php' || basename($_SERVER['PHP_SELF']) == 'trader_details.php' || basename($_SERVER['PHP_SELF']) == 'add_trader.php' || basename($_SERVER['PHP_SELF']) == 'edit_trader.php' ? 'active' : ''; ?>" href="manage_traders.php">
                    <i class="fas fa-user-tie me-2"></i>
                    Manage Traders
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'manage_trades.php' || basename($_SERVER['PHP_SELF']) == 'add_trade.php' || basename($_SERVER['PHP_SELF']) == 'edit_trade.php' ? 'active' : ''; ?>" href="manage_trades.php">
                    <i class="fas fa-exchange-alt me-2"></i>
                    Manage Trades
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'manage_subscription_plans.php' || basename($_SERVER['PHP_SELF']) == 'add_subscription_plan.php' || basename($_SERVER['PHP_SELF']) == 'edit_subscription_plan.php' ? 'active' : ''; ?>" href="manage_subscription_plans.php">
                    <i class="fas fa-star me-2"></i>
                    Subscription Plans
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'manage_signals.php' || basename($_SERVER['PHP_SELF']) == 'add_signal.php' || basename($_SERVER['PHP_SELF']) == 'edit_signal.php' ? 'active' : ''; ?>" href="manage_signals.php">
                    <i class="fas fa-signal me-2"></i>
                    Manage Signals
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'manage_nfts.php' || basename($_SERVER['PHP_SELF']) == 'add_nft.php' || basename($_SERVER['PHP_SELF']) == 'edit_nft.php' || basename($_SERVER['PHP_SELF']) == 'nft_details.php' ? 'active' : ''; ?>" href="manage_nfts.php">
                    <i class="fas fa-image me-2"></i>
                    Manage NFTs
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'manage_loans.php' || basename($_SERVER['PHP_SELF']) == 'loan_details.php' || basename($_SERVER['PHP_SELF']) == 'process_loan.php' ? 'active' : ''; ?>" href="manage_loans.php">
                    <i class="fas fa-hand-holding-usd me-2"></i>
                    Manage Loans
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'loan_plans.php' ? 'active' : ''; ?>" href="loan_plans.php">
                    <i class="fas fa-list-alt me-2"></i>
                    Loan Plans
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'administrators.php' || basename($_SERVER['PHP_SELF']) == 'add_manager.php' ? 'active' : ''; ?>" href="administrators.php">
                    <i class="fas fa-user-shield me-2"></i>
                    Administrators
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'settings.php' ? 'active' : ''; ?>" href="settings.php">
                    <i class="fas fa-cog me-2"></i>
                    Settings
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'payment_settings.php' ? 'active' : ''; ?>" href="payment_settings.php">
                    <i class="fas fa-credit-card me-2"></i>
                    Payment Settings
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="../auth/logout.php">
                    <i class="fas fa-sign-out-alt me-2"></i>
                    Logout
                </a>
            </li>
        </ul>
    </div>
</nav>
