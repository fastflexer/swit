<?php
// Check if user is logged in
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

// Check if user is admin
function isAdmin() {
    return isset($_SESSION['user_role']) && ($_SESSION['user_role'] == 'admin' || $_SESSION['user_role'] == 'super_admin');
}

// Check if user is a trader
function isTrader() {
    return isset($_SESSION['user_role']) && $_SESSION['user_role'] == 'trader';
}

// Check if user has verified OTP
function hasVerifiedOTP() {
    return isset($_SESSION['otp_verified']) && $_SESSION['otp_verified'] === true;
}

// Redirect if not logged in
function requireLogin() {
    if (!isLoggedIn()) {
        header("Location: " . APP_URL . "/auth/login.php");
        exit();
    }
}

// Redirect if not admin
function requireAdmin() {
    if (!isAdmin()) {
        header("Location: " . APP_URL . "/index.php");
        exit();
    }
}

// Redirect if OTP not verified
function requireOTPVerification() {
    if (!hasVerifiedOTP()) {
        header("Location: " . APP_URL . "/auth/verify_otp.php");
        exit();
    }
}
?>
