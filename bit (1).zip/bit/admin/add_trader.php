<?php
session_start();
require_once '../config/config.php';
require_once '../includes/auth_check.php';
require_once '../includes/functions.php';
require_once '../includes/copytrade.php';

// Check if user is admin
requireAdmin();
requireOTPVerification();

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $firstName = $_POST['first_name'] ?? '';
    $lastName = $_POST['last_name'] ?? '';
    $email = $_POST['email'] ?? '';
    $phone = $_POST['phone'] ?? '';
    $password = $_POST['password'] ?? '';
    $biography = $_POST['biography'] ?? '';
    $tradingStrategy = $_POST['trading_strategy'] ?? '';
    $experience = $_POST['experience'] ?? '';
    $riskLevel = $_POST['risk_level'] ?? '';
    
    // Validate input
    if (empty($firstName) || empty($lastName) || empty($email) || empty($phone) || empty($password)) {
        $error = "All required fields must be filled";
    } else {
        // Check if email already exists
        $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $error = "Email already exists";
        } else {
            // Start transaction
            $conn->begin_transaction();
            
            try {
                // Hash password
                $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
                
                // Insert user
                $stmt = $conn->prepare("INSERT INTO users (first_name, last_name, email, phone, password, role, status, created_at) VALUES (?, ?, ?, ?, ?, 'trader', 'active', NOW())");
                $stmt->bind_param("sssss", $firstName, $lastName, $email, $phone, $hashedPassword);
                $stmt->execute();
                
                $userId = $conn->insert_id;
                
                // Insert trader details
                $stmt = $conn->prepare("INSERT INTO traders (user_id, biography, trading_strategy, experience, risk_level, success_rate, total_trades, profitable_trades, created_at) VALUES (?, ?, ?, ?, ?, 0, 0, 0, NOW())");
                $stmt->bind_param("issss", $userId, $biography, $tradingStrategy, $experience, $riskLevel);
                $stmt->execute();
                
                // Handle profile picture upload
                if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] === UPLOAD_ERR_OK) {
                    $allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
                    $maxSize = 5 * 1024 * 1024; // 5MB
                    
                    if (!in_array($_FILES['profile_picture']['type'], $allowedTypes)) {
                        throw new Exception("Invalid file type. Only JPG, PNG, and GIF are allowed.");
                    } elseif ($_FILES['profile_picture']['size'] > $maxSize) {
                        throw new Exception("File size exceeds the limit of 5MB.");
                    } else {
                        $fileName = 'trader_' . $userId . '_' . time() . '.' . pathinfo($_FILES['profile_picture']['name'], PATHINFO_EXTENSION);
                        $uploadPath = '../uploads/profile/' . $fileName;
                        
                        // Create directory if it doesn't exist
                        if (!file_exists('../uploads/profile/')) {
                            mkdir('../uploads/profile/', 0777, true);
                        }
                        
                        if (move_uploaded_file($_FILES['profile_picture']['tmp_name'], $uploadPath)) {
                            $stmt = $conn->prepare("UPDATE users SET profile_picture = ? WHERE id = ?");
                            $stmt->bind_param("si", $fileName, $userId);
                            $stmt->execute();
                        } else {
                            throw new Exception("Failed to upload profile picture.");
                        }
                    }
                }
                
                // Commit transaction
                $conn->commit();
                
                $success = "Trader added successfully";
            } catch (Exception $e) {
                // Rollback transaction on error
                $conn->rollback();
                $error = "Error: " . $e->getMessage();
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Trader - <?php echo APP_NAME; ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <?php include 'includes/sidebar.php'; ?>
            
            <!-- Main Content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Add New Trader</h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <a href="manage_traders.php" class="btn btn-sm btn-outline-secondary">
                            <i class="fas fa-arrow-left"></i> Back
                        </a>
                    </div>
                </div>
                
                <?php if (!empty($error)): ?>
                    <div class="alert alert-danger"><?php echo $error; ?></div>
                <?php endif; ?>
                
                <?php if (!empty($success)): ?>
                    <div class="alert alert-success"><?php echo $success; ?></div>
                <?php endif; ?>
                
                <div class="card">
                    <div class="card-body">
                        <form method="POST" action="" enctype="multipart/form-data">
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <label for="first_name" class="form-label">First Name <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="first_name" name="first_name" required>
                                </div>
                                <div class="col-md-6">
                                    <label for="last_name" class="form-label">Last Name <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="last_name" name="last_name" required>
                                </div>
                            </div>
                            
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <label for="email" class="form-label">Email <span class="text-danger">*</span></label>
                                    <input type="email" class="form-control" id="email" name="email" required>
                                </div>
                                <div class="col-md-6">
                                    <label for="phone" class="form-label">Phone <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="phone" name="phone" required>
                                </div>
                            </div>
                            
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <label for="password" class="form-label">Password <span class="text-danger">*</span></label>
                                    <input type="password" class="form-control" id="password" name="password" required>
                                </div>
                                <div class="col-md-6">
                                    <label for="risk_level" class="form-label">Risk Level</label>
                                    <select class="form-select" id="risk_level" name="risk_level">
                                        <option value="Low">Low</option>
                                        <option value="Medium" selected>Medium</option>
                                        <option value="High">High</option>
                                    </select>
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label for="profile_picture" class="form-label">Profile Picture</label>
                                <input type="file" class="form-control" id="profile_picture" name="profile_picture">
                                <div class="form-text">Recommended size: 300x300 pixels. Max file size: 5MB.</div>
                            </div>
                            
                            <div class="mb-3">
                                <label for="biography" class="form-label">Biography</label>
                                <textarea class="form-control" id="biography" name="biography" rows="3"></textarea>
                            </div>
                            
                            <div class="mb-3">
                                <label for="trading_strategy" class="form-label">Trading Strategy</label>
                                <textarea class="form-control" id="trading_strategy" name="trading_strategy" rows="3"></textarea>
                            </div>
                            
                            <div class="mb-3">
                                <label for="experience" class="form-label">Experience</label>
                                <textarea class="form-control" id="experience" name="experience" rows="3"></textarea>
                            </div>
                            
                            <div class="d-grid gap-2">
                                <button type="submit" class="btn btn-primary">Add Trader</button>
                            </div>
                        </form>
                    </div>
                </div>
            </main>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
