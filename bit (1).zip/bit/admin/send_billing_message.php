<?php
session_start();
require_once '../config/config.php';
require_once '../includes/auth_check.php';
require_once '../includes/functions.php';

// Check if user is admin
requireAdmin();
requireOTPVerification();

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['user_id']) || !isset($_POST['subject']) || !isset($_POST['message'])) {
    header("Location: manage_users.php");
    exit();
}

$userId = $_POST['user_id'];
$subject = $_POST['subject'];
$message = $_POST['message'];

// Get user data
$user = getUserById($userId);

if (!$user) {
    $_SESSION['error'] = "User not found";
    header("Location: manage_users.php");
    exit();
}

// Insert billing message
$stmt = $conn->prepare("INSERT INTO billing_messages (user_id, subject, message, created_at) VALUES (?, ?, ?, NOW())");
$stmt->bind_param("iss", $userId, $subject, $message);

if ($stmt->execute()) {
    $_SESSION['success'] = "Billing message sent successfully";
} else {
    $_SESSION['error'] = "Failed to send billing message";
}

// Redirect back to user details
header("Location: user_details.php?id=" . $userId);
exit();
?>
