<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/mail_helper.php';

// Generate random OTP
function generateOTP($length = 6) {
   $characters = '0123456789';
   $otp = '';
   
   for ($i = 0; $i < $length; $i++) {
       $otp .= $characters[rand(0, strlen($characters) - 1)];
   }
   
   return $otp;
}

// Store OTP in database
function storeOTP($userId, $otp) {
   global $conn;
   
   // Delete any existing OTP for this user
   $stmt = $conn->prepare("DELETE FROM otps WHERE user_id = ?");
   $stmt->bind_param("i", $userId);
   $stmt->execute();
   
   // Insert new OTP
   $expiryTime = date('Y-m-d H:i:s', strtotime('+' . OTP_EXPIRY_MINUTES . ' minutes'));
   $stmt = $conn->prepare("INSERT INTO otps (user_id, otp_code, expiry_time) VALUES (?, ?, ?)");
   $stmt->bind_param("iss", $userId, $otp, $expiryTime);
   
   return $stmt->execute();
}

// Verify OTP 

function verifyOTP($userId, $otp) {
    global $conn;
    $stmt = $conn->prepare("SELECT otp_code, expiry_time FROM otps WHERE user_id = ? ORDER BY id DESC LIMIT 1");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result && $row = $result->fetch_assoc()) {
        // Check if OTP matches and is not expired
        if ($row['otp_code'] === $otp && strtotime($row['expiry_time']) > time()) {
            return true;
        }
    }
    return false;
}

// Send OTP via email
require_once '../vendor/autoload.php'; // Make sure this path is correct

function sendOTP($toEmail, $otp) {
    // Create the Transport
    $transport = (new Swift_SmtpTransport('mail.jetfxgrowth.online', 587, 'tls'))
        ->setUsername('otps@jetfxgrowth.online')
        ->setPassword('10@Jetfxgrowth10@');

    // Create the Mailer using your created Transport
    $mailer = new Swift_Mailer($transport);

    // Create a message
    $message = (new Swift_Message('Your OTP Code'))
        ->setFrom(['otps@jetfxgrowth.online' => 'JetFx Growth'])
        ->setTo([$toEmail])
        ->setBody("Your OTP code is: $otp");

    // Send the message
    try {
        $result = $mailer->send($message);
        return $result > 0;
    } catch (Exception $e) {
        // Optionally log $e->getMessage()
        return false;
    }
}
// ... existing code ...

// Format currency
function formatCurrency($amount, $currency = '$') {
   return $currency . number_format($amount, 2);
}

// Get user by ID
function getUserById($userId) {
   global $conn;
   
   $stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
   $stmt->bind_param("i", $userId);
   $stmt->execute();
   $result = $stmt->get_result();
   
   if ($result->num_rows > 0) {
       return $result->fetch_assoc();
   }
   
   return null;
}

// Generate unique referral code
function generateReferralCode($length = 8) {
   global $conn;
   
   $characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
   $code = '';
   
   do {
       $code = '';
       for ($i = 0; $i < $length; $i++) {
           $code .= $characters[rand(0, strlen($characters) - 1)];
       }
       
       // Check if code already exists
       $stmt = $conn->prepare("SELECT * FROM users WHERE referral_code = ?");
       $stmt->bind_param("s", $code);
       $stmt->execute();
       $result = $stmt->get_result();
   } while ($result->num_rows > 0);
   
   return $code;
}

// Log user activity
function logUserActivity($userId, $activity, $ipAddress = null) {
   global $conn;
   
   if ($ipAddress === null) {
       $ipAddress = $_SERVER['REMOTE_ADDR'];
   }
   
   $stmt = $conn->prepare("INSERT INTO user_activities (user_id, activity, ip_address, created_at) VALUES (?, ?, ?, NOW())");
   $stmt->bind_param("iss", $userId, $activity, $ipAddress);
   
   return $stmt->execute();
}

// Get all users
function getAllUsers() {
   global $conn;
   
   $stmt = $conn->prepare("SELECT * FROM users WHERE role != 'admin' AND role != 'super_admin' ORDER BY created_at DESC");
   $stmt->execute();
   $result = $stmt->get_result();
   
   $users = [];
   while ($row = $result->fetch_assoc()) {
       $users[] = $row;
   }
   
   return $users;
}

// Get all admins
function getAllAdmins() {
   global $conn;
   
   $stmt = $conn->prepare("SELECT * FROM users WHERE role = 'admin' OR role = 'super_admin' ORDER BY created_at DESC");
   $stmt->execute();
   $result = $stmt->get_result();
   
   $admins = [];
   while ($row = $result->fetch_assoc()) {
       $admins[] = $row;
   }
   
   return $admins;
}

// Get all deposits
function getAllDeposits() {
   global $conn;
   
   $stmt = $conn->prepare("SELECT d.*, u.first_name, u.last_name, u.email FROM deposits d JOIN users u ON d.user_id = u.id ORDER BY d.created_at DESC");
   $stmt->execute();
   $result = $stmt->get_result();
   
   $deposits = [];
   while ($row = $result->fetch_assoc()) {
       $deposits[] = $row;
   }
   
   return $deposits;
}

// ... existing code ...
function getTotalDeposits($userId) {
    global $conn;
    $stmt = $conn->prepare("SELECT SUM(amount) as total FROM deposits WHERE user_id = ? AND status = 'approved'");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        return $row['total'] ?? 0;
    }
    return 0;
}

// Get all withdrawals
function getAllWithdrawals() {
   global $conn;
   
   $stmt = $conn->prepare("SELECT w.*, u.first_name, u.last_name, u.email FROM withdrawals w JOIN users u ON w.user_id = u.id ORDER BY w.created_at DESC");
   $stmt->execute();
   $result = $stmt->get_result();
   
   $withdrawals = [];
   while ($row = $result->fetch_assoc()) {
       $withdrawals[] = $row;
   }
   
   return $withdrawals;
}

// Get Total Withdrawal
function getTotalWithdrawals($userId) {
    global $conn;
    $stmt = $conn->prepare("SELECT SUM(amount) as total FROM withdrawals WHERE user_id = ? AND status = 'approved'");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        return $row['total'] ?? 0;
    }
    return 0;
}

// Get Total Trades
function getTotalTrades($userId) {
    global $conn;
    $stmt = $conn->prepare("SELECT COUNT(*) as total FROM trade_history WHERE user_id = ?");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        return $row['total'] ?? 0;
    }
    return 0;
}

// Open Trades
function getOpenTrades($userId) {
    global $conn;
    $stmt = $conn->prepare("SELECT COUNT(*) as open_trades FROM trade_history WHERE user_id = ? AND status = 'open'");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        return $row['open_trades'] ?? 0;
    }
    return 0;
}

// Get Closed trades
function getClosedTrades($userId) {
    global $conn;
    $stmt = $conn->prepare("SELECT COUNT(*) as closed_trades FROM trade_history WHERE user_id = ? AND status = 'closed'");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        return $row['closed_trades'] ?? 0;
    }
    return 0;
}


// Get Unread Notification
function getUnreadNotifications($userId) {
    global $conn;
    $stmt = $conn->prepare("SELECT COUNT(*) as unread_count FROM notifications WHERE user_id = ? AND `read` = 0");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        return $row['unread_count'] ?? 0;
    }
    return 0;
}



// Get all trading accounts
function getAllTradingAccounts() {
   global $conn;
   
   $stmt = $conn->prepare("SELECT t.*, u.first_name, u.last_name, u.email FROM trading_accounts t JOIN users u ON t.user_id = u.id ORDER BY t.created_at DESC");
   $stmt->execute();
   $result = $stmt->get_result();
   
   $accounts = [];
   while ($row = $result->fetch_assoc()) {
       $accounts[] = $row;
   }
   
   return $accounts;
}

// Get all investment plans
function getAllInvestmentPlans() {
   global $conn;
   
   $stmt = $conn->prepare("SELECT * FROM investment_plans ORDER BY min_amount ASC");
   $stmt->execute();
   $result = $stmt->get_result();
   
   $plans = [];
   while ($row = $result->fetch_assoc()) {
       $plans[] = $row;
   }
   
   return $plans;
}

// Get active investments
function getActiveInvestments() {
   global $conn;
   
   $stmt = $conn->prepare("SELECT i.*, u.first_name, u.last_name, u.email, p.name as plan_name FROM investments i JOIN users u ON i.user_id = u.id JOIN investment_plans p ON i.plan_id = p.id WHERE i.status = 'active' ORDER BY i.created_at DESC");
   $stmt->execute();
   $result = $stmt->get_result();
   
   $investments = [];
   while ($row = $result->fetch_assoc()) {
       $investments[] = $row;
   }
   
   return $investments;
}

// Get dashboard statistics
function getDashboardStats() {
    global $pdo;
    
    try {
        // Get total users
        $stmt = $pdo->query("SELECT COUNT(*) FROM users");
        $total_users = $stmt->fetchColumn();

        // Get total investments
        $stmt = $pdo->query("SELECT COALESCE(SUM(amount), 0) FROM investments");
        $total_investments = $stmt->fetchColumn();

        // Get pending withdrawals count
        $stmt = $pdo->query("SELECT COUNT(*) FROM withdrawals WHERE status = 'pending'");
        $pending_withdrawals = $stmt->fetchColumn();

        // Get active investments count
        $stmt = $pdo->query("SELECT COUNT(*) FROM investments WHERE status = 'active'");
        $active_investments = $stmt->fetchColumn();

        // Get recent users
        $stmt = $pdo->query("SELECT username, email, created_at FROM users ORDER BY created_at DESC LIMIT 5");
        $recent_users = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Get recent transactions
        $stmt = $pdo->query("
            SELECT 
                u.username,
                CASE 
                    WHEN i.id IS NOT NULL THEN 'Investment'
                    WHEN w.id IS NOT NULL THEN 'Withdrawal'
                END as type,
                COALESCE(i.amount, w.amount) as amount,
                COALESCE(i.status, w.status) as status,
                COALESCE(i.created_at, w.created_at) as created_at
            FROM 
                (SELECT id, user_id, amount, status, created_at FROM investments
                 UNION ALL
                 SELECT id, user_id, amount, status, created_at FROM withdrawals) as combined_data
            LEFT JOIN investments i ON combined_data.id = i.id
            LEFT JOIN withdrawals w ON combined_data.id = w.id
            LEFT JOIN users u ON combined_data.user_id = u.id
            ORDER BY combined_data.created_at DESC
            LIMIT 5
        ");
        $recent_transactions = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return [
            'total_users' => $total_users,
            'total_investments' => $total_investments,
            'pending_withdrawals' => $pending_withdrawals,
            'active_investments' => $active_investments,
            'recent_users' => $recent_users,
            'recent_transactions' => $recent_transactions
        ];
    } catch (PDOException $e) {
        // Return default values if there's an error
        return [
            'total_users' => 0,
            'total_investments' => 0,
            'pending_withdrawals' => 0,
            'active_investments' => 0,
            'recent_users' => [],
            'recent_transactions' => []
        ];
    }
}

// Get payment methods
function getPaymentMethods() {
   global $conn;
   
   $stmt = $conn->prepare("SELECT * FROM payment_methods WHERE status = 'enabled'");
   $stmt->execute();
   $result = $stmt->get_result();
   
   $methods = [];
   while ($row = $result->fetch_assoc()) {
       $methods[] = $row;
   }
   
   return $methods;
}
?>
