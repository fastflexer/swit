<?php
/**
 * CopyTrade System Functions
 */

// Get all master traders
function getMasterTraders() {
    global $conn;
    
    $stmt = $conn->prepare("SELECT u.*, t.success_rate, t.total_trades, t.profitable_trades FROM users u JOIN traders t ON u.id = t.user_id WHERE u.role = 'trader' AND u.status = 'active' ORDER BY t.success_rate DESC");
    $stmt->execute();
    $result = $stmt->get_result();
    
    $traders = [];
    while ($row = $result->fetch_assoc()) {
        $traders[] = $row;
    }
    
    return $traders;
}

// Get trader details
function getTraderDetails($traderId) {
    global $conn;
    
    $stmt = $conn->prepare("SELECT u.*, t.* FROM users u JOIN traders t ON u.id = t.user_id WHERE u.id = ?");
    $stmt->bind_param("i", $traderId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        return $result->fetch_assoc();
    }
    
    return null;
}

// Get trader's trades
function getTraderTrades($traderId) {
    global $conn;
    
    $stmt = $conn->prepare("SELECT * FROM trades WHERE trader_id = ? ORDER BY created_at DESC");
    $stmt->bind_param("i", $traderId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $trades = [];
    while ($row = $result->fetch_assoc()) {
        $trades[] = $row;
    }
    
    return $trades;
}

// Get user's copy trades
function getUserCopyTrades($userId) {
    global $conn;
    
    $stmt = $conn->prepare("SELECT c.*, u.first_name, u.last_name, u.email FROM copy_trades c JOIN users u ON c.trader_id = u.id WHERE c.user_id = ? ORDER BY c.created_at DESC");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $copyTrades = [];
    while ($row = $result->fetch_assoc()) {
        $copyTrades[] = $row;
    }
    
    return $copyTrades;
}

// Start copy trading
function startCopyTrading($userId, $traderId, $amount, $accountId) {
    global $conn;
    
    // Check if user has enough balance
    $stmt = $conn->prepare("SELECT balance FROM users WHERE id = ?");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    
    if ($user['balance'] < $amount) {
        return [
            'success' => false,
            'message' => 'Insufficient balance'
        ];
    }
    
    // Start transaction
    $conn->begin_transaction();
    
    try {
        // Deduct amount from user's balance
        $stmt = $conn->prepare("UPDATE users SET balance = balance - ? WHERE id = ?");
        $stmt->bind_param("di", $amount, $userId);
        $stmt->execute();
        
        // Create copy trade record
        $stmt = $conn->prepare("INSERT INTO copy_trades (user_id, trader_id, amount, account_id, status, created_at) VALUES (?, ?, ?, ?, 'active', NOW())");
        $stmt->bind_param("iiis", $userId, $traderId, $amount, $accountId);
        $stmt->execute();
        
        // Commit transaction
        $conn->commit();
        
        return [
            'success' => true,
            'message' => 'Copy trading started successfully'
        ];
    } catch (Exception $e) {
        // Rollback transaction on error
        $conn->rollback();
        
        return [
            'success' => false,
            'message' => 'Failed to start copy trading: ' . $e->getMessage()
        ];
    }
}

// Stop copy trading
function stopCopyTrading($copyTradeId, $userId) {
    global $conn;
    
    // Get copy trade details
    $stmt = $conn->prepare("SELECT * FROM copy_trades WHERE id = ? AND user_id = ?");
    $stmt->bind_param("ii", $copyTradeId, $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        return [
            'success' => false,
            'message' => 'Copy trade not found'
        ];
    }
    
    $copyTrade = $result->fetch_assoc();
    
    // Check if copy trade is already stopped
    if ($copyTrade['status'] !== 'active') {
        return [
            'success' => false,
            'message' => 'Copy trade is already stopped'
        ];
    }
    
    // Start transaction
    $conn->begin_transaction();
    
    try {
        // Update copy trade status
        $stmt = $conn->prepare("UPDATE copy_trades SET status = 'stopped', stopped_at = NOW() WHERE id = ?");
        $stmt->bind_param("i", $copyTradeId);
        $stmt->execute();
        
        // Calculate profit/loss
        $profit = calculateCopyTradeProfit($copyTradeId);
        
        // Update copy trade profit
        $stmt = $conn->prepare("UPDATE copy_trades SET profit = ? WHERE id = ?");
        $stmt->bind_param("di", $profit, $copyTradeId);
        $stmt->execute();
        
        // Return amount + profit to user's balance
        $returnAmount = $copyTrade['amount'] + $profit;
        $stmt = $conn->prepare("UPDATE users SET balance = balance + ? WHERE id = ?");
        $stmt->bind_param("di", $returnAmount, $userId);
        $stmt->execute();
        
        // Commit transaction
        $conn->commit();
        
        return [
            'success' => true,
            'message' => 'Copy trading stopped successfully',
            'profit' => $profit
        ];
    } catch (Exception $e) {
        // Rollback transaction on error
        $conn->rollback();
        
        return [
            'success' => false,
            'message' => 'Failed to stop copy trading: ' . $e->getMessage()
        ];
    }
}

// Calculate copy trade profit
function calculateCopyTradeProfit($copyTradeId) {
    global $conn;
    
    // Get copy trade details
    $stmt = $conn->prepare("SELECT * FROM copy_trades WHERE id = ?");
    $stmt->bind_param("i", $copyTradeId);
    $stmt->execute();
    $result = $stmt->get_result();
    $copyTrade = $result->fetch_assoc();
    
    // Get trader's performance during copy trade period
    $stmt = $conn->prepare("SELECT AVG(profit_percentage) as avg_profit FROM trades WHERE trader_id = ? AND created_at >= ?");
    $stmt->bind_param("is", $copyTrade['trader_id'], $copyTrade['created_at']);
    $stmt->execute();
    $result = $stmt->get_result();
    $performance = $result->fetch_assoc();
    
    // Calculate profit based on trader's performance
    $profitPercentage = $performance['avg_profit'] ?? 0;
    $profit = $copyTrade['amount'] * ($profitPercentage / 100);
    
    return $profit;
}

// Get all copy trades (for admin)
function getAllCopyTrades() {
    global $conn;
    
    $stmt = $conn->prepare("SELECT c.*, u.first_name as user_first_name, u.last_name as user_last_name, u.email as user_email, t.first_name as trader_first_name, t.last_name as trader_last_name, t.email as trader_email FROM copy_trades c JOIN users u ON c.user_id = u.id JOIN users t ON c.trader_id = t.id ORDER BY c.created_at DESC");
    $stmt->execute();
    $result = $stmt->get_result();
    
    $copyTrades = [];
    while ($row = $result->fetch_assoc()) {
        $copyTrades[] = $row;
    }
    
    return $copyTrades;
}

// Register as a trader
function registerAsTrader($userId) {
    global $conn;
    
    // Check if user is already a trader
    $stmt = $conn->prepare("SELECT * FROM traders WHERE user_id = ?");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        return [
            'success' => false,
            'message' => 'User is already registered as a trader'
        ];
    }
    
    // Register user as trader
    $stmt = $conn->prepare("INSERT INTO traders (user_id, success_rate, total_trades, profitable_trades, created_at) VALUES (?, 0, 0, 0, NOW())");
    $stmt->bind_param("i", $userId);
    
    if ($stmt->execute()) {
        // Update user role
        $stmt = $conn->prepare("UPDATE users SET role = 'trader' WHERE id = ?");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        
        return [
            'success' => true,
            'message' => 'Successfully registered as a trader'
        ];
    } else {
        return [
            'success' => false,
            'message' => 'Failed to register as a trader'
        ];
    }
}

// Add trade (for traders)
function addTrade($traderId, $symbol, $type, $entryPrice, $exitPrice, $volume, $profit, $profitPercentage) {
    global $conn;
    
    $stmt = $conn->prepare("INSERT INTO trades (trader_id, symbol, type, entry_price, exit_price, volume, profit, profit_percentage, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())");
    $stmt->bind_param("issddddd", $traderId, $symbol, $type, $entryPrice, $exitPrice, $volume, $profit, $profitPercentage);
    
    if ($stmt->execute()) {
        // Update trader statistics
        updateTraderStatistics($traderId);
        
        return [
            'success' => true,
            'message' => 'Trade added successfully'
        ];
    } else {
        return [
            'success' => false,
            'message' => 'Failed to add trade'
        ];
    }
}

// Update trader statistics
function updateTraderStatistics($traderId) {
    global $conn;
    
    // Get all trades for the trader
    $stmt = $conn->prepare("SELECT * FROM trades WHERE trader_id = ?");
    $stmt->bind_param("i", $traderId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $totalTrades = $result->num_rows;
    $profitableTrades = 0;
    
    while ($trade = $result->fetch_assoc()) {
        if ($trade['profit'] > 0) {
            $profitableTrades++;
        }
    }
    
    $successRate = $totalTrades > 0 ? ($profitableTrades / $totalTrades) * 100 : 0;
    
    // Update trader statistics
    $stmt = $conn->prepare("UPDATE traders SET success_rate = ?, total_trades = ?, profitable_trades = ? WHERE user_id = ?");
    $stmt->bind_param("diii", $successRate, $totalTrades, $profitableTrades, $traderId);
    $stmt->execute();
}
?>
