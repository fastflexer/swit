<?php
session_start();
require_once '../config/config.php';
require_once '../includes/functions.php';

$error = '';
$success = '';

// Check if token is provided
if (!isset($_GET['token']) || empty($_GET['token'])) {
    $error = "Invalid verification link";
} else {
    $token = $_GET['token'];
    
    // Check if token exists in database
    $stmt = $conn->prepare("SELECT * FROM users WHERE verification_token = ?");
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();
        
        // Check if email is already verified
        if ($user['email_verified'] == 1) {
            $success = "Your email has already been verified. You can now login.";
        } else {
            // Update user as verified
            $stmt = $conn->prepare("UPDATE users SET email_verified = 1, verification_token = NULL WHERE id = ?");
            $stmt->bind_param("i", $user['id']);
            
            if ($stmt->execute()) {
                $success = "Your email has been verified successfully. You can now login.";
                
                // If referrer exists, add referral bonus
                if ($user['referred_by']) {
                    $referralBonus = 10.00; // $10 bonus
                    
                    // Add bonus to referrer
                    $stmt = $conn->prepare("UPDATE users SET balance = balance + ? WHERE id = ?");
                    $stmt->bind_param("di", $referralBonus, $user['referred_by']);
                    $stmt->execute();
                    
                    // Log the referral bonus
                    $stmt = $conn->prepare("INSERT INTO transactions (user_id, type, amount, description, created_at) VALUES (?, 'referral_bonus', ?, 'Referral bonus for referring " . $user['email'] . "', NOW())");
                    $stmt->bind_param("id", $user['referred_by'], $referralBonus);
                    $stmt->execute();
                }
            } else {
                $error = "Failed to verify email. Please try again.";
            }
        }
    } else {
        $error = "Invalid verification token";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Email Verification - <?php echo APP_NAME; ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/auth.css">
</head>
<body>
    <div class="container">
        <div class="row justify-content-center align-items-center min-vh-100">
            <div class="col-md-6">
                <div class="auth-card">
                    <div class="text-center mb-4">
                        <h2 class="auth-title">Email Verification</h2>
                    </div>
                    
                    <?php if (!empty($error)): ?>
                        <div class="alert alert-danger">
                            <i class="fas fa-exclamation-circle me-2"></i>
                            <?php echo $error; ?>
                        </div>
                        <div class="text-center mt-4">
                            <a href="login.php" class="btn btn-primary">Back to Login</a>
                        </div>
                    <?php endif; ?>
                    
                    <?php if (!empty($success)): ?>
                        <div class="alert alert-success">
                            <i class="fas fa-check-circle me-2"></i>
                            <?php echo $success; ?>
                        </div>
                        <div class="text-center">
                            <div class="verification-icon mb-4">
                                <i class="fas fa-envelope-open-text"></i>
                            </div>
                            <p>Thank you for verifying your email address.</p>
                            <p>You can now access all features of your account.</p>
                            <a href="login.php" class="btn btn-primary btn-lg mt-3">Login to Your Account</a>
                        </div>
                    <?php endif; ?>
                    
                    <div class="text-center mt-4">
                        <p class="small text-muted">© Copyright 2025 JetFx Growth All Rights Reserved.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
