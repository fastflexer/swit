<?php
session_start();
require_once '../config/config.php';
require_once '../includes/auth_check.php';
require_once '../includes/functions.php';

// Check if user is logged in
requireLogin();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['theme'])) {
    $theme = $_POST['theme'];
    
    // Validate theme
    if ($theme !== 'dark' && $theme !== 'light') {
        $theme = 'dark'; // Default to dark if invalid
    }
    
    // Update user's theme preference
    $stmt = $conn->prepare("UPDATE users SET theme = ? WHERE id = ?");
    $stmt->bind_param("si", $theme, $_SESSION['user_id']);
    $stmt->execute();
    
    // Redirect back to settings page
    header("Location: account_settings.php");
    exit();
} else {
    // Redirect if not a POST request
    header("Location: account_settings.php");
    exit();
}
