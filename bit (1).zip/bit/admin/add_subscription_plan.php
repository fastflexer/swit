<?php
require_once '../config/config.php';
require_once '../includes/auth_check.php';
require_once '../includes/admin_check.php';
require_once '../includes/functions.php';

// Process form submission
$message = '';
$messageType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $type = trim($_POST['type']);
    $duration = intval($_POST['duration']);
    $status = trim($_POST['status']);
    
    // Validate inputs
    if (empty($name) || empty($type) || $duration <= 0) {
        $message = 'All fields are required and duration must be greater than 0.';
        $messageType = 'danger';
    } else {
        // Prepare data based on plan type
        if ($type == 'investment') {
            $minAmount = floatval($_POST['min_amount']);
            $maxAmount = floatval($_POST['max_amount']);
            $roiRate = floatval($_POST['roi_rate']);
            $price = 0; // Not used for investment plans
            $features = ''; // Not used for investment plans
            
            if ($minAmount <= 0 || $roiRate <= 0) {
                $message = 'Minimum amount and ROI rate must be greater than 0.';
                $messageType = 'danger';
            } else {
                // Insert investment plan
                $stmt = $conn->prepare("INSERT INTO subscription_plans (name, type, min_amount, max_amount, roi_rate, duration, price, features, status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())");
                $stmt->bind_param("ssddidsss", $name, $type, $minAmount, $maxAmount, $roiRate, $duration, $price, $features, $status);
            }
        } else { // Signal plan
            $price = floatval($_POST['price']);
            $featuresArray = isset($_POST['features']) ? $_POST['features'] : [];
            $features = json_encode($featuresArray);
            $minAmount = 0; // Not used for signal plans
            $maxAmount = 0; // Not used for signal plans
            $roiRate = 0; // Not used for signal plans
            
            if ($price <= 0) {
                $message = 'Price must be greater than 0.';
                $messageType = 'danger';
            } else {
                // Insert signal plan
                $stmt = $conn->prepare("INSERT INTO subscription_plans (name, type, min_amount, max_amount, roi_rate, duration, price, features, status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())");
                $stmt->bind_param("ssddidsss", $name, $type, $minAmount, $maxAmount, $roiRate, $duration, $price, $features, $status);
            }
        }
        
        // Execute query if validation passed
        if (!isset($stmt)) {
            // Do nothing, validation failed
        } elseif ($stmt->execute()) {
            $message = "Subscription plan created successfully!";
            $messageType = 'success';
            
            // Redirect after a short delay
            header("Refresh: 2; URL=manage_subscription_plans.php");
        } else {
            $message = "Error: " . $stmt->error;
            $messageType = 'danger';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Subscription Plan - Admin Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <style>
        .form-container {
            max-width: 800px;
            margin: 0 auto;
        }
        .feature-input-group {
            margin-bottom: 10px;
        }
        @media (max-width: 768px) {
            .feature-controls {
                margin-top: 10px;
            }
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <?php include 'includes/sidebar.php'; ?>
            
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Add Subscription Plan</h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <div class="btn-group me-2">
                            <a href="manage_subscription_plans.php" class="btn btn-sm btn-outline-secondary">Back to Plans</a>
                        </div>
                    </div>
                </div>
                
                <?php if (!empty($message)): ?>
                    <div class="alert alert-<?php echo $messageType; ?> alert-dismissible fade show" role="alert">
                        <?php echo $message; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>
                
                <div class="card mb-4">
                    <div class="card-header">
                        <i class="fas fa-plus-circle me-1"></i>
                        Add New Subscription Plan
                    </div>
                    <div class="card-body">
                        <div class="form-container">
                            <form method="POST" id="planForm">
                                <div class="mb-3">
                                    <label for="name" class="form-label">Plan Name</label>
                                    <input type="text" class="form-control" id="name" name="name" required>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="type" class="form-label">Plan Type</label>
                                    <select class="form-select" id="type" name="type" required>
                                        <option value="">Select a type</option>
                                        <option value="investment">Investment Plan</option>
                                        <option value="signal">Signal Plan</option>
                                    </select>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="duration" class="form-label">Duration (days)</label>
                                    <input type="number" class="form-control" id="duration" name="duration" min="1" required>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="status" class="form-label">Status</label>
                                    <select class="form-select" id="status" name="status" required>
                                        <option value="active">Active</option>
                                        <option value="inactive">Inactive</option>
                                    </select>
                                </div>
                                
                                <!-- Investment Plan Fields -->
                                <div id="investmentFields" style="display: none;">
                                    <div class="mb-3">
                                        <label for="min_amount" class="form-label">Minimum Amount ($)</label>
                                        <input type="number" class="form-control" id="min_amount" name="min_amount" step="0.01" min="0.01">
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="max_amount" class="form-label">Maximum Amount ($)</label>
                                        <input type="number" class="form-control" id="max_amount" name="max_amount" step="0.01" min="0">
                                        <div class="form-text">Enter 0 for unlimited.</div>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="roi_rate" class="form-label">ROI Rate (% daily)</label>
                                        <input type="number" class="form-control" id="roi_rate" name="roi_rate" step="0.01" min="0.01">
                                    </div>
                                </div>
                                
                                <!-- Signal Plan Fields -->
                                <div id="signalFields" style="display: none;">
                                    <div class="mb-3">
                                        <label for="price" class="form-label">Price ($)</label>
                                        <input type="number" class="form-control" id="price" name="price" step="0.01" min="0.01">
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label class="form-label">Features</label>
                                        <div id="featuresContainer">
                                            <div class="feature-input-group row">
                                                <div class="col-md-10">
                                                    <input type="text" class="form-control" name="features[]" placeholder="Enter a feature">
                                                </div>
                                                <div class="col-md-2 feature-controls">
                                                    <button type="button" class="btn btn-danger remove-feature" style="display: none;"><i class="fas fa-trash"></i></button>
                                                </div>
                                            </div>
                                        </div>
                                        <button type="button" class="btn btn-sm btn-secondary mt-2" id="addFeature">Add Feature</button>
                                    </div>
                                </div>
                                
                                <div class="d-grid gap-2 mt-4">
                                    <button type="submit" class="btn btn-primary">Create Plan</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const typeSelect = document.getElementById('type');
            const investmentFields = document.getElementById('investmentFields');
            const signalFields = document.getElementById('signalFields');
            const addFeatureBtn = document.getElementById('addFeature');
            const featuresContainer = document.getElementById('featuresContainer');
            
            // Show/hide fields based on plan type
            typeSelect.addEventListener('change', function() {
                if (this.value === 'investment') {
                    investmentFields.style.display = 'block';
                    signalFields.style.display = 'none';
                } else if (this.value === 'signal') {
                    investmentFields.style.display = 'none';
                    signalFields.style.display = 'block';
                } else {
                    investmentFields.style.display = 'none';
                    signalFields.style.display = 'none';
                }
            });
            
            // Add feature field
            addFeatureBtn.addEventListener('click', function() {
                const featureGroup = document.createElement('div');
                featureGroup.className = 'feature-input-group row mt-2';
                
                featureGroup.innerHTML = `
                    <div class="col-md-10">
                        <input type="text" class="form-control" name="features[]" placeholder="Enter a feature">
                    </div>
                    <div class="col-md-2 feature-controls">
                        <button type="button" class="btn btn-danger remove-feature"><i class="fas fa-trash"></i></button>
                    </div>
                `;
                
                featuresContainer.appendChild(featureGroup);
                
                // Show remove button for the first feature if there are now multiple features
                if (featuresContainer.querySelectorAll('.feature-input-group').length > 1) {
                    const firstRemoveBtn = featuresContainer.querySelector('.remove-feature');
                    if (firstRemoveBtn) {
                        firstRemoveBtn.style.display = 'block';
                    }
                }
            });
            
            // Remove feature field
            featuresContainer.addEventListener('click', function(e) {
                if (e.target.classList.contains('remove-feature') || e.target.parentElement.classList.contains('remove-feature')) {
                    const button = e.target.classList.contains('remove-feature') ? e.target : e.target.parentElement;
                    const featureGroup = button.closest('.feature-input-group');
                    
                    featureGroup.remove();
                    
                    // Hide remove button for the first feature if there's only one left
                    if (featuresContainer.querySelectorAll('.feature-input-group').length === 1) {
                        const firstRemoveBtn = featuresContainer.querySelector('.remove-feature');
                        if (firstRemoveBtn) {
                            firstRemoveBtn.style.display = 'none';
                        }
                    }
                }
            });
            
            // Form validation
            document.getElementById('planForm').addEventListener('submit', function(e) {
                const type = typeSelect.value;
                
                if (type === 'investment') {
                    const minAmount = document.getElementById('min_amount').value;
                    const roiRate = document.getElementById('roi_rate').value;
                    
                    if (!minAmount || minAmount <= 0) {
                        alert('Minimum amount must be greater than 0.');
                        e.preventDefault();
                        return;
                    }
                    
                    if (!roiRate || roiRate <= 0) {
                        alert('ROI rate must be greater than 0.');
                        e.preventDefault();
                        return;
                    }
                } else if (type === 'signal') {
                    const price = document.getElementById('price').value;
                    
                    if (!price || price <= 0) {
                        alert('Price must be greater than 0.');
                        e.preventDefault();
                        return;
                    }
                    
                    const features = document.querySelectorAll('input[name="features[]"]');
                    let hasFeature = false;
                    
                    for (const feature of features) {
                        if (feature.value.trim() !== '') {
                            hasFeature = true;
                            break;
                        }
                    }
                    
                    if (!hasFeature) {
                        alert('Please add at least one feature for the signal plan.');
                        e.preventDefault();
                        return;
                    }
                }
            });
        });
    </script>
</body>
</html>
