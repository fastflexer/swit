<?php
session_start();
require_once '../config/config.php';
require_once '../includes/auth_check.php';
require_once '../includes/functions.php';

// Check if user is logged in
requireLogin();

// Get user data
$user = getUserById($_SESSION['user_id']);

// Get user's theme preference
$theme = $user['theme'] ?? 'dark';

// Get account statistics
$totalBalance = $user['balance'];
$totalDeposits = getTotalDeposits($_SESSION['user_id']);
$totalWithdrawals = getTotalWithdrawals($_SESSION['user_id']);
$totalTrades = getTotalTrades($_SESSION['user_id']);
$openTrades = getOpenTrades($_SESSION['user_id']);
$closedTrades = getClosedTrades($_SESSION['user_id']);
$unreadNotifications = getUnreadNotifications($_SESSION['user_id']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - <?php echo APP_NAME; ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <?php if ($theme === 'dark'): ?>
    <link rel="stylesheet" href="../assets/css/dark-theme.css">
    <?php else: ?>
    <link rel="stylesheet" href="../assets/css/light-theme.css">
    <?php endif; ?>
</head>
<body class="<?php echo $theme; ?>-theme">
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <?php include 'includes/sidebar.php'; ?>
            
            <!-- Main Content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
                <!-- Top Navigation Bar -->
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3">
                    <div class="d-flex align-items-center">
                        <?php if (!empty($user['profile_image'])): ?>
                            <img src="../uploads/profile/<?php echo $user['profile_image']; ?>" alt="Profile" class="rounded-circle me-2" style="width: 40px; height: 40px; object-fit: cover;">
                        <?php else: ?>
                            <div class="rounded-circle bg-secondary text-white d-flex align-items-center justify-content-center me-2" style="width: 40px; height: 40px;">
                                <?php echo strtoupper(substr($user['first_name'], 0, 1)); ?>
                            </div>
                        <?php endif; ?>
                        <div>
                            <h6 class="mb-0"><?php echo $user['first_name'] . ' ' . $user['last_name']; ?></h6>
                            <small class="text-muted"><?php echo $user['email']; ?></small>
                        </div>
                    </div>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <a href="account.php" class="btn btn-sm btn-primary me-2">
                            <i class="fas fa-user-circle"></i> Account
                        </a>
                        <a href="deposit.php" class="btn btn-sm btn-success me-2">
                            <i class="fas fa-money-bill-wave"></i> Make Deposit
                        </a>
                        <a href="withdraw.php" class="btn btn-sm btn-warning me-2">
                            <i class="fas fa-money-bill-transfer"></i> Withdraw Funds
                        </a>
                        <a href="contact.php" class="btn btn-sm btn-info me-2">
                            <i class="fas fa-envelope"></i> Mail Us
                        </a>
                        <a href="settings.php" class="btn btn-sm btn-danger">
                            <i class="fas fa-cog"></i> Settings
                        </a>
                    </div>
                </div>
                
                <!-- Market Ticker -->
                <div class="market-ticker mb-4">
                    <div class="ticker-item">
                        <span class="ticker-symbol">Nasdaq 100:</span>
                        <span class="ticker-value">19,445.4</span>
                        <span class="ticker-change positive">+209.8 (+1.09%)</span>
                    </div>
                    <div class="ticker-item">
                        <span class="ticker-symbol">EUR/USD:</span>
                        <span class="ticker-value">1.13640</span>
                        <span class="ticker-change negative">-0.00220 (-0.19%)</span>
                    </div>
                    <div class="ticker-item">
                        <span class="ticker-symbol">BTC/USD:</span>
                        <span class="ticker-value">93,852</span>
                        <span class="ticker-change negative">-810 (-0.86%)</span>
                    </div>
                    <div class="ticker-item">
                        <span class="ticker-symbol">ETH/USD:</span>
                        <span class="ticker-value">1,901.5</span>
                        <span class="ticker-change positive">+15.5 (+0.82%)</span>
                    </div>
                </div>
                
                <!-- Dashboard Stats -->
                <div class="row mb-4">
                    <div class="col-md-3 mb-3">
                        <div class="card dashboard-card">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="text-muted">TOTAL BALANCE</h6>
                                        <h3 class="mb-0">$<?php echo number_format($totalBalance, 2); ?></h3>
                                    </div>
                                    <div class="dashboard-icon">
                                        <i class="fas fa-wallet fa-2x text-primary"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-3 mb-3">
                        <div class="card dashboard-card">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="text-muted">TOTAL DEPOSITS</h6>
                                        <h3 class="mb-0">$<?php echo number_format($totalDeposits, 2); ?></h3>
                                    </div>
                                    <div class="dashboard-icon">
                                        <i class="fas fa-money-bill-wave fa-2x text-success"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-3 mb-3">
                        <div class="card dashboard-card">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="text-muted">TOTAL TRADES</h6>
                                        <h3 class="mb-0"><?php echo $totalTrades; ?></h3>
                                    </div>
                                    <div class="dashboard-icon">
                                        <i class="fas fa-chart-line fa-2x text-info"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-3 mb-3">
                        <div class="card dashboard-card">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="text-muted">UNREAD NOTIFICATIONS</h6>
                                        <h3 class="mb-0"><?php echo $unreadNotifications; ?></h3>
                                    </div>
                                    <div class="dashboard-icon">
                                        <i class="fas fa-bell fa-2x text-warning"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="row mb-4">
                    <div class="col-md-3 mb-3">
                        <div class="card dashboard-card">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="text-muted">OPEN TRADES</h6>
                                        <h3 class="mb-0"><?php echo $openTrades; ?></h3>
                                    </div>
                                    <div class="dashboard-icon">
                                        <i class="fas fa-exchange-alt fa-2x text-primary"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-3 mb-3">
                        <div class="card dashboard-card">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="text-muted">CLOSED TRADES</h6>
                                        <h3 class="mb-0"><?php echo $closedTrades; ?></h3>
                                    </div>
                                    <div class="dashboard-icon">
                                        <i class="fas fa-check-circle fa-2x text-success"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-3 mb-3">
                        <div class="card dashboard-card">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="text-muted">TOTAL WITHDRAWALS</h6>
                                        <h3 class="mb-0">$<?php echo number_format($totalWithdrawals, 2); ?></h3>
                                    </div>
                                    <div class="dashboard-icon">
                                        <i class="fas fa-money-bill-transfer fa-2x text-danger"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-3 mb-3">
                        <div class="card dashboard-card">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="text-muted">ACCOUNT STATUS</h6>
                                        <h3 class="mb-0">
                                            <span class="badge bg-<?php echo $user['status'] === 'active' ? 'success' : 'danger'; ?>">
                                                <?php echo ucfirst($user['status']); ?>
                                            </span>
                                        </h3>
                                    </div>
                                    <div class="dashboard-icon">
                                        <i class="fas fa-user-shield fa-2x text-info"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Live Trading Chart -->
                <div class="card mb-4">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">Live Trading Chart</h5>
                        <div>
                            <select class="form-select form-select-sm" id="chartSymbol">
                                <option value="EUR/USD">EUR/USD</option>
                                <option value="BTC/USD">BTC/USD</option>
                                <option value="ETH/USD">ETH/USD</option>
                                <option value="GBP/USD">GBP/USD</option>
                            </select>
                        </div>
                    </div>
                    <div class="card-body">
                        <div id="tradingChart" style="height: 400px;">
                            <!-- Trading chart will be loaded here -->
                            <img src="../assets/images/trading-chart.png" alt="Trading Chart" class="img-fluid w-100" style="height: 400px; object-fit: cover;">
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-6 mb-4">
                        <div class="card">
                            <div class="card-header d-flex justify-content-between align-items-center">
                                <h5 class="mb-0">Cryptocurrency Market</h5>
                                <a href="crypto.php" class="btn btn-sm btn-primary">View All</a>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-hover">
                                        <thead>
                                            <tr>
                                                <th>Coin</th>
                                                <th>Price</th>
                                                <th>24h %</th>
                                                <th>Market Cap</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>
                                                    <div class="d-flex align-items-center">
                                                        <img src="../assets/images/bitcoin.png" alt="Bitcoin" width="24" height="24" class="me-2">
                                                        Bitcoin
                                                    </div>
                                                </td>
                                                <td>$93,852</td>
                                                <td class="text-danger">-0.86%</td>
                                                <td>$1.8T</td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    <div class="d-flex align-items-center">
                                                        <img src="../assets/images/ethereum.png" alt="Ethereum" width="24" height="24" class="me-2">
                                                        Ethereum
                                                    </div>
                                                </td>
                                                <td>$1,901.5</td>
                                                <td class="text-success">+0.82%</td>
                                                <td>$228.5B</td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    <div class="d-flex align-items-center">
                                                        <img src="../assets/images/xrp.png" alt="XRP" width="24" height="24" class="me-2">
                                                        XRP
                                                    </div>
                                                </td>
                                                <td>$0.5655</td>
                                                <td class="text-danger">-1.23%</td>
                                                <td>$30.8B</td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    <div class="d-flex align-items-center">
                                                        <img src="../assets/images/solana.png" alt="Solana" width="24" height="24" class="me-2">
                                                        Solana
                                                    </div>
                                                </td>
                                                <td>$146.78</td>
                                                <td class="text-success">+2.45%</td>
                                                <td>$63.2B</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-6 mb-4">
                        <div class="card">
                            <div class="card-header d-flex justify-content-between align-items-center">
                                <h5 class="mb-0">Stock Market Data</h5>
                                <a href="stocks.php" class="btn btn-sm btn-primary">View All</a>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-hover">
                                        <thead>
                                            <tr>
                                                <th>Stock</th>
                                                <th>Price</th>
                                                <th>Change</th>
                                                <th>% Change</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>AAPL</td>
                                                <td>$175.31</td>
                                                <td class="text-success">+1.23</td>
                                                <td class="text-success">+0.71%</td>
                                            </tr>
                                            <tr>
                                                <td>MSFT</td>
                                                <td>$416.38</td>
                                                <td class="text-success">+2.87</td>
                                                <td class="text-success">+0.69%</td>
                                            </tr>
                                            <tr>
                                                <td>GOOGL</td>
                                                <td>$156.37</td>
                                                <td class="text-danger">-0.48</td>
                                                <td class="text-danger">-0.31%</td>
                                            </tr>
                                            <tr>
                                                <td>AMZN</td>
                                                <td>$182.41</td>
                                                <td class="text-success">+1.56</td>
                                                <td class="text-success">+0.86%</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Notification for new investment popup
        setTimeout(function() {
            const randomCountry = ['Sweden', 'South Africa', 'Venezuela', 'Australia', 'Canada', 'Brazil', 'Japan', 'Germany'][Math.floor(Math.random() * 8)];
            const randomAmount = ['$10,000', '$58,623', '$41,000', '$25,750', '$12,300', '$8,500'][Math.floor(Math.random() * 6)];
            
            const notification = document.createElement('div');
            notification.className = 'investment-notification';
            notification.innerHTML = `
                <div class="notification-content">
                    <p>Someone from <strong>${randomCountry}</strong> just <strong>invested ${randomAmount}</strong></p>
                </div>
            `;
            
            document.body.appendChild(notification);
            
            setTimeout(function() {
                notification.classList.add('show');
            }, 100);
            
            setTimeout(function() {
                notification.classList.remove('show');
                setTimeout(function() {
                    document.body.removeChild(notification);
                }, 500);
            }, 5000);
        }, 10000);
    </script>
</body>
</html>
