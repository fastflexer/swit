<?php
session_start();
require_once '../config/config.php';
require_once '../includes/auth_check.php';
require_once '../includes/functions.php';

// Check if user is admin
requireAdmin();
requireOTPVerification();

// Get all trading accounts
$accounts = getAllTradingAccounts();

// Handle account actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action']) && isset($_POST['account_id'])) {
        $action = $_POST['action'];
        $accountId = $_POST['account_id'];
        
        switch ($action) {
            case 'activate':
                $stmt = $conn->prepare("UPDATE trading_accounts SET status = 'active' WHERE id = ?");
                $stmt->bind_param("i", $accountId);
                $stmt->execute();
                header("Location: manage_accounts.php");
                exit();
                break;
                
            case 'deactivate':
                $stmt = $conn->prepare("UPDATE trading_accounts SET status = 'inactive' WHERE id = ?");
                $stmt->bind_param("i", $accountId);
                $stmt->execute();
                header("Location: manage_accounts.php");
                exit();
                break;
                
            case 'delete':
                $stmt = $conn->prepare("DELETE FROM trading_accounts WHERE id = ?");
                $stmt->bind_param("i", $accountId);
                $stmt->execute();
                header("Location: manage_accounts.php");
                exit();
                break;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trading Accounts - <?php echo APP_NAME; ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <?php include 'includes/sidebar.php'; ?>
            
            <!-- Main Content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Trading Accounts</h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <div class="input-group">
                            <input type="text" class="form-control" placeholder="Search...">
                            <button class="btn btn-outline-secondary" type="button">Search</button>
                        </div>
                    </div>
                </div>
                
                <div class="mb-3">
                    <p>Manage trading accounts submitted by users. Collect their submitted details and connect to your master trading account</p>
                </div>
                
                <div class="mb-3">
                    <a href="add_trading_account.php" class="btn btn-primary">Add New Trade</a>
                </div>
                
                <div class="card">
                    <div class="card-header bg-light">
                        <div class="row">
                            <div class="col-md-12 d-flex justify-content-between">
                                <div>
                                    <button class="btn btn-sm btn-secondary">Copy</button>
                                    <button class="btn btn-sm btn-secondary">CSV</button>
                                    <button class="btn btn-sm btn-secondary">Print</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th>USER</th>
                                        <th>Account ID</th>
                                        <th>Account Password</th>
                                        <th>Account Type</th>
                                        <th>Currency</th>
                                        <th>Leverage</th>
                                        <th>Server</th>
                                        <th>Duration</th>
                                        <th>Submitted at</th>
                                        <th>Started at</th>
                                        <th>Expiring at</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (empty($accounts)): ?>
                                    <tr>
                                        <td colspan="13" class="text-center">No data available in table</td>
                                    </tr>
                                    <?php else: ?>
                                    <?php foreach ($accounts as $account): ?>
                                    <tr>
                                        <td><?php echo $account['first_name'] . ' ' . $account['last_name']; ?></td>
                                        <td><?php echo $account['account_id']; ?></td>
                                        <td><?php echo $account['account_password']; ?></td>
                                        <td><?php echo $account['account_type']; ?></td>
                                        <td><?php echo $account['currency']; ?></td>
                                        <td><?php echo $account['leverage']; ?></td>
                                        <td><?php echo $account['server']; ?></td>
                                        <td><?php echo $account['duration']; ?></td>
                                        <td><?php echo date('M j, Y g:i A', strtotime($account['created_at'])); ?></td>
                                        <td><?php echo !empty($account['started_at']) ? date('M j, Y g:i A', strtotime($account['started_at'])) : 'N/A'; ?></td>
                                        <td><?php echo !empty($account['expiry_at']) ? date('M j, Y g:i A', strtotime($account['expiry_at'])) : 'N/A'; ?></td>
                                        <td>
                                            <span class="badge bg-<?php 
                                                echo $account['status'] === 'active' ? 'success' : 
                                                    ($account['status'] === 'pending' ? 'warning' : 'danger'); 
                                            ?>">
                                                <?php echo $account['status']; ?>
                                            </span>
                                        </td>
                                        <td>
                                            <div class="dropdown">
                                                <button class="btn btn-sm btn-secondary dropdown-toggle" type="button" id="actionDropdown<?php echo $account['id']; ?>" data-bs-toggle="dropdown" aria-expanded="false">
                                                    Action
                                                </button>
                                                <ul class="dropdown-menu" aria-labelledby="actionDropdown<?php echo $account['id']; ?>">
                                                    <li>
                                                        <form method="POST" action="">
                                                            <input type="hidden" name="account_id" value="<?php echo $account['id']; ?>">
                                                            <input type="hidden" name="action" value="activate">
                                                            <button type="submit" class="dropdown-item">Activate</button>
                                                        </form>
                                                    </li>
                                                    <li>
                                                        <form method="POST" action="">
                                                            <input type="hidden" name="account_id" value="<?php echo $account['id']; ?>">
                                                            <input type="hidden" name="action" value="deactivate">
                                                            <button type="submit" class="dropdown-item">Deactivate</button>
                                                        </form>
                                                    </li>
                                                    <li>
                                                        <form method="POST" action="">
                                                            <input type="hidden" name="account_id" value="<?php echo $account['id']; ?>">
                                                            <input type="hidden" name="action" value="delete">
                                                            <button type="submit" class="dropdown-item text-danger">Delete</button>
                                                        </form>
                                                    </li>
                                                </ul>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="card-footer">
                        <nav aria-label="Page navigation">
                            <ul class="pagination justify-content-end">
                                <li class="page-item disabled">
                                    <a class="page-link" href="#" tabindex="-1">Previous</a>
                                </li>
                                <li class="page-item active"><a class="page-link" href="#">1</a></li>
                                <li class="page-item"><a class="page-link" href="#">2</a></li>
                                <li class="page-item"><a class="page-link" href="#">3</a></li>
                                <li class="page-item">
                                    <a class="page-link" href="#">Next</a>
                                </li>
                            </ul>
                        </nav>
                    </div>
                </div>
            </main>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
