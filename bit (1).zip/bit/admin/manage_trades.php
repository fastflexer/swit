<?php
session_start();
require_once '../config/config.php';
require_once '../includes/auth_check.php';
require_once '../includes/functions.php';
require_once '../includes/copytrade.php';

// Check if user is admin
requireAdmin();
requireOTPVerification();

// Get all trades
$stmt = $conn->prepare("SELECT t.*, u.first_name, u.last_name FROM trades t JOIN users u ON t.trader_id = u.id ORDER BY t.created_at DESC");
$stmt->execute();
$trades = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Handle trade actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action']) && isset($_POST['trade_id'])) {
        $action = $_POST['action'];
        $tradeId = $_POST['trade_id'];
        
        switch ($action) {
            case 'pause':
                $stmt = $conn->prepare("UPDATE trades SET status = 'paused' WHERE id = ?");
                $stmt->bind_param("i", $tradeId);
                $stmt->execute();
                $_SESSION['success'] = "Trade has been paused successfully";
                break;
                
            case 'resume':
                $stmt = $conn->prepare("UPDATE trades SET status = 'active' WHERE id = ?");
                $stmt->bind_param("i", $tradeId);
                $stmt->execute();
                $_SESSION['success'] = "Trade has been resumed successfully";
                break;
                
            case 'stop':
                $stmt = $conn->prepare("UPDATE trades SET status = 'stopped', closed_at = NOW() WHERE id = ?");
                $stmt->bind_param("i", $tradeId);
                $stmt->execute();
                $_SESSION['success'] = "Trade has been stopped successfully";
                break;
                
            case 'delete':
                $stmt = $conn->prepare("DELETE FROM trades WHERE id = ?");
                $stmt->bind_param("i", $tradeId);
                $stmt->execute();
                $_SESSION['success'] = "Trade has been deleted successfully";
                break;
        }
        
        // Refresh trades
        $stmt = $conn->prepare("SELECT t.*, u.first_name, u.last_name FROM trades t JOIN users u ON t.trader_id = u.id ORDER BY t.created_at DESC");
        $stmt->execute();
        $trades = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Trades - <?php echo APP_NAME; ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <?php include 'includes/sidebar.php'; ?>
            
            <!-- Main Content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Manage Trades</h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <a href="add_trade.php" class="btn btn-sm btn-primary">
                            <i class="fas fa-plus"></i> Add New Trade
                        </a>
                    </div>
                </div>
                
                <?php if (isset($_SESSION['error'])): ?>
                    <div class="alert alert-danger"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
                <?php endif; ?>
                
                <?php if (isset($_SESSION['success'])): ?>
                    <div class="alert alert-success"><?php echo $_SESSION['success']; unset($_SESSION['success']); ?></div>
                <?php endif; ?>
                
                <div class="card">
                    <div class="card-header bg-light">
                        <div class="row">
                            <div class="col-md-12 d-flex justify-content-between">
                                <div>
                                    <button class="btn btn-sm btn-secondary">Copy</button>
                                    <button class="btn btn-sm btn-secondary">CSV</button>
                                    <button class="btn btn-sm btn-secondary">Print</button>
                                </div>
                                <div class="input-group" style="width: 300px;">
                                    <input type="text" class="form-control form-control-sm" placeholder="Search...">
                                    <button class="btn btn-sm btn-outline-secondary" type="button">Search</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th>Trader</th>
                                        <th>Symbol</th>
                                        <th>Type</th>
                                        <th>Entry Price</th>
                                        <th>Exit Price</th>
                                        <th>Volume</th>
                                        <th>Profit/Loss</th>
                                        <th>Status</th>
                                        <th>Date</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (empty($trades)): ?>
                                        <tr>
                                            <td colspan="10" class="text-center">No trades found</td>
                                        </tr>
                                    <?php else: ?>
                                        <?php foreach ($trades as $trade): ?>
                                            <tr>
                                                <td><?php echo $trade['first_name'] . ' ' . $trade['last_name']; ?></td>
                                                <td><?php echo $trade['symbol']; ?></td>
                                                <td><?php echo ucfirst($trade['type']); ?></td>
                                                <td><?php echo $trade['entry_price']; ?></td>
                                                <td><?php echo $trade['exit_price']; ?></td>
                                                <td><?php echo $trade['volume']; ?></td>
                                                <td class="<?php echo $trade['profit'] >= 0 ? 'text-success' : 'text-danger'; ?>">
                                                    <?php echo $trade['profit'] >= 0 ? '+' : ''; ?><?php echo number_format($trade['profit'], 2); ?>
                                                </td>
                                                <td>
                                                    <span class="badge bg-<?php 
                                                        echo $trade['status'] === 'active' ? 'success' : 
                                                            ($trade['status'] === 'paused' ? 'warning' : 'danger'); 
                                                    ?>">
                                                        <?php echo ucfirst($trade['status']); ?>
                                                    </span>
                                                </td>
                                                <td><?php echo date('M j, Y', strtotime($trade['created_at'])); ?></td>
                                                <td>
                                                    <div class="dropdown">
                                                        <button class="btn btn-sm btn-secondary dropdown-toggle" type="button" id="tradeActions<?php echo $trade['id']; ?>" data-bs-toggle="dropdown" aria-expanded="false">
                                                            Actions
                                                        </button>
                                                        <ul class="dropdown-menu" aria-labelledby="tradeActions<?php echo $trade['id']; ?>">
                                                            <li>
                                                                <a class="dropdown-item" href="edit_trade.php?id=<?php echo $trade['id']; ?>">
                                                                    <i class="fas fa-edit"></i> Edit
                                                                </a>
                                                            </li>
                                                            <?php if ($trade['status'] === 'active'): ?>
                                                                <li>
                                                                    <form method="POST" action="">
                                                                        <input type="hidden" name="trade_id" value="<?php echo $trade['id']; ?>">
                                                                        <input type="hidden" name="action" value="pause">
                                                                        <button type="submit" class="dropdown-item">
                                                                            <i class="fas fa-pause"></i> Pause
                                                                        </button>
                                                                    </form>
                                                                </li>
