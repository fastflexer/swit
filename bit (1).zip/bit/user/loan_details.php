<?php
session_start();
require_once '../config/config.php';
require_once '../includes/auth_check.php';
require_once '../includes/functions.php';

// Check if user is logged in
requireLogin();

// Get user data
$user = getUserById($_SESSION['user_id']);

// Get user's theme preference
$theme = $user['theme'] ?? 'dark';

// Check if loan ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    $_SESSION['loan_message'] = "Invalid loan ID.";
    $_SESSION['loan_message_type'] = "danger";
    header("Location: loans.php");
    exit;
}

$loanId = intval($_GET['id']);

// Get loan details
$loan = getLoanById($loanId);

// Check if loan exists and belongs to the user
if (!$loan || $loan['user_id'] != $_SESSION['user_id']) {
    $_SESSION['loan_message'] = "Loan not found or you don't have permission to view it.";
    $_SESSION['loan_message_type'] = "danger";
    header("Location: loans.php");
    exit;
}

// Get loan plan details
$loanPlan = getLoanPlanById($loan['plan_id']);

// Get loan repayment history
$repayments = getLoanRepayments($loanId);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Loan Details - <?php echo APP_NAME; ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <?php if ($theme === 'dark'): ?>
    <link rel="stylesheet" href="../assets/css/dark-theme.css">
    <?php else: ?>
    <link rel="stylesheet" href="../assets/css/light-theme.css">
    <?php endif; ?>
</head>
<body class="<?php echo $theme; ?>-theme">
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <?php include 'includes/sidebar.php'; ?>
            
            <!-- Main Content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Loan Details</h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <a href="loans.php" class="btn btn-secondary">
                            <i class="fas fa-arrow-left me-2"></i>Back to Loans
                        </a>
                        <?php if ($loan['status'] === 'approved'): ?>
                        <a href="repay_loan.php?id=<?php echo $loan['id']; ?>" class="btn btn-success ms-2">
                            <i class="fas fa-money-bill-wave me-2"></i>Repay Loan
                        </a>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Loan Status Card -->
                <div class="row mb-4">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-6">
                                        <h5 class="card-title">Loan #<?php echo $loan['loan_id']; ?></h5>
                                        <div class="loan-status-badge mb-3">
                                            <?php
                                            $statusClass = '';
                                            switch ($loan['status']) {
                                                case 'pending':
                                                    $statusClass = 'bg-warning';
                                                    break;
                                                case 'approved':
                                                    $statusClass = 'bg-success';
                                                    break;
                                                case 'rejected':
                                                    $statusClass = 'bg-danger';
                                                    break;
                                                case 'paid':
                                                    $statusClass = 'bg-info';
                                                    break;
                                                case 'overdue':
                                                    $statusClass = 'bg-danger';
                                                    break;
                                            }
                                            ?>
                                            <span class="badge <?php echo $statusClass; ?> p-2">
                                                <i class="fas fa-circle me-1"></i>
                                                <?php echo ucfirst($loan['status']); ?>
                                            </span>
                                        </div>
                                        <p class="mb-2"><strong>Plan:</strong> <?php echo $loanPlan['name']; ?></p>
                                        <p class="mb-2"><strong>Purpose:</strong> <?php echo $loan['purpose']; ?></p>
                                        <p class="mb-2"><strong>Repayment Source:</strong> <?php echo $loan['repayment_source']; ?></p>
                                        <p class="mb-2"><strong>Applied Date:</strong> <?php echo date('M d, Y', strtotime($loan['created_at'])); ?></p>
                                        <?php if ($loan['status'] === 'approved'): ?>
                                        <p class="mb-2"><strong>Approval Date:</strong> <?php echo date('M d, Y', strtotime($loan['approved_at'])); ?></p>
                                        <p class="mb-2"><strong>Due Date:</strong> <?php echo date('M d, Y', strtotime($loan['due_date'])); ?></p>
                                        <?php endif; ?>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="loan-amount-box text-center p-3 mb-3 rounded" style="background-color: rgba(0,0,0,0.05);">
                                            <h6>Loan Amount</h6>
                                            <h2 class="mb-0">$<?php echo number_format($loan['amount'], 2); ?></h2>
                                        </div>
                                        <div class="row">
                                            <div class="col-6">
                                                <p class="mb-2"><strong>Interest Rate:</strong> <?php echo $loanPlan['interest_rate']; ?>%</p>
                                                <p class="mb-2"><strong>Interest Amount:</strong> $<?php echo number_format($loan['interest_amount'], 2); ?></p>
                                                <p class="mb-2"><strong>Processing Fee:</strong> $<?php echo number_format($loan['processing_fee'], 2); ?></p>
                                            </div>
                                            <div class="col-6">
                                                <p class="mb-2"><strong>Duration:</strong> <?php echo $loan['duration']; ?> days</p>
                                                <p class="mb-2"><strong>Total Repayment:</strong> $<?php echo number_format($loan['total_repayment'], 2); ?></p>
                                                <p class="mb-2"><strong>Amount Paid:</strong> $<?php echo number_format($loan['amount_paid'], 2); ?></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Repayment Schedule -->
                <?php if ($loan['status'] === 'approved' || $loan['status'] === 'paid' || $loan['status'] === 'overdue'): ?>
                <div class="card mb-4">
                    <div class="card-header">
                        <h5 class="mb-0">Repayment Schedule</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Due Date</th>
                                        <th>Amount Due</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td><?php echo date('M d, Y', strtotime($loan['due_date'])); ?></td>
                                        <td>$<?php echo number_format($loan['total_repayment'], 2); ?></td>
                                        <td>
                                            <?php if ($loan['status'] === 'paid'): ?>
                                            <span class="badge bg-success">Paid</span>
                                            <?php elseif ($loan['status'] === 'overdue'): ?>
                                            <span class="badge bg-danger">Overdue</span>
                                            <?php else: ?>
                                            <span class="badge bg-warning">Pending</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
                
                <!-- Repayment History -->
                <?php if (!empty($repayments)): ?>
                <div class="card mb-4">
                    <div class="card-header">
                        <h5 class="mb-0">Repayment History</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Date</th>
                                        <th>Amount</th>
                                        <th>Payment Method</th>
                                        <th>Transaction ID</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($repayments as $repayment): ?>
                                    <tr>
                                        <td><?php echo date('M d, Y', strtotime($repayment['created_at'])); ?></td>
                                        <td>$<?php echo number_format($repayment['amount'], 2); ?></td>
                                        <td><?php echo $repayment['payment_method']; ?></td>
                                        <td><?php echo $repayment['transaction_id']; ?></td>
                                        <td>
                                            <span class="badge bg-<?php echo $repayment['status'] === 'confirmed' ? 'success' : 'warning'; ?>">
                                                <?php echo ucfirst($repayment['status']); ?>
                                            </span>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
                
                <!-- Loan Comments -->
                <?php if (!empty($loan['admin_comment'])): ?>
                <div class="card mb-4">
                    <div class="card-header">
                        <h5 class="mb-0">Admin Comments</h5>
                    </div>
                    <div class="card-body">
                        <div class="admin-comment p-3 rounded" style="background-color: rgba(0,0,0,0.05);">
                            <p class="mb-0"><?php echo nl2br($loan['admin_comment']); ?></p>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            </main>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
