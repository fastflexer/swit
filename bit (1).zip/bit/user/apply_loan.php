<?php
session_start();
require_once '../config/config.php';
require_once '../includes/auth_check.php';
require_once '../includes/functions.php';

// Check if user is logged in
requireLogin();

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate inputs
    $loanPlanId = isset($_POST['loan_plan']) ? intval($_POST['loan_plan']) : 0;
    $loanAmount = isset($_POST['loan_amount']) ? floatval($_POST['loan_amount']) : 0;
    $purpose = isset($_POST['purpose']) ? trim($_POST['purpose']) : '';
    $otherPurpose = isset($_POST['other_purpose']) ? trim($_POST['other_purpose']) : '';
    $repaymentSource = isset($_POST['repayment_source']) ? trim($_POST['repayment_source']) : '';
    $otherSource = isset($_POST['other_source']) ? trim($_POST['other_source']) : '';
    $agreeTerms = isset($_POST['agree_terms']) ? true : false;
    
    // Validate required fields
    $errors = [];
    
    if (empty($loanPlanId)) {
        $errors[] = "Loan plan is required.";
    }
    
    if (empty($loanAmount) || $loanAmount <= 0) {
        $errors[] = "Valid loan amount is required.";
    }
    
    if (empty($purpose)) {
        $errors[] = "Purpose is required.";
    } else if ($purpose === 'Other' && empty($otherPurpose)) {
        $errors[] = "Please specify the purpose of the loan.";
    }
    
    if (empty($repaymentSource)) {
        $errors[] = "Source of repayment is required.";
    } else if ($repaymentSource === 'Other' && empty($otherSource)) {
        $errors[] = "Please specify the source of repayment.";
    }
    
    if (!$agreeTerms) {
        $errors[] = "You must agree to the terms and conditions.";
    }
    
    // If no errors, proceed with loan application
    if (empty($errors)) {
        // Get loan plan details
        $loanPlan = getLoanPlanById($loanPlanId);
        
        if (!$loanPlan) {
            $_SESSION['loan_message'] = "Invalid loan plan selected.";
            $_SESSION['loan_message_type'] = "danger";
            header("Location: loans.php");
            exit;
        }
        
        // Validate loan amount against plan limits
        if ($loanAmount < $loanPlan['min_amount'] || $loanAmount > $loanPlan['max_amount']) {
            $_SESSION['loan_message'] = "Loan amount must be between $" . number_format($loanPlan['min_amount'], 2) . " and $" . number_format($loanPlan['max_amount'], 2) . ".";
            $_SESSION['loan_message_type'] = "danger";
            header("Location: loans.php");
            exit;
        }
        
        // Get user data
        $user = getUserById($_SESSION['user_id']);
        
        // Calculate loan details
        $interestRate = $loanPlan['interest_rate'];
        $duration = $loanPlan['duration'];
        $processingFeeRate = $loanPlan['processing_fee'];
        $processingFee = ($loanAmount * $processingFeeRate) / 100;
        $interestAmount = ($loanAmount * $interestRate * $duration) / (100 * 365);
        $totalRepayment = $loanAmount + $interestAmount;
        
        // Format purpose and repayment source
        $finalPurpose = ($purpose === 'Other') ? $otherPurpose : $purpose;
        $finalRepaymentSource = ($repaymentSource === 'Other') ? $otherSource : $repaymentSource;
        
        // Generate unique loan ID
        $loanId = generateLoanId();
        
        // Insert loan application into database
        $result = applyForLoan(
            $_SESSION['user_id'],
            $loanPlanId,
            $loanAmount,
            $interestAmount,
            $totalRepayment,
            $processingFee,
            $duration,
            $finalPurpose,
            $finalRepaymentSource,
            $loanId
        );
        
        if ($result) {
            // Send email notification
            $loanDetails = [
                'loan_id' => $loanId,
                'amount' => $loanAmount,
                'interest_amount' => $interestAmount,
                'total_repayment' => $totalRepayment,
                'processing_fee' => $processingFee,
                'duration' => $duration,
                'purpose' => $finalPurpose,
                'repayment_source' => $finalRepaymentSource,
                'plan_name' => $loanPlan['name'],
                'created_at' => date('Y-m-d H:i:s')
            ];
            
            sendLoanApplicationNotification($user, $loanDetails);
            
            $_SESSION['loan_message'] = "Your loan application has been submitted successfully. Application ID: " . $loanId;
            $_SESSION['loan_message_type'] = "success";
        } else {
            $_SESSION['loan_message'] = "Failed to submit loan application. Please try again.";
            $_SESSION['loan_message_type'] = "danger";
        }
    } else {
        // If there are errors, set error message
        $_SESSION['loan_message'] = "Please correct the following errors: " . implode(" ", $errors);
        $_SESSION['loan_message_type'] = "danger";
    }
    
    // Redirect back to loans page
    header("Location: loans.php");
    exit;
} else {
    // If not POST request, redirect to loans page
    header("Location: loans.php");
    exit;
}
?>
