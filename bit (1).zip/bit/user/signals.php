<?php
require_once '../config/config.php';
require_once '../includes/auth_check.php';
require_once '../includes/functions.php';

// Get user information
$userId = $_SESSION['user_id'];
$user = getUserById($userId);

// Get signal plans
$stmt = $conn->prepare("SELECT * FROM subscription_plans WHERE type = 'signal' ORDER BY price ASC");
$stmt->execute();
$signalPlans = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Get user's active signal subscriptions
$stmt = $conn->prepare("SELECT s.*, p.name as plan_name, p.features FROM subscriptions s JOIN subscription_plans p ON s.plan_id = p.id WHERE s.user_id = ? AND s.status = 'active' AND p.type = 'signal' ORDER BY s.created_at DESC");
$stmt->bind_param("i", $userId);
$stmt->execute();
$activeSignals = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Process subscription
$message = '';
$messageType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['plan_id'])) {
    $planId = intval($_POST['plan_id']);
    
    // Get plan details
    $stmt = $conn->prepare("SELECT * FROM subscription_plans WHERE id = ? AND type = 'signal'");
    $stmt->bind_param("i", $planId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        $message = 'Invalid plan selected.';
        $messageType = 'danger';
    } else {
        $plan = $result->fetch_assoc();
        
        // Check if user already has an active subscription to this plan
        $stmt = $conn->prepare("SELECT * FROM subscriptions WHERE user_id = ? AND plan_id = ? AND status = 'active'");
        $stmt->bind_param("ii", $userId, $planId);
        $stmt->execute();
        $existingSubscription = $stmt->get_result()->fetch_assoc();
        
        if ($existingSubscription) {
            $message = 'You already have an active subscription to this plan.';
            $messageType = 'warning';
        } elseif ($plan['price'] > $user['balance']) {
            $message = 'Insufficient balance to subscribe to this plan.';
            $messageType = 'danger';
        } else {
            // Start transaction
            $conn->begin_transaction();
            
            try {
                // Deduct amount from user balance
                $stmt = $conn->prepare("UPDATE users SET balance = balance - ? WHERE id = ?");
                $stmt->bind_param("di", $plan['price'], $userId);
                $stmt->execute();
                
                // Calculate end date based on duration
                $endDate = date('Y-m-d H:i:s', strtotime('+' . $plan['duration'] . ' days'));
                
                // Insert subscription
                $stmt = $conn->prepare("INSERT INTO subscriptions (user_id, plan_id, amount, start_date, end_date, status, created_at) VALUES (?, ?, ?, NOW(), ?, 'active', NOW())");
                $stmt->bind_param("iids", $userId, $planId, $plan['price'], $endDate);
                $stmt->execute();
                
                // Commit transaction
                $conn->commit();
                
                $message = 'Subscription successful! Your signal plan is now active.';
                $messageType = 'success';
                
                // Refresh page to show updated data
                header("Refresh: 2");
            } catch (Exception $e) {
                // Rollback transaction on error
                $conn->rollback();
                $message = 'Error processing subscription: ' . $e->getMessage();
                $messageType = 'danger';
            }
        }
    }
}

// Get recent signals
$stmt = $conn->prepare("
    SELECT s.*, p.name as plan_name 
    FROM signals s 
    JOIN subscription_plans p ON s.plan_id = p.id 
    WHERE s.plan_id IN (
        SELECT plan_id FROM subscriptions WHERE user_id = ? AND status = 'active' AND end_date > NOW()
    )
    ORDER BY s.created_at DESC 
    LIMIT 10
");
$stmt->bind_param("i", $userId);
$stmt->execute();
$recentSignals = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trading Signals - JetFx Growth</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        .signal-plan-card {
            border-radius: 10px;
            overflow: hidden;
            transition: transform 0.3s ease;
            height: 100%;
        }
        .signal-plan-card:hover {
            transform: translateY(-5px);
        }
        .signal-plan-header {
            padding: 20px;
            text-align: center;
            color: white;
        }
        .signal-plan-price {
            font-size: 2rem;
            font-weight: bold;
        }
        .signal-plan-features {
            padding: 20px;
        }
        .signal-plan-feature {
            margin-bottom: 10px;
        }
        .alpha-plan {
            background-color: #3498db;
        }
        .titan-plan {
            background-color: #2ecc71;
        }
        .quantum-plan {
            background-color: #9b59b6;
        }
        .elite-plan {
            background-color: #e74c3c;
        }
        .velocity-plan {
            background-color: #f39c12;
        }
        .apex-plan {
            background-color: #1abc9c;
        }
        .genesis-plan {
            background-color: #8e44ad;
        }
        .legendary-plan {
            background-color: #c0392b;
        }
        .signal-item {
            border-left: 4px solid var(--primary-color);
            padding-left: 15px;
            margin-bottom: 20px;
        }
        .signal-meta {
            font-size: 0.85rem;
            color: var(--secondary-color);
        }
        @media (max-width: 768px) {
            .signal-plan-cards {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <?php include 'includes/sidebar.php'; ?>
            
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Trading Signals</h1>
                </div>
                
                <?php if (!empty($message)): ?>
                    <div class="alert alert-<?php echo $messageType; ?> alert-dismissible fade show" role="alert">
                        <?php echo $message; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>
                
                <?php if (empty($activeSignals)): ?>
                    <div class="alert alert-info mb-4">
                        <h5>Subscribe to a Signal Plan</h5>
                        <p>You don't have any active signal subscriptions. Choose a plan below to start receiving trading signals.</p>
                    </div>
                <?php else: ?>
                    <div class="card mb-4">
                        <div class="card-header">
                            <h5 class="mb-0">Your Active Signal Subscriptions</h5>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <?php foreach ($activeSignals as $subscription): ?>
                                    <div class="col-md-6 col-lg-4 mb-3">
                                        <div class="card h-100">
                                            <div class="card-body">
                                                <h5 class="card-title"><?php echo htmlspecialchars($subscription['plan_name']); ?></h5>
                                                <p class="card-text">
                                                    <small class="text-muted">
                                                        Expires: <?php echo date('M j, Y', strtotime($subscription['end_date'])); ?>
                                                    </small>
                                                </p>
                                                <p class="card-text">
                                                    <?php 
                                                    $features = json_decode($subscription['features'], true);
                                                    if (is_array($features)) {
                                                        echo '<ul class="mb-0 ps-3">';
                                                        foreach ($features as $feature) {
                                                            echo '<li>' . htmlspecialchars($feature) . '</li>';
                                                        }
                                                        echo '</ul>';
                                                    }
                                                    ?>
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                    
                    <?php if (!empty($recentSignals)): ?>
                        <div class="card mb-4">
                            <div class="card-header">
                                <h5 class="mb-0">Recent Signals</h5>
                            </div>
                            <div class="card-body">
                                <?php foreach ($recentSignals as $signal): ?>
                                    <div class="signal-item">
                                        <h5><?php echo htmlspecialchars($signal['title']); ?></h5>
                                        <div class="signal-meta mb-2">
                                            <span class="me-3"><i class="fas fa-layer-group me-1"></i> <?php echo htmlspecialchars($signal['plan_name']); ?></span>
                                            <span class="me-3"><i class="fas fa-calendar-alt me-1"></i> <?php echo date('M j, Y H:i', strtotime($signal['created_at'])); ?></span>
                                            <span><i class="fas fa-chart-line me-1"></i> <?php echo htmlspecialchars($signal['pair']); ?></span>
                                        </div>
                                        <div class="row mb-2">
                                            <div class="col-md-6">
                                                <strong>Entry:</strong> <?php echo htmlspecialchars($signal['entry_price']); ?>
                                            </div>
                                            <div class="col-md-6">
                                                <strong>Direction:</strong> 
                                                <?php if ($signal['direction'] == 'buy'): ?>
                                                    <span class="text-success">BUY</span>
                                                <?php else: ?>
                                                    <span class="text-danger">SELL</span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="row mb-2">
                                            <div class="col-md-6">
                                                <strong>Take Profit:</strong> <?php echo htmlspecialchars($signal['take_profit']); ?>
                                            </div>
                                            <div class="col-md-6">
                                                <strong>Stop Loss:</strong> <?php echo htmlspecialchars($signal['stop_loss']); ?>
                                            </div>
                                        </div>
                                        <?php if (!empty($signal['notes'])): ?>
                                            <div class="mt-2">
                                                <strong>Notes:</strong> <?php echo nl2br(htmlspecialchars($signal['notes'])); ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
                
                <h3 class="mb-4">Subscribe to a Signal Plan</h3>
                
                <div class="alert alert-info">
                    <strong>Your Balance:</strong> $<?php echo number_format($user['balance'], 2); ?>
                </div>
                
                <div class="row row-cols-1 row-cols-md-2 row-cols-xl-4 g-4 signal-plan-cards">
                    <?php 
                    $planClasses = ['alpha-plan', 'titan-plan', 'quantum-plan', 'elite-plan', 'velocity-plan', 'apex-plan', 'genesis-plan', 'legendary-plan'];
                    $planIndex = 0;
                    
                    foreach ($signalPlans as $plan): 
                        $planClass = $planClasses[$planIndex % count($planClasses)];
                        $planIndex++;
                        
                        // Check if user already has this plan
                        $hasActivePlan = false;
                        foreach ($activeSignals as $activePlan) {
                            if ($activePlan['plan_id'] == $plan['id']) {
                                $hasActivePlan = true;
                                break;
                            }
                        }
                        
                        // Decode features
                        $features = json_decode($plan['features'], true);
                    ?>
                        <div class="col">
                            <div class="card signal-plan-card h-100">
                                <div class="signal-plan-header <?php echo $planClass; ?>">
                                    <h3><?php echo htmlspecialchars($plan['name']); ?></h3>
                                    <div class="signal-plan-price">$<?php echo number_format($plan['price'], 0); ?></div>
                                    <p>Duration: <?php echo $plan['duration']; ?> Days</p>
                                </div>
                                <div class="card-body signal-plan-features">
                                    <?php if (is_array($features)): ?>
                                        <ul class="list-unstyled">
                                            <?php foreach ($features as $feature): ?>
                                                <li class="signal-plan-feature">
                                                    <i class="fas fa-check-circle text-success me-2"></i> <?php echo htmlspecialchars($feature); ?>
                                                </li>
                                            <?php endforeach; ?>
                                        </ul>
                                    <?php endif; ?>
                                    
                                    <form method="POST" class="mt-3">
                                        <input type="hidden" name="plan_id" value="<?php echo $plan['id']; ?>">
                                        <?php if ($hasActivePlan): ?>
                                            <button type="button" class="btn btn-secondary w-100" disabled>Already Subscribed</button>
                                        <?php else: ?>
                                            <button type="submit" class="btn btn-primary w-100">Subscribe Now</button>
                                        <?php endif; ?>
                                    </form>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
                
                <?php if (empty($signalPlans)): ?>
                    <div class="alert alert-info mt-4">No signal plans available at the moment.</div>
                <?php endif; ?>
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
