<?php
session_start();
require_once '../config/config.php';
require_once '../includes/auth_check.php';
require_once '../includes/functions.php';
require_once '../includes/copytrade.php';

// Check if user is admin
requireAdmin();
requireOTPVerification();

// Get all traders
$stmt = $conn->prepare("SELECT u.id, u.first_name, u.last_name FROM users u WHERE u.role = 'trader' AND u.status = 'active'");
$stmt->execute();
$traders = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Pre-select trader if trader_id is provided in URL
$selectedTraderId = $_GET['trader_id'] ?? null;

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $traderId = $_POST['trader_id'] ?? '';
    $symbol = $_POST['symbol'] ?? '';
    $type = $_POST['type'] ?? '';
    $entryPrice = $_POST['entry_price'] ?? '';
    $exitPrice = $_POST['exit_price'] ?? '';
    $volume = $_POST['volume'] ?? '';
    $profit = $_POST['profit'] ?? '';
    $profitPercentage = $_POST['profit_percentage'] ?? '';
    $status = $_POST['status'] ?? 'active';
    
    // Validate input
    if (empty($traderId) || empty($symbol) || empty($type) || empty($entryPrice) || empty($exitPrice) || empty($volume) || !isset($profit) || !isset($profitPercentage)) {
        $error = "All required fields must be filled";
    } else {
        // Insert trade
        $stmt = $conn->prepare("INSERT INTO trades (trader_id, symbol, type, entry_price, exit_price, volume, profit, profit_percentage, status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())");
        $stmt->bind_param("issdddds", $traderId, $symbol, $type, $entryPrice, $exitPrice, $volume, $profit, $profitPercentage, $status);
        
        if ($stmt->execute()) {
            // Update trader statistics
            updateTraderStatistics($traderId);
            
            $success = "Trade added successfully";
        } else {
            $error = "Failed to add trade: " . $conn->error;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Trade - <?php echo APP_NAME; ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <?php include 'includes/sidebar.php'; ?>
            
            <!-- Main Content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Add New Trade</h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <?php if ($selectedTraderId): ?>
                            <a href="trader_details.php?id=<?php echo $selectedTraderId; ?>" class="btn btn-sm btn-outline-secondary">
                                <i class="fas fa-arrow-left"></i> Back to Trader
                            </a>
                        <?php else: ?>
                            <a href="manage_trades.php" class="btn btn-sm btn-outline-secondary">
                                <i class="fas fa-arrow-left"></i> Back
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
                
                <?php if (!empty($error)): ?>
                    <div class="alert alert-danger"><?php echo $error; ?></div>
                <?php endif; ?>
                
                <?php if (!empty($success)): ?>
                    <div class="alert alert-success"><?php echo $success; ?></div>
                <?php endif; ?>
                
                <div class="card">
                    <div class="card-body">
                        <form method="POST" action="">
                            <div class="mb-3">
                                <label for="trader_id" class="form-label">Trader <span class="text-danger">*</span></label>
                                <select class="form-select" id="trader_id" name="trader_id" required>
                                    <option value="">Select Trader</option>
                                    <?php foreach ($traders as $trader): ?>
                                        <option value="<?php echo $trader['id']; ?>" <?php echo $selectedTraderId == $trader['id'] ? 'selected' : ''; ?>>
                                            <?php echo $trader['first_name'] . ' ' . $trader['last_name']; ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <label for="symbol" class="form-label">Symbol <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="symbol" name="symbol" placeholder="e.g. EURUSD, BTCUSD" required>
                                </div>
                                <div class="col-md-6">
                                    <label for="type" class="form-label">Type <span class="text-danger">*</span></label>
                                    <select class="form-select" id="type" name="type" required>
                                        <option value="buy">Buy</option>
                                        <option value="sell">Sell</option>
                                    </select>
                                </div>
                            </div>
                            
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <label for="entry_price" class="form-label">Entry Price <span class="text-danger">*</span></label>
                                    <input type="number" class="form-control" id="entry_price" name="entry_price" step="0.00001" required>
                                </div>
                                <div class="col-md-6">
                                    <label for="exit_price" class="form-label">Exit Price <span class="text-danger">*</span></label>
                                    <input type="number" class="form-control" id="exit_price" name="exit_price" step="0.00001" required>
                                </div>
                            </div>
                            
                            <div class="row mb-3">
                                <div class="col-md-4">
                                    <label for="volume" class="form-label">Volume <span class="text-danger">*</span></label>
                                    <input type="number" class="form-control" id="volume" name="volume" step="0.01" required>
                                </div>
                                <div class="col-md-4">
                                    <label for="profit" class="form-label">Profit/Loss <span class="text-danger">*</span></label>
                                    <input type="number" class="form-control" id="profit" name="profit" step="0.01" required>
                                </div>
                                <div class="col-md-4">
                                    <label for="profit_percentage" class="form-label">Profit Percentage <span class="text-danger">*</span></label>
                                    <input type="number" class="form-control" id="profit_percentage" name="profit_percentage" step="0.01" required>
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label for="status" class="form-label">Status</label>
                                <select class="form-select" id="status" name="status">
                                    <option value="active" selected>Active</option>
                                    <option value="paused">Paused</option>
                                    <option value="stopped">Stopped</option>
                                </select>
                            </div>
                            
                            <div class="d-grid gap-2">
                                <button type="submit" class="btn btn-primary">Add Trade</button>
                            </div>
                        </form>
                    </div>
                </div>
            </main>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Calculate profit and profit percentage automatically
        document.addEventListener('DOMContentLoaded', function() {
            const entryPriceInput = document.getElementById('entry_price');
            const exitPriceInput = document.getElementById('exit_price');
            const volumeInput = document.getElementById('volume');
            const profitInput = document.getElementById('profit');
            const profitPercentageInput = document.getElementById('profit_percentage');
            const typeSelect = document.getElementById('type');
            
            function calculateProfit() {
                const entryPrice = parseFloat(entryPriceInput.value) || 0;
                const exitPrice = parseFloat(exitPriceInput.value) || 0;
                const volume = parseFloat(volumeInput.value) || 0;
                const type = typeSelect.value;
                
                let profit = 0;
                let profitPercentage = 0;
                
                if (entryPrice > 0 && exitPrice > 0 && volume > 0) {
                    if (type === 'buy') {
                        profit = (exitPrice - entryPrice) * volume;
                        profitPercentage = ((exitPrice - entryPrice) / entryPrice) * 100;
                    } else { // sell
                        profit = (entryPrice - exitPrice) * volume;
                        profitPercentage = ((entryPrice - exitPrice) / entryPrice) * 100;
                    }
                }
                
                profitInput.value = profit.toFixed(2);
                profitPercentageInput.value = profitPercentage.toFixed(2);
            }
            
            entryPriceInput.addEventListener('input', calculateProfit);
            exitPriceInput.addEventListener('input', calculateProfit);
            volumeInput.addEventListener('input', calculateProfit);
            typeSelect.addEventListener('change', calculateProfit);
        });
    </script>
</body>
</html>
