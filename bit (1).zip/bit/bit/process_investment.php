<?php
session_start();
require_once '../config/database.php';

if (!isset($_SESSION['user_id']) || $_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: index.php');
    exit();
}

$userId = $_SESSION['user_id'];
$amount = filter_input(INPUT_POST, 'amount', FILTER_VALIDATE_FLOAT);

if ($amount < 100) {
    $_SESSION['error'] = "Minimum investment amount is $100";
    header('Location: index.php');
    exit();
}

try {
    $stmt = $pdo->prepare("INSERT INTO investments (user_id, amount, investment_type, status) VALUES (?, ?, 'bitcoin', 'pending')");
    $stmt->execute([$userId, $amount]);

    $_SESSION['success'] = "Investment request submitted successfully";
} catch (PDOException $e) {
    $_SESSION['error'] = "Failed to process investment";
}

header('Location: index.php');
exit();
?>