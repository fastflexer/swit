<?php
session_start();
require_once '../config/config.php';
require_once '../includes/auth_check.php';
require_once '../includes/functions.php';

// Check if user is logged in
requireLogin();
requireOTPVerification();

// Get user data
$user = getUserById($_SESSION['user_id']);

// Get investment plans
$stmt = $conn->prepare("SELECT * FROM investment_plans WHERE status = 'active' ORDER BY min_amount ASC");
$stmt->execute();
$investmentPlans = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Get user's investments
$stmt = $conn->prepare("SELECT i.*, p.name as plan_name, p.roi, p.duration FROM investments i JOIN investment_plans p ON i.plan_id = p.id WHERE i.user_id = ? ORDER BY i.created_at DESC");
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$investments = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

$error = '';
$success = '';

// Handle investment submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $planId = $_POST['plan_id'] ?? 0;
    $amount = $_POST['amount'] ?? 0;
    
    // Validate input
    if (empty($planId) || !is_numeric($planId)) {
        $error = "Please select a valid investment plan";
    } elseif (empty($amount) || !is_numeric($amount) || $amount <= 0) {
        $error = "Please enter a valid amount";
    } else {
        // Get plan details
        $stmt = $conn->prepare("SELECT * FROM investment_plans WHERE id = ?");
        $stmt->bind_param("i", $planId);
        $stmt->execute();
        $plan = $stmt->get_result()->fetch_assoc();
        
        if (!$plan) {
            $error = "Selected investment plan does not exist";
        } elseif ($amount < $plan['min_amount']) {
            $error = "Minimum investment amount for this plan is $" . number_format($plan['min_amount'], 2);
        } elseif ($amount > $plan['max_amount']) {
            $error = "Maximum investment amount for this plan is $" . number_format($plan['max_amount'], 2);
        } elseif ($amount > $user['balance']) {
            $error = "Insufficient balance. Your current balance is $" . number_format($user['balance'], 2);
        } else {
            // Deduct amount from user's balance
            $stmt = $conn->prepare("UPDATE users SET balance = balance - ? WHERE id = ?");
            $stmt->bind_param("di", $amount, $_SESSION['user_id']);
            $stmt->execute();
            
            // Insert investment
            $stmt = $conn->prepare("INSERT INTO investments (user_id, plan_id, amount, status, created_at) VALUES (?, ?, ?, 'active', NOW())");
            $stmt->bind_param("iid", $_SESSION['user_id'], $planId, $amount);
            
            if ($stmt->execute()) {
                $success = "Investment created successfully";
                
                // Refresh user data and investments
                $user = getUserById($_SESSION['user_id']);
                $stmt = $conn->prepare("SELECT i.*, p.name as plan_name, p.roi, p.duration FROM investments i JOIN investment_plans p ON i.plan_id = p.id WHERE i.user_id = ? ORDER BY i.created_at DESC");
                $stmt->bind_param("i", $_SESSION['user_id']);
                $stmt->execute();
                $investments = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
            } else {
                $error = "Failed to create investment. Please try again.";
                
                // Refund the amount
                $stmt = $conn->prepare("UPDATE users SET balance = balance + ? WHERE id = ?");
                $stmt->bind_param("di", $amount, $_SESSION['user_id']);
                $stmt->execute();
            }
        }
    }
}

// Calculate statistics
$totalInvested = 0;
$activeInvestments = 0;
$totalReturns = 0;

foreach ($investments as $investment) {
    $totalInvested += $investment['amount'];
    
    if ($investment['status'] === 'active') {
        $activeInvestments++;
        
        // Calculate expected returns
        $expectedReturn = $investment['amount'] * ($investment['roi'] / 100);
        $totalReturns += $expectedReturn;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Investments - <?php echo APP_NAME; ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <?php include 'includes/sidebar.php'; ?>
            
            <!-- Main Content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Investments</h1>
                </div>
                
                <?php if (!empty($error)): ?>
                    <div class="alert alert-danger"><?php echo $error; ?></div>
                <?php endif; ?>
                
                <?php if (!empty($success)): ?>
                    <div class="alert alert-success"><?php echo $success; ?></div>
                <?php endif; ?>
                
                <div class="row mb-4">
                    <div class="col-md-4">
                        <div class="card bg-primary text-white">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="card-title">Total Invested</h6>
                                        <h2 class="card-text">$<?php echo number_format($totalInvested, 2); ?></h2>
                                    </div>
                                    <i class="fas fa-money-bill-trend-up fa-2x"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-4">
                        <div class="card bg-success text-white">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="card-title">Active Investments</h6>
                                        <h2 class="card-text"><?php echo $activeInvestments; ?></h2>
                                    </div>
                                    <i class="fas fa-chart-line fa-2x"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-4">
                        <div class="card bg-info text-white">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="card-title">Expected Returns</h6>
                                        <h2 class="card-text">$<?php echo number_format($totalReturns, 2); ?></h2>
                                    </div>
                                    <i class="fas fa-hand-holding-dollar fa-2x"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-4 mb-4">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="mb-0">New Investment</h5>
                            </div>
                            <div class="card-body">
                                <div class="alert alert-info">
                                    <strong>Available Balance:</strong> $<?php echo number_format($user['balance'], 2); ?>
                                </div>
                                
                                <form method="POST" action="">
                                    <div class="mb-3">
                                        <label for="plan_id" class="form-label">Investment Plan</label>
                                        <select class="form-select" id="plan_id" name="plan_id" required onchange="updateAmountLimits()">
                                            <option value="">Select Investment Plan</option>
                                            <?php foreach ($investmentPlans as $plan): ?>
                                                <option value="<?php echo $plan['id']; ?>" data-min="<?php echo $plan['min_amount']; ?>" data-max="<?php echo $plan['max_amount']; ?>">
                                                    <?php echo $plan['name']; ?> (<?php echo $plan['roi']; ?>% ROI, <?php echo $plan['duration']; ?> days)
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="amount" class="form-label">Amount</label>
                                        <div class="input-group">
                                            <span class="input-group-text">$</span>
                                            <input type="number" class="form-control" id="amount" name="amount" min="0" step="0.01" max="<?php echo $user['balance']; ?>" required>
                                        </div>
                                        <div class="form-text" id="amount-limits"></div>
                                    </div>
                                    
                                    <div class="d-grid">
                                        <button type="submit" class="btn btn-primary">Create Investment</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-8 mb-4">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="mb-0">Investment Plans</h5>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-striped table-hover">
                                        <thead>
                                            <tr>
                                                <th>Plan</th>
                                                <th>Min Amount</th>
                                                <th>Max Amount</th>
                                                <th>ROI</th>
                                                <th>Duration</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($investmentPlans as $plan): ?>
                                                <tr>
                                                    <td><?php echo $plan['name']; ?></td>
                                                    <td>$<?php echo number_format($plan['min_amount'], 2); ?></td>
                                                    <td>$<?php echo number_format($plan['max_amount'], 2); ?></td>
                                                    <td><?php echo $plan['roi']; ?>%</td>
                                                    <td><?php echo $plan['duration']; ?> days</td>
                                                    <td>
                                                        <button class="btn btn-sm btn-primary" onclick="selectPlan(<?php echo $plan['id']; ?>)">
                                                            <i class="fas fa-plus"></i> Invest
                                                        </button>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">My Investments</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th>Plan</th>
                                        <th>Amount</th>
                                        <th>ROI</th>
                                        <th>Expected Return</th>
                                        <th>Duration</th>
                                        <th>Status</th>
                                        <th>Start Date</th>
                                        <th>End Date</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (empty($investments)): ?>
                                        <tr>
                                            <td colspan="8" class="text-center">No investments found</td>
                                        </tr>
                                    <?php else: ?>
                                        <?php foreach ($investments as $investment): ?>
                                            <tr>
                                                <td><?php echo $investment['plan_name']; ?></td>
                                                <td>$<?php echo number_format($investment['amount'], 2); ?></td>
                                                <td><?php echo $investment['roi']; ?>%</td>
                                                <td>$<?php echo number_format($investment['amount'] * ($investment['roi'] / 100), 2); ?></td>
                                                <td><?php echo $investment['duration']; ?> days</td>
                                                <td>
                                                    <span class="badge bg-<?php 
                                                        echo $investment['status'] === 'active' ? 'success' : 
                                                            ($investment['status'] === 'pending' ? 'warning' : 'danger'); 
                                                    ?>">
                                                        <?php echo ucfirst($investment['status']); ?>
                                                    </span>
                                                </td>
                                                <td><?php echo date('M j, Y', strtotime($investment['created_at'])); ?></td>
                                                <td><?php echo date('M j, Y', strtotime($investment['created_at'] . ' + ' . $investment['duration'] . ' days')); ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function updateAmountLimits() {
            const planSelect = document.getElementById('plan_id');
            const amountInput = document.getElementById('amount');
            const amountLimits = document.getElementById('amount-limits');
            
            if (planSelect.selectedIndex > 0) {
                const selectedOption = planSelect.options[planSelect.selectedIndex];
                const minAmount = parseFloat(selectedOption.dataset.min);
                const maxAmount = parseFloat(selectedOption.dataset.max);
                
                amountInput.min = minAmount;
                amountInput.max = Math.min(maxAmount, <?php echo $user['balance']; ?>);
                
                amountLimits.textContent = `Min: $${minAmount.toFixed(2)}, Max: $${maxAmount.toFixed(2)}`;
            } else {
                amountInput.min = 0;
                amountInput.max = <?php echo $user['balance']; ?>;
                amountLimits.textContent = '';
            }
        }
        
        function selectPlan(planId) {
            const planSelect = document.getElementById('plan_id');
            
            for (let i = 0; i < planSelect.options.length; i++) {
                if (planSelect.options[i].value == planId) {
                    planSelect.selectedIndex = i;
                    break;
                }
            }
            
            updateAmountLimits();
            document.getElementById('amount').focus();
        }
        
        // Initialize on page load
        document.addEventListener('DOMContentLoaded', updateAmountLimits);
    </script>
</body>
</html>
