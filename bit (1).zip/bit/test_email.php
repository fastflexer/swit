<?php
require_once __DIR__ . '/includes/EmailHelper.php';

try {
    $emailHelper = new EmailHelper();
    $result = $emailHelper->sendEmail(
        'mimelord@gmail.com',
        'Test Email',
        'This is a test email from Online Broker'
    );
    
    if ($result) {
        echo "Email sent successfully!";
    } else {
        echo "Failed to send email. Please check your SMTP configuration and ensure the vendor directory is present.";
    }
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
    error_log($e->getTraceAsString());
}