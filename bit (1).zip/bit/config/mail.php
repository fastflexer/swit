<?php
// Mail Configuration
define('SMTP_HOST', 'mail.jetfxgrowth.online'); // Use your cPanel mail server
define('SMTP_PORT', 587);
define('SMTP_USERNAME', 'bitreply@jetfxgrowth.online');
define('SMTP_PASSWORD', '10@Jetfxgrowth10@');
define('SMTP_ENCRYPTION', 'tls');
define('MAIL_FROM_ADDRESS', 'bitreply@jetfxgrowth.online');
define('MAIL_FROM_NAME', 'JetFx Growth');
?>