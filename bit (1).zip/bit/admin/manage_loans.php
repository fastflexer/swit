<?php
session_start();
require_once '../config/config.php';
require_once '../includes/auth_check.php';
require_once '../includes/functions.php';

// Check if user is admin
requireAdmin();
requireOTPVerification();

// Get all loans
$loans = getAllLoans();

// Process messages
$message = '';
$messageType = '';

if (isset($_SESSION['loan_message'])) {
    $message = $_SESSION['loan_message'];
    $messageType = $_SESSION['loan_message_type'] ?? 'success';
    unset($_SESSION['loan_message']);
    unset($_SESSION['loan_message_type']);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Loans - <?php echo APP_NAME; ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <?php include 'includes/sidebar.php'; ?>
            
            <!-- Main Content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Manage Loans</h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <a href="loan_plans.php" class="btn btn-sm btn-outline-secondary me-2">
                            <i class="fas fa-cog"></i> Loan Plans
                        </a>
                        <button type="button" class="btn btn-sm btn-outline-secondary dropdown-toggle" data-bs-toggle="dropdown">
                            <i class="fas fa-filter"></i> Filter
                        </button>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="?status=all">All Loans</a></li>
                            <li><a class="dropdown-item" href="?status=pending">Pending</a></li>
                            <li><a class="dropdown-item" href="?status=approved">Approved</a></li>
                            <li><a class="dropdown-item" href="?status=rejected">Rejected</a></li>
                            <li><a class="dropdown-item" href="?status=paid">Paid</a></li>
                            <li><a class="dropdown-item" href="?status=overdue">Overdue</a></li>
                        </ul>
                    </div>
                </div>
                
                <?php if (!empty($message)): ?>
                <div class="alert alert-<?php echo $messageType; ?> alert-dismissible fade show" role="alert">
                    <?php echo $message; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <?php endif; ?>
                
                <!-- Loans Table -->
                <div class="card">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Loan ID</th>
                                        <th>User</th>
                                        <th>Plan</th>
                                        <th>Amount</th>
                                        <th>Interest</th>
                                        <th>Total</th>
                                        <th>Applied Date</th>
                                        <th>Due Date</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (empty($loans)): ?>
                                    <tr>
                                        <td colspan="10" class="text-center">No loans found</td>
                                    </tr>
                                    <?php else: ?>
                                    <?php foreach ($loans as $loan): ?>
                                    <tr>
                                        <td><?php echo $loan['loan_id']; ?></td>
                                        <td>
                                            <a href="user_details.php?id=<?php echo $loan['user_id']; ?>">
                                                <?php echo $loan['first_name'] . ' ' . $loan['last_name']; ?>
                                            </a>
                                        </td>
                                        <td><?php echo $loan['plan_name']; ?></td>
                                        <td>$<?php echo number_format($loan['amount'], 2); ?></td>
                                        <td>$<?php echo number_format($loan['interest_amount'], 2); ?></td>
                                        <td>$<?php echo number_format($loan['total_repayment'], 2); ?></td>
                                        <td><?php echo date('M d, Y', strtotime($loan['created_at'])); ?></td>
                                        <td><?php echo $loan['due_date'] ? date('M d, Y', strtotime($loan['due_date'])) : 'N/A'; ?></td>
                                        <td>
                                            <?php
                                            $statusClass = '';
                                            switch ($loan['status']) {
                                                case 'pending':
                                                    $statusClass = 'bg-warning';
                                                    break;
                                                case 'approved':
                                                    $statusClass = 'bg-success';
                                                    break;
                                                case 'rejected':
                                                    $statusClass = 'bg-danger';
                                                    break;
                                                case 'paid':
                                                    $statusClass = 'bg-info';
                                                    break;
                                                case 'overdue':
                                                    $statusClass = 'bg-danger';
                                                    break;
                                            }
                                            ?>
                                            <span class="badge <?php echo $statusClass; ?>"><?php echo ucfirst($loan['status']); ?></span>
                                        </td>
                                        <td>
                                            <a href="loan_details.php?id=<?php echo $loan['id']; ?>" class="btn btn-sm btn-info">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                            <?php if ($loan['status'] === 'pending'): ?>
                                            <a href="process_loan.php?id=<?php echo $loan['id']; ?>&action=approve" class="btn btn-sm btn-success" onclick="return confirm('Are you sure you want to approve this loan?')">
                                                <i class="fas fa-check"></i>
                                            </a>
                                            <a href="process_loan.php?id=<?php echo $loan['id']; ?>&action=reject" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to reject this loan?')">
                                                <i class="fas fa-times"></i>
                                            </a>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
