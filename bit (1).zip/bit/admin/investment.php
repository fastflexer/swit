<?php
session_start();
require_once '../config/config.php';
require_once '../includes/auth_check.php';
require_once '../includes/functions.php';

// Check if user is admin
requireAdmin();
requireOTPVerification();

// Get active investments
$investments = getActiveInvestments();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Active Investments - <?php echo APP_NAME; ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <?php include 'includes/sidebar.php'; ?>
            
            <!-- Main Content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Active investment Plans</h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <div class="input-group">
                            <input type="text" class="form-control" placeholder="Search...">
                            <button class="btn btn-outline-secondary" type="button">Search</button>
                        </div>
                    </div>
                </div>
                
                <div class="card">
                    <div class="card-header bg-light">
                        <div class="row">
                            <div class="col-md-12 d-flex justify-content-between">
                                <div>
                                    <button class="btn btn-sm btn-secondary">Copy</button>
                                    <button class="btn btn-sm btn-secondary">CSV</button>
                                    <button class="btn btn-sm btn-secondary">Print</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th>Client name</th>
                                        <th>Investment Plan</th>
                                        <th>Amount Invested</th>
                                        <th>Duration</th>
                                        <th>Last Growth</th>
                                        <th>Date created</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (empty($investments)): ?>
                                    <tr>
                                        <td colspan="7" class="text-center">No data available in table</td>
                                    </tr>
                                    <?php else: ?>
                                    <?php foreach ($investments as $investment): ?>
                                    <tr>
                                        <td><?php echo $investment['first_name'] . ' ' . $investment['last_name']; ?></td>
                                        <td><?php echo $investment['plan_name']; ?></td>
                                        <td>$<?php echo number_format($investment['amount'], 2); ?></td>
                                        <td><?php echo $investment['duration']; ?> days</td>
                                        <td><?php echo !empty($investment['last_growth']) ? '$' . number_format($investment['last_growth'], 2) : 'N/A'; ?></td>
                                        <td><?php echo date('M j, Y g:i A', strtotime($investment['created_at'])); ?></td>
                                        <td>
                                            <button class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#viewModal<?php echo $investment['id']; ?>">
                                                <i class="fas fa-eye"></i> View
                                            </button>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="card-footer">
                        <nav aria-label="Page navigation">
                            <ul class="pagination justify-content-end">
                                <li class="page-item disabled">
                                    <a class="page-link" href="#" tabindex="-1">Previous</a>
                                </li>
                                <li class="page-item active"><a class="page-link" href="#">1</a></li>
                                <li class="page-item"><a class="page-link" href="#">2</a></li>
                                <li class="page-item"><a class="page-link" href="#">3</a></li>
                                <li class="page-item">
                                    <a class="page-link" href="#">Next</a>
                                </li>
                            </ul>
                        </nav>
                    </div>
                </div>
            </main>
        </div>
    </div>
    
    <!-- View Investment Modals -->
    <?php foreach ($investments as $investment): ?>
    <div class="modal fade" id="viewModal<?php echo $investment['id']; ?>" tabindex="-1" aria-labelledby="viewModalLabel<?php echo $investment['id']; ?>" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="viewModalLabel<?php echo $investment['id']; ?>">Investment Details</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <strong>Client:</strong> <?php echo $investment['first_name'] . ' ' . $investment['last_name']; ?>
                    </div>
                    <div class="mb-3">
                        <strong>Email:</strong> <?php echo $investment['email']; ?>
                    </div>
                    <div class="mb-3">
                        <strong>Plan:</strong> <?php echo $investment['plan_name']; ?>
                    </div>
                    <div class="mb-3">
                        <strong>Amount:</strong> $<?php echo number_format($investment['amount'], 2); ?>
                    </div>
                    <div class="mb-3">
                        <strong>Duration:</strong> <?php echo $investment['duration']; ?> days
                    </div>
                    <div class="mb-3">
                        <strong>ROI:</strong> <?php echo $investment['roi']; ?>%
                    </div>
                    <div class="mb-3">
                        <strong>Start Date:</strong> <?php echo date('M j, Y g:i A', strtotime($investment['created_at'])); ?>
                    </div>
                    <div class="mb-3">
                        <strong>End Date:</strong> <?php echo date('M j, Y g:i A', strtotime($investment['created_at'] . ' + ' . $investment['duration'] . ' days')); ?>
                    </div>
                    <div class="mb-3">
                        <strong>Status:</strong> <?php echo $investment['status']; ?>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
