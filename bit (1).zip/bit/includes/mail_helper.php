<?php
require_once __DIR__ . '/../config/config.php';

// Send email using PHPMailer or your preferred email library
function sendEmail($to, $subject, $message) {
   // This is a placeholder function. In a real application, you would use PHPMailer or similar library
   // For demonstration purposes, we'll assume the email is sent successfully
   
   // Log email for debugging
   $logFile = __DIR__ . '/../logs/email_log.txt';
   $logMessage = date('Y-m-d H:i:s') . " - To: $to, Subject: $subject, Message: " . substr(strip_tags($message), 0, 100) . "...
";
   
   // Create logs directory if it doesn't exist
   if (!file_exists(__DIR__ . '/../logs')) {
       mkdir(__DIR__ . '/../logs', 0755, true);
   }
   
   // Append to log file
   file_put_contents($logFile, $logMessage, FILE_APPEND);
   
   // In a real application, you would use code like this:
   /*
   use PHPMailer\PHPMailer\PHPMailer;
   use PHPMailer\PHPMailer\Exception;
   
   require __DIR__ . '/../vendor/autoload.php';
   
   $mail = new PHPMailer(true);
   
   try {
       // Server settings
       $mail->isSMTP();
       $mail->Host = SMTP_HOST;
       $mail->SMTPAuth = true;
       $mail->Username = SMTP_USERNAME;
       $mail->Password = SMTP_PASSWORD;
       $mail->SMTPSecure = SMTP_ENCRYPTION;
       $mail->Port = SMTP_PORT;
       
       // Recipients
       $mail->setFrom(SMTP_FROM_EMAIL, SMTP_FROM_NAME);
       $mail->addAddress($to);
       
       // Content
       $mail->isHTML(true);
       $mail->Subject = $subject;
       $mail->Body = $message;
       
       $mail->send();
       return true;
   } catch (Exception $e) {
       error_log("Email could not be sent. Mailer Error: {$mail->ErrorInfo}");
       return false;
   }
   */
   
   // For demonstration, return true
   return true;
}

// Send deposit notification email
function sendDepositNotification($user, $deposit) {
   $subject = APP_NAME . " - Deposit " . ucfirst($deposit['status']);
   
   $statusMessage = '';
   switch($deposit['status']) {
       case 'pending':
           $statusMessage = "Your deposit request has been received and is pending approval.";
           break;
       case 'processed':
           $statusMessage = "Your deposit has been processed and the funds have been added to your account.";
           break;
       case 'rejected':
           $statusMessage = "Unfortunately, your deposit request has been rejected. Please contact support for more information.";
           break;
   }
   
   $message = "
       <html>
       <head>
           <title>Deposit Notification</title>
           <style>
               body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
               .container { max-width: 600px; margin: 0 auto; padding: 20px; }
               .header { background-color: #7000ff; color: white; padding: 10px 20px; text-align: center; }
               .content { padding: 20px; border: 1px solid #ddd; }
               .footer { font-size: 12px; text-align: center; margin-top: 20px; color: #777; }
               .details { margin: 20px 0; }
               .details table { width: 100%; border-collapse: collapse; }
               .details th, .details td { padding: 10px; border-bottom: 1px solid #ddd; text-align: left; }
               .status-pending { color: #ff9900; }
               .status-processed { color: #28a745; }
               .status-rejected { color: #dc3545; }
           </style>
       </head>
       <body>
           <div class='container'>
               <div class='header'>
                   <h2>" . APP_NAME . " - Deposit Notification</h2>
               </div>
               <div class='content'>
                   <p>Dear " . $user['full_name'] . ",</p>
                   
                   <p>" . $statusMessage . "</p>
                   
                   <div class='details'>
                       <table>
                           <tr>
                               <th>Amount:</th>
                               <td>" . formatCurrency($deposit['amount']) . "</td>
                           </tr>
                           <tr>
                               <th>Payment Method:</th>
                               <td>" . $deposit['payment_method'] . "</td>
                           </tr>
                           <tr>
                               <th>Transaction ID:</th>
                               <td>" . $deposit['transaction_id'] . "</td>
                           </tr>
                           <tr>
                               <th>Date:</th>
                               <td>" . date('F j, Y, g:i a', strtotime($deposit['created_at'])) . "</td>
                           </tr>
                           <tr>
                               <th>Status:</th>
                               <td class='status-" . $deposit['status'] . "'>" . ucfirst($deposit['status']) . "</td>
                           </tr>
                       </table>
                   </div>
                   
                   <p>If you have any questions, please contact our support team.</p>
                   
                   <p>Thank you for choosing " . APP_NAME . ".</p>
               </div>
               <div class='footer'>
                   <p>© " . date('Y') . " " . APP_NAME . ". All rights reserved.</p>
                   <p>This is an automated email, please do not reply.</p>
               </div>
           </div>
       </body>
       </html>
   ";
   
   return sendEmail($user['email'], $subject, $message);
}

// Send withdrawal notification email
function sendWithdrawalNotification($user, $withdrawal) {
   $subject = APP_NAME . " - Withdrawal " . ucfirst($withdrawal['status']);
   
   $statusMessage = '';
   switch($withdrawal['status']) {
       case 'pending':
           $statusMessage = "Your withdrawal request has been received and is pending approval.";
           break;
       case 'processed':
           $statusMessage = "Your withdrawal has been processed and the funds have been sent to your specified payment method.";
           break;
       case 'rejected':
           $statusMessage = "Unfortunately, your withdrawal request has been rejected. Please contact support for more information.";
           break;
       case 'blocked':
           $statusMessage = "Your withdrawal request has been blocked due to security concerns or policy violations. Please contact support immediately.";
           break;
   }
   
   $message = "
       <html>
       <head>
           <title>Withdrawal Notification</title>
           <style>
               body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
               .container { max-width: 600px; margin: 0 auto; padding: 20px; }
               .header { background-color: #7000ff; color: white; padding: 10px 20px; text-align: center; }
               .content { padding: 20px; border: 1px solid #ddd; }
               .footer { font-size: 12px; text-align: center; margin-top: 20px; color: #777; }
               .details { margin: 20px 0; }
               .details table { width: 100%; border-collapse: collapse; }
               .details th, .details td { padding: 10px; border-bottom: 1px solid #ddd; text-align: left; }
               .status-pending { color: #ff9900; }
               .status-processed { color: #28a745; }
               .status-rejected { color: #dc3545; }
               .status-blocked { color: #dc3545; font-weight: bold; }
           </style>
       </head>
       <body>
           <div class='container'>
               <div class='header'>
                   <h2>" . APP_NAME . " - Withdrawal Notification</h2>
               </div>
               <div class='content'>
                   <p>Dear " . $user['full_name'] . ",</p>
                   
                   <p>" . $statusMessage . "</p>
                   
                   <div class='details'>
                       <table>
                           <tr>
                               <th>Amount:</th>
                               <td>" . formatCurrency($withdrawal['amount']) . "</td>
                           </tr>
                           <tr>
                               <th>Fee:</th>
                               <td>" . formatCurrency($withdrawal['fee']) . "</td>
                           </tr>
                           <tr>
                               <th>Net Amount:</th>
                               <td>" . formatCurrency($withdrawal['amount'] - $withdrawal['fee']) . "</td>
                           </tr>
                           <tr>
                               <th>Payment Method:</th>
                               <td>" . $withdrawal['payment_method'] . "</td>
                           </tr>
                           <tr>
                               <th>Date:</th>
                               <td>" . date('F j, Y, g:i a', strtotime($withdrawal['created_at'])) . "</td>
                           </tr>
                           <tr>
                               <th>Status:</th>
                               <td class='status-" . $withdrawal['status'] . "'>" . ucfirst($withdrawal['status']) . "</td>
                           </tr>
                       </table>
                   </div>
                   
                   <p>If you have any questions, please contact our support team.</p>
                   
                   <p>Thank you for choosing " . APP_NAME . ".</p>
               </div>
               <div class='footer'>
                   <p>© " . date('Y') . " " . APP_NAME . ". All rights reserved.</p>
                   <p>This is an automated email, please do not reply.</p>
               </div>
           </div>
       </body>
       </html>
   ";
   
   return sendEmail($user['email'], $subject, $message);
}

// Send trade result notification email
function sendTradeResultNotification($user, $trade) {
   $isWin = $trade['result'] === 'win';
   $subject = APP_NAME . " - Trade " . ($isWin ? "Profit" : "Loss") . " Notification";
   
   $profitLoss = $isWin ? $trade['profit'] : $trade['loss'];
   $profitLossText = $isWin ? "Profit" : "Loss";
   $profitLossColor = $isWin ? "#28a745" : "#dc3545";
   
   $message = "
       <html>
       <head>
           <title>Trade Result Notification</title>
           <style>
               body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
               .container { max-width: 600px; margin: 0 auto; padding: 20px; }
               .header { background-color: #7000ff; color: white; padding: 10px 20px; text-align: center; }
               .content { padding: 20px; border: 1px solid #ddd; }
               .footer { font-size: 12px; text-align: center; margin-top: 20px; color: #777; }
               .details { margin: 20px 0; }
               .details table { width: 100%; border-collapse: collapse; }
               .details th, .details td { padding: 10px; border-bottom: 1px solid #ddd; text-align: left; }
               .profit { color: #28a745; }
               .loss { color: #dc3545; }
               .result-box { padding: 15px; margin: 20px 0; text-align: center; border-radius: 5px; }
           </style>
       </head>
       <body>
           <div class='container'>
               <div class='header'>
                   <h2>" . APP_NAME . " - Trade Result</h2>
               </div>
               <div class='content'>
                   <p>Dear " . $user['full_name'] . ",</p>
                   
                   <p>Your trade has been completed with the following result:</p>
                   
                   <div class='result-box' style='background-color: " . $profitLossColor . "20; border: 1px solid " . $profitLossColor . ";'>
                       <h3 style='color: " . $profitLossColor . ";'>" . ($isWin ? "PROFIT" : "LOSS") . ": " . formatCurrency($profitLoss) . "</h3>
                   </div>
                   
                   <div class='details'>
                       <table>
                           <tr>
                               <th>Symbol:</th>
                               <td>" . $trade['symbol'] . "</td>
                           </tr>
                           <tr>
                               <th>Type:</th>
                               <td>" . strtoupper($trade['type']) . "</td>
                           </tr>
                           <tr>
                               <th>Entry Price:</th>
                               <td>" . $trade['entry_price'] . "</td>
                           </tr>
                           <tr>
                               <th>Exit Price:</th>
                               <td>" . $trade['exit_price'] . "</td>
                           </tr>
                           <tr>
                               <th>Volume:</th>
                               <td>" . $trade['volume'] . " lots</td>
                           </tr>
                           <tr>
                               <th>Open Time:</th>
                               <td>" . date('F j, Y, g:i a', strtotime($trade['open_time'])) . "</td>
                           </tr>
                           <tr>
                               <th>Close Time:</th>
                               <td>" . date('F j, Y, g:i a', strtotime($trade['close_time'])) . "</td>
                           </tr>
                           <tr>
                               <th>" . $profitLossText . ":</th>
                               <td class='" . strtolower($profitLossText) . "'>" . formatCurrency($profitLoss) . "</td>
                           </tr>
                       </table>
                   </div>
                   
                   <p>Your account balance has been " . ($isWin ? "credited with the profit" : "debited with the loss") . ".</p>
                   
                   <p>Thank you for trading with " . APP_NAME . ".</p>
               </div>
               <div class='footer'>
                   <p>© " . date('Y') . " " . APP_NAME . ". All rights reserved.</p>
                   <p>This is an automated email, please do not reply.</p>
               </div>
           </div>
       </body>
       </html>
   ";
   
   return sendEmail($user['email'], $subject, $message);
}

// Send copy trade notification email
function sendCopyTradeNotification($user, $trade, $trader) {
   $isWin = $trade['result'] === 'win';
   $subject = APP_NAME . " - Copy Trade " . ($isWin ? "Profit" : "Loss") . " Notification";
   
   $profitLoss = $isWin ? $trade['profit'] : $trade['loss'];
   $profitLossText = $isWin ? "Profit" : "Loss";
   $profitLossColor = $isWin ? "#28a745" : "#dc3545";
   
   $message = "
       <html>
       <head>
           <title>Copy Trade Notification</title>
           <style>
               body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
               .container { max-width: 600px; margin: 0 auto; padding: 20px; }
               .header { background-color: #7000ff; color: white; padding: 10px 20px; text-align: center; }
               .content { padding: 20px; border: 1px solid #ddd; }
               .footer { font-size: 12px; text-align: center; margin-top: 20px; color: #777; }
               .details { margin: 20px 0; }
               .details table { width: 100%; border-collapse: collapse; }
               .details th, .details td { padding: 10px; border-bottom: 1px solid #ddd; text-align: left; }
               .profit { color: #28a745; }
               .loss { color: #dc3545; }
               .result-box { padding: 15px; margin: 20px 0; text-align: center; border-radius: 5px; }
               .trader-info { background-color: #f8f9fa; padding: 15px; margin: 20px 0; border-radius: 5px; }
           </style>
       </head>
       <body>
           <div class='container'>
               <div class='header'>
                   <h2>" . APP_NAME . " - Copy Trade Result</h2>
               </div>
               <div class='content'>
                   <p>Dear " . $user['full_name'] . ",</p>
                   
                   <p>A trade has been copied from trader <strong>" . $trader['full_name'] . "</strong> with the following result:</p>
                   
                   <div class='result-box' style='background-color: " . $profitLossColor . "20; border: 1px solid " . $profitLossColor . ";'>
                       <h3 style='color: " . $profitLossColor . ";'>" . ($isWin ? "PROFIT" : "LOSS") . ": " . formatCurrency($profitLoss) . "</h3>
                   </div>
                   
                   <div class='trader-info'>
                       <h4>Trader Information</h4>
                       <p><strong>Name:</strong> " . $trader['full_name'] . "</p>
                       <p><strong>Win Rate:</strong> " . $trader['win_rate'] . "%</p>
                   </div>
                   
                   <div class='details'>
                       <table>
                           <tr>
                               <th>Symbol:</th>
                               <td>" . $trade['symbol'] . "</td>
                           </tr>
                           <tr>
                               <th>Type:</th>
                               <td>" . strtoupper($trade['type']) . "</td>
                           </tr>
                           <tr>
                               <th>Entry Price:</th>
                               <td>" . $trade['entry_price'] . "</td>
                           </tr>
                           <tr>
                               <th>Exit Price:</th>
                               <td>" . $trade['exit_price'] . "</td>
                           </tr>
                           <tr>
                               <th>Volume:</th>
                               <td>" . $trade['volume'] . " lots</td>
                           </tr>
                           <tr>
                               <th>Open Time:</th>
                               <td>" . date('F j, Y, g:i a', strtotime($trade['open_time'])) . "</td>
                           </tr>
                           <tr>
                               <th>Close Time:</th>
                               <td>" . date('F j, Y, g:i a', strtotime($trade['close_time'])) . "</td>
                           </tr>
                           <tr>
                               <th>" . $profitLossText . ":</th>
                               <td class='" . strtolower($profitLossText) . "'>" . formatCurrency($profitLoss) . "</td>
                           </tr>
                       </table>
                   </div>
                   
                   <p>Your account balance has been " . ($isWin ? "credited with the profit" : "debited with the loss") . ".</p>
                   
                   <p>Thank you for using our copy trading service at " . APP_NAME . ".</p>
               </div>
               <div class='footer'>
                   <p>© " . date('Y') . " " . APP_NAME . ". All rights reserved.</p>
                   <p>This is an automated email, please do not reply.</p>
               </div>
           </div>
       </body>
       </html>
   ";
   
   return sendEmail($user['email'], $subject, $message);
}
?>
