<?php
session_start();
require_once '../config/config.php';
require_once '../includes/functions.php';

// Redirect if already logged in
if (isset($_SESSION['user_id'])) {
    header("Location: ../index.php");
    exit();
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';
    $remember = isset($_POST['remember']) ? true : false;
    
    if (empty($email) || empty($password)) {
        $error = "Please enter both email and password";
    } else {
        // Check if user exists
        $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 1) {
            $user = $result->fetch_assoc();
            
            // Verify password
            if (password_verify($password, $user['password'])) {
                // Check if email is verified
                if ($user['email_verified'] != 1) {
                    $error = "Please verify your email address before logging in. <a href='resend_verification.php?email=" . urlencode($email) . "'>Resend verification email</a>";
                } 
                // Check if account is active
                else if ($user['status'] !== 'active') {
                    $error = "Your account is not active. Please contact support.";
                } else {
                    // Generate and store OTP
                    $otp = generateOTP();
                    if (storeOTP($user['id'], $otp)) {
                        // Send OTP via email
                        if (sendOTP($user['email'], $otp)) {
                            // Store user info in session
                            $_SESSION['temp_user_id'] = $user['id'];
                            $_SESSION['temp_user_email'] = $user['email'];
                            $_SESSION['temp_user_role'] = $user['role'];
                            
                            // Set remember me cookie if checked
                            if ($remember) {
                                $token = bin2hex(random_bytes(32));
                                $expires = time() + (30 * 24 * 60 * 60); // 30 days
                                
                                // Store token in database
                                $stmt = $conn->prepare("INSERT INTO remember_tokens (user_id, token, expires) VALUES (?, ?, ?)");
                                $stmt->bind_param("iss", $user['id'], $token, date('Y-m-d H:i:s', $expires));
                                $stmt->execute();
                                
                                // Set cookie
                                setcookie('remember_token', $token, $expires, '/', '', true, true);
                            }
                            
                            // Redirect to OTP verification page
                            header("Location: verify_otp.php");
                            exit();
                        } else {
                            $error = "Failed to send OTP. Please try again.";
                        }
                    } else {
                        $error = "Failed to generate OTP. Please try again.";
                    }
                }
            } else {
                $error = "Invalid email or password";
            }
        } else {
            $error = "Invalid email or password";
        }
    }
}

// Check for remember me cookie
if (isset($_COOKIE['remember_token'])) {
    $token = $_COOKIE['remember_token'];
    
    $stmt = $conn->prepare("SELECT u.* FROM users u JOIN remember_tokens rt ON u.id = rt.user_id WHERE rt.token = ? AND rt.expires > NOW()");
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();
        
        // Auto-login user
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_email'] = $user['email'];
        $_SESSION['user_role'] = $user['role'];
        $_SESSION['otp_verified'] = true;
        
        // Redirect based on role
        if ($user['role'] === 'admin' || $user['role'] === 'super_admin') {
            header("Location: ../admin/dashboard.php");
        } else {
            header("Location: ../user/dashboard.php");
        }
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - <?php echo APP_NAME; ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/auth.css">
</head>
<body>
    <div class="container">
        <div class="row justify-content-center align-items-center min-vh-100">
            <div class="col-md-5">
                <div class="auth-card">
                    <div class="text-center mb-4">
                        <h2 class="auth-title">User Login</h2>
                    </div>
                    
                    <?php if (!empty($error)): ?>
                        <div class="alert alert-danger"><?php echo $error; ?></div>
                    <?php endif; ?>
                    
                    <?php if (!empty($success)): ?>
                        <div class="alert alert-success"><?php echo $success; ?></div>
                    <?php endif; ?>
                    
                    <form method="POST" action="">
                        <div class="mb-3">
                            <label for="email" class="form-label">Your Email <span class="text-danger">*</span></label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="fas fa-envelope"></i></span>
                                <input type="email" class="form-control" id="email" name="email" placeholder="name@example.com" required>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="password" class="form-label">Password <span class="text-danger">*</span></label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="fas fa-lock"></i></span>
                                <input type="password" class="form-control" id="password" name="password" placeholder="Enter Password" required>
                            </div>
                        </div>
                        
                        <div class="d-flex justify-content-between mb-3">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="remember" name="remember">
                                <label class="form-check-label" for="remember">Remember me</label>
                            </div>
                            <div>
                                <a href="forgot_password.php" class="text-decoration-none">Forgot password?</a>
                            </div>
                        </div>
                        
                        <div class="d-grid mb-4">
                            <button type="submit" class="btn btn-primary btn-lg">Sign in</button>
                        </div>
                    </form>
                    
                    <div class="text-center mb-3">
                        <p>Or Login With</p>
                    </div>
                    
                    <div class="d-grid mb-4">
                        <a href="#" class="btn btn-outline-secondary btn-lg">
                            <img src="../assets/img/google-icon.png" alt="Google" width="20" height="20" class="me-2">
                            Google
                        </a>
                    </div>
                    
                    <div class="text-center">
                        <p>Don't have an account? <a href="register.php" class="text-decoration-none">Sign Up</a></p>
                    </div>
                    
                    <div class="text-center mt-4">
                        <p class="small text-muted">© Copyright 2025 JetFx Growth All Rights Reserved.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
