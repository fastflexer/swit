<?php
require_once 'config/config.php';
require_once 'includes/functions.php';

/**
 * Get all NFTs
 * 
 * @param string $category Optional category filter
 * @param string $search Optional search term
 * @return array Array of NFTs
 */
function getAllNFTs($category = null, $search = null) {
    global $conn;
    
    $sql = "SELECT n.*, u.username as owner_username FROM nfts n 
            LEFT JOIN users u ON n.owner_id = u.id 
            WHERE n.status = 'active'";
    
    if ($category && $category != 'All Categories') {
        $sql .= " AND n.category = ?";
    }
    
    if ($search) {
        $sql .= " AND (n.name LIKE ? OR n.description LIKE ?)";
    }
    
    $sql .= " ORDER BY n.created_at DESC";
    
    $stmt = $conn->prepare($sql);
    
    $i = 1;
    if ($category && $category != 'All Categories') {
        $stmt->bind_param('s', $category);
        $i++;
    }
    
    if ($search) {
        $searchParam = "%$search%";
        if ($i == 1) {
            $stmt->bind_param('ss', $searchParam, $searchParam);
        } else {
            $stmt->bind_param('sss', $category, $searchParam, $searchParam);
        }
    }
    
    $stmt->execute();
    $result = $stmt->get_result();
    
    $nfts = [];
    while ($row = $result->fetch_assoc()) {
        $nfts[] = $row;
    }
    
    return $nfts;
}

/**
 * Get NFT by ID
 * 
 * @param int $id NFT ID
 * @return array|null NFT data or null if not found
 */
function getNFTById($id) {
    global $conn;
    
    $stmt = $conn->prepare("SELECT n.*, u.username as owner_username FROM nfts n 
                           LEFT JOIN users u ON n.owner_id = u.id 
                           WHERE n.id = ?");
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        return $result->fetch_assoc();
    }
    
    return null;
}

/**
 * Get NFTs by owner ID
 * 
 * @param int $ownerId User ID of the owner
 * @return array Array of NFTs
 */
function getNFTsByOwner($ownerId) {
    global $conn;
    
    $stmt = $conn->prepare("SELECT * FROM nfts WHERE owner_id = ? ORDER BY created_at DESC");
    $stmt->bind_param('i', $ownerId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $nfts = [];
    while ($row = $result->fetch_assoc()) {
        $nfts[] = $row;
    }
    
    return $nfts;
}

/**
 * Create a new NFT
 * 
 * @param array $data NFT data
 * @return int|bool New NFT ID or false on failure
 */
function createNFT($data) {
    global $conn;
    
    $stmt = $conn->prepare("INSERT INTO nfts (name, description, price, category, image_url, owner_id, status, created_at) 
                           VALUES (?, ?, ?, ?, ?, ?, 'active', NOW())");
    $stmt->bind_param('ssdssi', $data['name'], $data['description'], $data['price'], $data['category'], $data['image_url'], $data['owner_id']);
    
    if ($stmt->execute()) {
        return $conn->insert_id;
    }
    
    return false;
}

/**
 * Update an NFT
 * 
 * @param int $id NFT ID
 * @param array $data Updated NFT data
 * @return bool Success or failure
 */
function updateNFT($id, $data) {
    global $conn;
    
    $sql = "UPDATE nfts SET name = ?, description = ?, price = ?, category = ?";
    
    if (isset($data['image_url']) && !empty($data['image_url'])) {
        $sql .= ", image_url = ?";
    }
    
    if (isset($data['status'])) {
        $sql .= ", status = ?";
    }
    
    $sql .= " WHERE id = ?";
    
    $stmt = $conn->prepare($sql);
    
    if (isset($data['image_url']) && !empty($data['image_url'])) {
        if (isset($data['status'])) {
            $stmt->bind_param('ssdsssi', $data['name'], $data['description'], $data['price'], $data['category'], $data['image_url'], $data['status'], $id);
        } else {
            $stmt->bind_param('ssdssi', $data['name'], $data['description'], $data['price'], $data['category'], $data['image_url'], $id);
        }
    } else {
        if (isset($data['status'])) {
            $stmt->bind_param('ssdssi', $data['name'], $data['description'], $data['price'], $data['category'], $data['status'], $id);
        } else {
            $stmt->bind_param('ssdsi', $data['name'], $data['description'], $data['price'], $data['category'], $id);
        }
    }
    
    return $stmt->execute();
}

/**
 * Delete an NFT
 * 
 * @param int $id NFT ID
 * @return bool Success or failure
 */
function deleteNFT($id) {
    global $conn;
    
    $stmt = $conn->prepare("DELETE FROM nfts WHERE id = ?");
    $stmt->bind_param('i', $id);
    
    return $stmt->execute();
}

/**
 * Place a bid on an NFT
 * 
 * @param int $nftId NFT ID
 * @param int $userId User ID
 * @param float $amount Bid amount
 * @return int|bool New bid ID or false on failure
 */
function placeNFTBid($nftId, $userId, $amount) {
    global $conn;
    
    $stmt = $conn->prepare("INSERT INTO nft_bids (nft_id, user_id, amount, status, created_at) 
                           VALUES (?, ?, ?, 'pending', NOW())");
    $stmt->bind_param('iid', $nftId, $userId, $amount);
    
    if ($stmt->execute()) {
        return $conn->insert_id;
    }
    
    return false;
}

/**
 * Get bids for an NFT
 * 
 * @param int $nftId NFT ID
 * @return array Array of bids
 */
function getNFTBids($nftId) {
    global $conn;
    
    $stmt = $conn->prepare("SELECT b.*, u.username FROM nft_bids b 
                           LEFT JOIN users u ON b.user_id = u.id 
                           WHERE b.nft_id = ? 
                           ORDER BY b.amount DESC, b.created_at DESC");
    $stmt->bind_param('i', $nftId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $bids = [];
    while ($row = $result->fetch_assoc()) {
        $bids[] = $row;
    }
    
    return $bids;
}

/**
 * Accept a bid for an NFT
 * 
 * @param int $bidId Bid ID
 * @return bool Success or failure
 */
function acceptNFTBid($bidId) {
    global $conn;
    
    // Start transaction
    $conn->begin_transaction();
    
    try {
        // Get bid details
        $stmt = $conn->prepare("SELECT * FROM nft_bids WHERE id = ?");
        $stmt->bind_param('i', $bidId);
        $stmt->execute();
        $bid = $stmt->get_result()->fetch_assoc();
        
        if (!$bid) {
            throw new Exception("Bid not found");
        }
        
        // Get NFT details
        $stmt = $conn->prepare("SELECT * FROM nfts WHERE id = ?");
        $stmt->bind_param('i', $bid['nft_id']);
        $stmt->execute();
        $nft = $stmt->get_result()->fetch_assoc();
        
        if (!$nft) {
            throw new Exception("NFT not found");
        }
        
        // Update bid status
        $stmt = $conn->prepare("UPDATE nft_bids SET status = 'accepted' WHERE id = ?");
        $stmt->bind_param('i', $bidId);
        $stmt->execute();
        
        // Update other bids for this NFT to rejected
        $stmt = $conn->prepare("UPDATE nft_bids SET status = 'rejected' WHERE nft_id = ? AND id != ?");
        $stmt->bind_param('ii', $bid['nft_id'], $bidId);
        $stmt->execute();
        
        // Transfer NFT ownership
        $stmt = $conn->prepare("UPDATE nfts SET owner_id = ?, last_sold_price = ?, last_sold_at = NOW() WHERE id = ?");
        $stmt->bind_param('idi', $bid['user_id'], $bid['amount'], $bid['nft_id']);
        $stmt->execute();
        
        // Record transaction
        $stmt = $conn->prepare("INSERT INTO nft_transactions (nft_id, seller_id, buyer_id, price, transaction_type, created_at) 
                               VALUES (?, ?, ?, ?, 'bid_accepted', NOW())");
        $stmt->bind_param('iiid', $bid['nft_id'], $nft['owner_id'], $bid['user_id'], $bid['amount']);
        $stmt->execute();
        
        // Commit transaction
        $conn->commit();
        return true;
    } catch (Exception $e) {
        // Rollback on error
        $conn->rollback();
        return false;
    }
}

/**
 * Buy an NFT directly
 * 
 * @param int $nftId NFT ID
 * @param int $buyerId Buyer user ID
 * @return bool Success or failure
 */
function buyNFT($nftId, $buyerId) {
    global $conn;
    
    // Start transaction
    $conn->begin_transaction();
    
    try {
        // Get NFT details
        $stmt = $conn->prepare("SELECT * FROM nfts WHERE id = ?");
        $stmt->bind_param('i', $nftId);
        $stmt->execute();
        $nft = $stmt->get_result()->fetch_assoc();
        
        if (!$nft) {
            throw new Exception("NFT not found");
        }
        
        // Update NFT ownership
        $stmt = $conn->prepare("UPDATE nfts SET owner_id = ?, last_sold_price = price, last_sold_at = NOW() WHERE id = ?");
        $stmt->bind_param('ii', $buyerId, $nftId);
        $stmt->execute();
        
        // Record transaction
        $stmt = $conn->prepare("INSERT INTO nft_transactions (nft_id, seller_id, buyer_id, price, transaction_type, created_at) 
                               VALUES (?, ?, ?, ?, 'direct_purchase', NOW())");
        $stmt->bind_param('iiid', $nftId, $nft['owner_id'], $buyerId, $nft['price']);
        $stmt->execute();
        
        // Reject all pending bids
        $stmt = $conn->prepare("UPDATE nft_bids SET status = 'rejected' WHERE nft_id = ? AND status = 'pending'");
        $stmt->bind_param('i', $nftId);
        $stmt->execute();
        
        // Commit transaction
        $conn->commit();
        return true;
    } catch (Exception $e) {
        // Rollback on error
        $conn->rollback();
        return false;
    }
}

/**
 * Get NFT categories
 * 
 * @return array Array of categories
 */
function getNFTCategories() {
    return [
        'Arts',
        'Collectibles',
        'Domain Names',
        'Music',
        'Photography',
        'Sports',
        'Trading Cards',
        'Utility',
        'Virtual Worlds'
    ];
}

/**
 * Get NFT transaction history
 * 
 * @param int $nftId NFT ID
 * @return array Array of transactions
 */
function getNFTTransactionHistory($nftId) {
    global $conn;
    
    $stmt = $conn->prepare("SELECT t.*, 
                           s.username as seller_username, 
                           b.username as buyer_username 
                           FROM nft_transactions t
                           LEFT JOIN users s ON t.seller_id = s.id
                           LEFT JOIN users b ON t.buyer_id = b.id
                           WHERE t.nft_id = ?
                           ORDER BY t.created_at DESC");
    $stmt->bind_param('i', $nftId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $transactions = [];
    while ($row = $result->fetch_assoc()) {
        $transactions[] = $row;
    }
    
    return $transactions;
}
?>
