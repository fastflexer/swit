<?php
session_start();
require_once '../config/config.php';
require_once '../includes/auth_check.php';
require_once '../includes/functions.php';

// Check if user is admin
requireAdmin();
requireOTPVerification();

// Check if loan ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    $_SESSION['loan_message'] = "Invalid loan ID.";
    $_SESSION['loan_message_type'] = "danger";
    header("Location: manage_loans.php");
    exit;
}

$loanId = intval($_GET['id']);

// Get loan details
$loan = getLoanById($loanId);

// Check if loan exists
if (!$loan) {
    $_SESSION['loan_message'] = "Loan not found.";
    $_SESSION['loan_message_type'] = "danger";
    header("Location: manage_loans.php");
    exit;
}

// Get user details
$user = getUserById($loan['user_id']);

// Get loan plan details
$loanPlan = getLoanPlanById($loan['plan_id']);

// Get loan repayment history
$repayments = getLoanRepayments($loanId);

// Process messages
$message = '';
$messageType = '';

if (isset($_SESSION['loan_detail_message'])) {
    $message = $_SESSION['loan_detail_message'];
    $messageType = $_SESSION['loan_detail_message_type'] ?? 'success';
    unset($_SESSION['loan_detail_message']);
    unset($_SESSION['loan_detail_message_type']);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Loan Details - <?php echo APP_NAME; ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <?php include 'includes/sidebar.php'; ?>
            
            <!-- Main Content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Loan Details</h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <a href="manage_loans.php" class="btn btn-sm btn-outline-secondary me-2">
                            <i class="fas fa-arrow-left"></i> Back to Loans
                        </a>
                        <?php if ($loan['status'] === 'pending'): ?>
                        <a href="process_loan.php?id=<?php echo $loan['id']; ?>&action=approve" class="btn btn-sm btn-success me-2" onclick="return confirm('Are you sure you want to approve this loan?')">
                            <i class="fas fa-check"></i> Approve Loan
                        </a>
                        <a href="process_loan.php?id=<?php echo $loan['id']; ?>&action=reject" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to reject this loan?')">
                            <i class="fas fa-times"></i> Reject Loan
                        </a>
                        <?php endif; ?>
                    </div>
                </div>
                
                <?php if (!empty($message)): ?>
                <div class="alert alert-<?php echo $messageType; ?> alert-dismissible fade show" role="alert">
                    <?php echo $message; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <?php endif; ?>
                
                <!-- Loan Status Card -->
                <div class="row mb-4">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-6">
                                        <h5 class="card-title">Loan #<?php echo $loan['loan_id']; ?></h5>
                                        <div class="loan-status-badge mb-3">
                                            <?php
                                            $statusClass = '';
                                            switch ($loan['status']) {
                                                case 'pending':
                                                    $statusClass = 'bg-warning';
                                                    break;
                                                case 'approved':
                                                    $statusClass = 'bg-success';
                                                    break;
                                                case 'rejected':
                                                    $statusClass = 'bg-danger';
                                                    break;
                                                case 'paid':
                                                    $statusClass = 'bg-info';
                                                    break;
                                                case 'overdue':
                                                    $statusClass = 'bg-danger';
                                                    break;
                                            }
                                            ?>
                                            <span class="badge <?php echo $statusClass; ?> p-2">
                                                <i class="fas fa-circle me-1"></i>
                                                <?php echo ucfirst($loan['status']); ?>
                                            </span>
                                        </div>
                                        <p class="mb-2"><strong>User:</strong> <a href="user_details.php?id=<?php echo $user['id']; ?>"><?php echo $user['first_name'] . ' ' . $user['last_name']; ?></a></p>
                                        <p class="mb-2"><strong>Email:</strong> <?php echo $user['email']; ?></p>
                                        <p class="mb-2"><strong>Phone:</strong> <?php echo $user['phone']; ?></p>
                                        <p class="mb-2"><strong>Plan:</strong> <?php echo $loanPlan['name']; ?></p>
                                        <p class="mb-2"><strong>Purpose:</strong> <?php echo $loan['purpose']; ?></p>
                                        <p class="mb-2"><strong>Repayment Source:</strong> <?php echo $loan['repayment_source']; ?></p>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="loan-amount-box text-center p-3 mb-3 rounded" style="background-color: rgba(0,0,0,0.05);">
                                            <h6>Loan Amount</h6>
                                            <h2 class="mb-0">$<?php echo number_format($loan['amount'], 2); ?></h2>
                                        </div>
                                        <div class="row">
                                            <div class="col-6">
                                                <p class="mb-2"><strong>Interest Rate:</strong> <?php echo $loanPlan['interest_rate']; ?>%</p>
                                                <p class="mb-2"><strong>Interest Amount:</strong> $<?php echo number_format($loan['interest_amount'], 2); ?></p>
                                                <p class="mb-2"><strong>Processing Fee:</strong> $<?php echo number_format($loan['processing_fee'], 2); ?></p>
                                                <p class="mb-2"><strong>Applied Date:</strong> <?php echo date('M d, Y', strtotime($loan['created_at'])); ?></p>
                                            </div>
                                            <div class="col-6">
                                                <p class="mb-2"><strong>Duration:</strong> <?php echo $loan['duration']; ?> days</p>
                                                <p class="mb-2"><strong>Total Repayment:</strong> $<?php echo number_format($loan['total_repayment'], 2); ?></p>
                                                <p class="mb-2"><strong>Amount Paid:</strong> $<?php echo number_format($loan['amount_paid'], 2); ?></p>
                                                <?php if ($loan['status'] === 'approved'): ?>
                                                <p class="mb-2"><strong>Due Date:</strong> <?php echo date('M d, Y', strtotime($loan['due_date'])); ?></p>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Admin Actions -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h5 class="mb-0">Admin Actions</h5>
                    </div>
                    <div class="card-body">
                        <form action="update_loan_comment.php" method="post">
                            <input type="hidden" name="loan_id" value="<?php echo $loan['id']; ?>">
                            
                            <div class="mb-3">
                                <label for="admin_comment" class="form-label">Admin Comment</label>
                                <textarea class="form-control" id="admin_comment" name="admin_comment" rows="3"><?php echo $loan['admin_comment']; ?></textarea>
                            </div>
                            
                            <button type="submit" class="btn btn-primary">Update Comment</button>
                        </form>
                        
                        <hr>
                        
                        <?php if ($loan['status'] === 'approved'): ?>
                        <div class="row">
                            <div class="col-md-6">
                                <form action="mark_loan_paid.php" method="post" onsubmit="return confirm('Are you sure you want to mark this loan as fully paid?')">
                                    <input type="hidden" name="loan_id" value="<?php echo $loan['id']; ?>">
                                    <button type="submit" class="btn btn-success w-100">
                                        <i class="fas fa-check-circle me-2"></i>Mark as Fully Paid
                                    </button>
                                </form>
                            </div>
                            <div class="col-md-6">
                                <form action="mark_loan_overdue.php" method="post" onsubmit="return confirm('Are you sure you want to mark this loan as overdue?')">
                                    <input type="hidden" name="loan_id" value="<?php echo $loan['id']; ?>">
                                    <button type="submit" class="btn btn-danger w-100">
                                        <i class="fas fa-exclamation-circle me-2"></i>Mark as Overdue
                                    </button>
                                </form>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Repayment History -->
                <?php if (!empty($repayments)): ?>
                <div class="card mb-4">
                    <div class="card-header">
                        <h5 class="mb-0">Repayment History</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Date</th>
                                        <th>Amount</th>
                                        <th>Payment Method</th>
                                        <th>Transaction ID</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($repayments as $repayment): ?>
                                    <tr>
                                        <td><?php echo date('M d, Y', strtotime($repayment['created_at'])); ?></td>
                                        <td>$<?php echo number_format($repayment['amount'], 2); ?></td>
                                        <td><?php echo $repayment['payment_method']; ?></td>
                                        <td><?php echo $repayment['transaction_id']; ?></td>
                                        <td>
                                            <span class="badge bg-<?php echo $repayment['status'] === 'confirmed' ? 'success' : 'warning'; ?>">
                                                <?php echo ucfirst($repayment['status']); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <a href="../uploads/loan_payments/<?php echo $repayment['proof_image']; ?>" target="_blank" class="btn btn-sm btn-info">
                                                <i class="fas fa-image"></i> View Proof
                                            </a>
                                            <?php if ($repayment['status'] === 'pending'): ?>
                                            <a href="confirm_loan_payment.php?id=<?php echo $repayment['id']; ?>" class="btn btn-sm btn-success" onclick="return confirm('Are you sure you want to confirm this payment?')">
                                                <i class="fas fa-check"></i> Confirm
                                            </a>
                                            <a href="reject_loan_payment.php?id=<?php echo $repayment['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to reject this payment?')">
                                                <i class="fas fa-times"></i> Reject
                                            </a>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            </main>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
