<?php
session_start();
require_once '../config/config.php';
require_once '../includes/auth_check.php';
require_once '../includes/functions.php';
require_once '../includes/copytrade.php';

// Check if user is admin
requireAdmin();
requireOTPVerification();

// Get all traders
$traders = getMasterTraders();

// Handle trader actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action']) && isset($_POST['trader_id'])) {
        $action = $_POST['action'];
        $traderId = $_POST['trader_id'];
        
        switch ($action) {
            case 'activate':
                $stmt = $conn->prepare("UPDATE users SET status = 'active' WHERE id = ? AND role = 'trader'");
                $stmt->bind_param("i", $traderId);
                $stmt->execute();
                header("Location: manage_traders.php");
                exit();
                break;
                
            case 'deactivate':
                $stmt = $conn->prepare("UPDATE users SET status = 'inactive' WHERE id = ? AND role = 'trader'");
                $stmt->bind_param("i", $traderId);
                $stmt->execute();
                header("Location: manage_traders.php");
                exit();
                break;
                
            case 'delete':
                // First check if there are active copy trades
                $stmt = $conn->prepare("SELECT COUNT(*) as count FROM copy_trades WHERE trader_id = ? AND status = 'active'");
                $stmt->bind_param("i", $traderId);
                $stmt->execute();
                $result = $stmt->get_result()->fetch_assoc();
                
                if ($result['count'] > 0) {
                    $_SESSION['error'] = "Cannot delete trader with active copy trades. Please stop all copy trades first.";
                } else {
                    // Delete trader record
                    $stmt = $conn->prepare("DELETE FROM traders WHERE user_id = ?");
                    $stmt->bind_param("i", $traderId);
                    $stmt->execute();
                    
                    // Update user role back to regular user
                    $stmt = $conn->prepare("UPDATE users SET role = 'user' WHERE id = ?");
                    $stmt->bind_param("i", $traderId);
                    $stmt->execute();
                    
                    $_SESSION['success'] = "Trader has been deleted successfully";
                }
                
                header("Location: manage_traders.php");
                exit();
                break;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Traders - <?php echo APP_NAME; ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <?php include 'includes/sidebar.php'; ?>
            
            <!-- Main Content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Manage Traders</h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <a href="add_trader.php" class="btn btn-sm btn-primary">
                            <i class="fas fa-plus"></i> Add New Trader
                        </a>
                    </div>
                </div>
                
                <?php if (isset($_SESSION['error'])): ?>
                    <div class="alert alert-danger"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
                <?php endif; ?>
                
                <?php if (isset($_SESSION['success'])): ?>
                    <div class="alert alert-success"><?php echo $_SESSION['success']; unset($_SESSION['success']); ?></div>
                <?php endif; ?>
                
                <div class="card">
                    <div class="card-header bg-light">
                        <div class="row">
                            <div class="col-md-12 d-flex justify-content-between">
                                <div>
                                    <button class="btn btn-sm btn-secondary">Copy</button>
                                    <button class="btn btn-sm btn-secondary">CSV</button>
                                    <button class="btn btn-sm btn-secondary">Print</button>
                                </div>
                                <div class="input-group" style="width: 300px;">
                                    <input type="text" class="form-control form-control-sm" placeholder="Search...">
                                    <button class="btn btn-sm btn-outline-secondary" type="button">Search</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th>Profile</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Success Rate</th>
                                        <th>Total Trades</th>
                                        <th>Profitable Trades</th>
                                        <th>Followers</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (empty($traders)): ?>
                                        <tr>
                                            <td colspan="9" class="text-center">No traders found</td>
                                        </tr>
                                    <?php else: ?>
                                        <?php foreach ($traders as $trader): ?>
                                            <tr>
                                                <td>
                                                    <img src="<?php echo !empty($trader['profile_picture']) ? '../uploads/profile/' . $trader['profile_picture'] : '../assets/img/default-avatar.png'; ?>" 
                                                         alt="Profile" class="rounded-circle" width="40" height="40">
                                                </td>
                                                <td><?php echo $trader['first_name'] . ' ' . $trader['last_name']; ?></td>
                                                <td><?php echo $trader['email']; ?></td>
                                                <td><?php echo number_format($trader['success_rate'], 2); ?>%</td>
                                                <td><?php echo $trader['total_trades']; ?></td>
                                                <td><?php echo $trader['profitable_trades']; ?></td>
                                                <td>
                                                    <?php
                                                    $stmt = $conn->prepare("SELECT COUNT(*) as count FROM copy_trades WHERE trader_id = ? AND status = 'active'");
                                                    $stmt->bind_param("i", $trader['id']);
                                                    $stmt->execute();
                                                    $result = $stmt->get_result()->fetch_assoc();
                                                    echo $result['count'];
                                                    ?>
                                                </td>
                                                <td>
                                                    <span class="badge bg-<?php echo $trader['status'] === 'active' ? 'success' : 'danger'; ?>">
                                                        <?php echo ucfirst($trader['status']); ?>
                                                    </span>
                                                </td>
                                                <td>
                                                    <div class="btn-group">
                                                        <a href="trader_details.php?id=<?php echo $trader['id']; ?>" class="btn btn-sm btn-primary">
                                                            <i class="fas fa-eye"></i>
                                                        </a>
                                                        <a href="edit_trader.php?id=<?php echo $trader['id']; ?>" class="btn btn-sm btn-warning">
                                                            <i class="fas fa-edit"></i>
                                                        </a>
                                                        <button type="button" class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#deleteModal<?php echo $trader['id']; ?>">
                                                            <i class="fas fa-trash"></i>
                                                        </button>
                                                    </div>
                                                </td>
                                            </tr>
                                            
                                            <!-- Delete Modal -->
                                            <div class="modal fade" id="deleteModal<?php echo $trader['id']; ?>" tabindex="-1" aria-labelledby="deleteModalLabel<?php echo $trader['id']; ?>" aria-hidden="true">
                                                <div class="modal-dialog">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="deleteModalLabel<?php echo $trader['id']; ?>">Confirm Delete</h5>
                                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                        </div>
                                                        <div class="modal-body">
                                                            Are you sure you want to delete this trader? This action cannot be undone.
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                                            <form method="POST" action="">
                                                                <input type="hidden" name="trader_id" value="<?php echo $trader['id']; ?>">
                                                                <input type="hidden" name="action" value="delete">
                                                                <button type="submit" class="btn btn-danger">Delete</button>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="card-footer">
                        <nav aria-label="Page navigation">
                            <ul class="pagination justify-content-end">
                                <li class="page-item disabled">
                                    <a class="page-link" href="#" tabindex="-1">Previous</a>
                                </li>
                                <li class="page-item active"><a class="page-link" href="#">1</a></li>
                                <li class="page-item"><a class="page-link" href="#">2</a></li>
                                <li class="page-item"><a class="page-link" href="#">3</a></li>
                                <li class="page-item">
                                    <a class="page-link" href="#">Next</a>
                                </li>
                            </ul>
                        </nav>
                    </div>
                </div>
            </main>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
