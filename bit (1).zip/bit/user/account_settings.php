<?php
session_start();
require_once '../config/config.php';
require_once '../includes/auth_check.php';
require_once '../includes/functions.php';

// Check if user is logged in
requireLogin();

// Get user data
$user = getUserById($_SESSION['user_id']);

// Handle form submissions
$success = '';
$error = '';

// Handle password change
if (isset($_POST['change_password'])) {
    $oldPassword = $_POST['old_password'] ?? '';
    $newPassword = $_POST['new_password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';
    
    if (empty($oldPassword) || empty($newPassword) || empty($confirmPassword)) {
        $error = "All password fields are required";
    } elseif ($newPassword !== $confirmPassword) {
        $error = "New passwords do not match";
    } elseif (!password_verify($oldPassword, $user['password'])) {
        $error = "Current password is incorrect";
    } else {
        $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
        $stmt->bind_param("si", $hashedPassword, $_SESSION['user_id']);
        
        if ($stmt->execute()) {
            $success = "Password updated successfully";
        } else {
            $error = "Failed to update password";
        }
    }
}

// Handle profile update
if (isset($_POST['update_profile'])) {
    $firstName = $_POST['first_name'] ?? '';
    $lastName = $_POST['last_name'] ?? '';
    $phone = $_POST['phone'] ?? '';
    $country = $_POST['country'] ?? '';
    $state = $_POST['state'] ?? '';
    $address = $_POST['address'] ?? '';
    $postalCode = $_POST['postal_code'] ?? '';
    
    $stmt = $conn->prepare("UPDATE users SET first_name = ?, last_name = ?, phone = ?, country = ?, state = ?, address = ?, postal_code = ? WHERE id = ?");
    $stmt->bind_param("sssssssi", $firstName, $lastName, $phone, $country, $state, $address, $postalCode, $_SESSION['user_id']);
    
    if ($stmt->execute()) {
        $success = "Profile updated successfully";
        // Refresh user data
        $user = getUserById($_SESSION['user_id']);
    } else {
        $error = "Failed to update profile";
    }
}

// Handle profile image upload
if (isset($_FILES['profile_image']) && $_FILES['profile_image']['error'] === UPLOAD_ERR_OK) {
    $allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
    $maxSize = 2 * 1024 * 1024; // 2MB
    
    if (!in_array($_FILES['profile_image']['type'], $allowedTypes)) {
        $error = "Invalid file type. Only JPG, PNG, and GIF are allowed.";
    } elseif ($_FILES['profile_image']['size'] > $maxSize) {
        $error = "File size exceeds the limit of 2MB.";
    } else {
        $fileName = 'profile_' . $_SESSION['user_id'] . '_' . time() . '.' . pathinfo($_FILES['profile_image']['name'], PATHINFO_EXTENSION);
        $uploadDir = '../uploads/profile/';
        
        // Create directory if it doesn't exist
        if (!file_exists($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }
        
        $uploadPath = $uploadDir . $fileName;
        
        if (move_uploaded_file($_FILES['profile_image']['tmp_name'], $uploadPath)) {
            $stmt = $conn->prepare("UPDATE users SET profile_image = ? WHERE id = ?");
            $stmt->bind_param("si", $fileName, $_SESSION['user_id']);
            $stmt->execute();
            $success = "Profile image uploaded successfully";
            // Refresh user data
            $user = getUserById($_SESSION['user_id']);
        } else {
            $error = "Failed to upload profile image. Please try again.";
        }
    }
}

// Get user's theme preference
$theme = $user['theme'] ?? 'dark';

// Get referral code
$referralCode = $user['referral_code'] ?? generateReferralCode();
if (empty($user['referral_code'])) {
    $stmt = $conn->prepare("UPDATE users SET referral_code = ? WHERE id = ?");
    $stmt->bind_param("si", $referralCode, $_SESSION['user_id']);
    $stmt->execute();
}

$referralLink = APP_URL . '/ref/' . $referralCode;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Account Settings - <?php echo APP_NAME; ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <?php if ($theme === 'dark'): ?>
    <link rel="stylesheet" href="../assets/css/dark-theme.css">
    <?php else: ?>
    <link rel="stylesheet" href="../assets/css/light-theme.css">
    <?php endif; ?>
</head>
<body class="<?php echo $theme; ?>-theme">
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <?php include 'includes/sidebar.php'; ?>
            
            <!-- Main Content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
                <!-- Top Navigation Bar -->
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3">
                    <div class="d-flex align-items-center">
                        <?php if (!empty($user['profile_image'])): ?>
                            <img src="../uploads/profile/<?php echo $user['profile_image']; ?>" alt="Profile" class="rounded-circle me-2" style="width: 40px; height: 40px; object-fit: cover;">
                        <?php else: ?>
                            <div class="rounded-circle bg-secondary text-white d-flex align-items-center justify-content-center me-2" style="width: 40px; height: 40px;">
                                <?php echo strtoupper(substr($user['first_name'], 0, 1)); ?>
                            </div>
                        <?php endif; ?>
                        <div>
                            <h6 class="mb-0"><?php echo $user['first_name'] . ' ' . $user['last_name']; ?></h6>
                            <small class="text-muted"><?php echo $user['email']; ?></small>
                        </div>
                    </div>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <a href="account.php" class="btn btn-sm btn-primary me-2">
                            <i class="fas fa-user-circle"></i> Account
                        </a>
                        <a href="deposit.php" class="btn btn-sm btn-success me-2">
                            <i class="fas fa-money-bill-wave"></i> Make Deposit
                        </a>
                        <a href="withdraw.php" class="btn btn-sm btn-warning me-2">
                            <i class="fas fa-money-bill-transfer"></i> Withdraw Funds
                        </a>
                        <a href="contact.php" class="btn btn-sm btn-info me-2">
                            <i class="fas fa-envelope"></i> Mail Us
                        </a>
                        <a href="settings.php" class="btn btn-sm btn-danger">
                            <i class="fas fa-cog"></i> Settings
                        </a>
                    </div>
                </div>
                
                <?php if (!empty($error)): ?>
                    <div class="alert alert-danger"><?php echo $error; ?></div>
                <?php endif; ?>
                
                <?php if (!empty($success)): ?>
                    <div class="alert alert-success"><?php echo $success; ?></div>
                <?php endif; ?>
                
                <!-- Tabs Navigation -->
                <ul class="nav nav-tabs mb-4" id="accountTabs" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="personal-tab" data-bs-toggle="tab" data-bs-target="#personal" type="button" role="tab" aria-controls="personal" aria-selected="false">Personal Profile</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="records-tab" data-bs-toggle="tab" data-bs-target="#records" type="button" role="tab" aria-controls="records" aria-selected="false">Account Records</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="settings-tab" data-bs-toggle="tab" data-bs-target="#settings" type="button" role="tab" aria-controls="settings" aria-selected="true">Account Settings</button>
                    </li>
                </ul>
                
                <!-- Tab Content -->
                <div class="tab-content" id="accountTabsContent">
                    <!-- Personal Profile Tab -->
                    <div class="tab-pane fade" id="personal" role="tabpanel" aria-labelledby="personal-tab">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title">Personal Profile Info</h5>
                                <form method="POST" action="">
                                    <div class="row mb-3">
                                        <div class="col-md-12">
                                            <label for="full_name" class="form-label">
                                                <i class="fas fa-user"></i> Full Name
                                            </label>
                                            <input type="text" class="form-control" id="full_name" name="first_name" value="<?php echo $user['first_name'] . ' ' . $user['last_name']; ?>">
                                        </div>
                                    </div>
                                    
                                    <div class="row mb-3">
                                        <div class="col-md-6">
                                            <label for="username" class="form-label">
                                                <i class="fas fa-user-tag"></i> Username
                                            </label>
                                            <input type="text" class="form-control" id="username" name="username" value="<?php echo $user['username'] ?? ''; ?>" readonly>
                                        </div>
                                        <div class="col-md-6">
                                            <label for="email" class="form-label">
                                                <i class="fas fa-envelope"></i> Email Address
                                            </label>
                                            <input type="email" class="form-control" id="email" name="email" value="<?php echo $user['email']; ?>" readonly>
                                        </div>
                                    </div>
                                    
                                    <div class="row mb-3">
                                        <div class="col-md-6">
                                            <label for="phone" class="form-label">
                                                <i class="fas fa-phone"></i> Phone Number
                                            </label>
                                            <input type="text" class="form-control" id="phone" name="phone" value="<?php echo $user['phone']; ?>">
                                        </div>
                                        <div class="col-md-6">
                                            <label for="country" class="form-label">
                                                <i class="fas fa-globe"></i> Country
                                            </label>
                                            <input type="text" class="form-control" id="country" name="country" value="<?php echo $user['country'] ?? ''; ?>">
                                        </div>
                                    </div>
                                    
                                    <div class="row mb-3">
                                        <div class="col-md-6">
                                            <label for="state" class="form-label">
                                                <i class="fas fa-map-marker-alt"></i> State/Province
                                            </label>
                                            <input type="text" class="form-control" id="state" name="state" value="<?php echo $user['state'] ?? ''; ?>">
                                        </div>
                                        <div class="col-md-6">
                                            <label for="postal_code" class="form-label">
                                                <i class="fas fa-map-pin"></i> Postal/Zip Code
                                            </label>
                                            <input type="text" class="form-control" id="postal_code" name="postal_code" value="<?php echo $user['postal_code'] ?? ''; ?>">
                                        </div>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="address" class="form-label">
                                            <i class="fas fa-home"></i> Address
                                        </label>
                                        <textarea class="form-control" id="address" name="address" rows="3"><?php echo $user['address'] ?? ''; ?></textarea>
                                    </div>
                                    
                                    <div class="d-flex justify-content-between">
                                        <div>
                                            <span class="badge bg-<?php echo $user['status'] === 'active' ? 'success' : 'danger'; ?>">
                                                <i class="fas fa-circle"></i> Account Status: <?php echo ucfirst($user['status']); ?>
                                            </span>
                                            
                                            <span class="badge bg-<?php echo $user['kyc_verified'] === 'yes' ? 'success' : 'warning'; ?> ms-2">
                                                <i class="fas fa-id-card"></i> KYC: <?php echo $user['kyc_verified'] === 'yes' ? 'Verified' : 'Not Verified'; ?>
                                            </span>
                                        </div>
                                        <button type="submit" name="update_profile" class="btn btn-primary">
                                            <i class="fas fa-save"></i> Update Profile
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Account Records Tab -->
                    <div class="tab-pane fade" id="records" role="tabpanel" aria-labelledby="records-tab">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title">Account Records</h5>
                                <div class="table-responsive">
                                    <table class="table table-hover">
                                        <thead>
                                            <tr>
                                                <th>Type</th>
                                                <th>Amount</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>Total Investment</td>
                                                <td>$<?php echo number_format(getTotalInvestment($_SESSION['user_id']), 2); ?></td>
                                            </tr>
                                            <tr>
                                                <td>Total Earnings</td>
                                                <td>$<?php echo number_format(getTotalEarnings($_SESSION['user_id']), 2); ?></td>
                                            </tr>
                                            <tr>
                                                <td>Total Balance</td>
                                                <td>$<?php echo number_format($user['balance'], 2); ?></td>
                                            </tr>
                                            <tr>
                                                <td>Total Referral</td>
                                                <td>$<?php echo number_format(getTotalReferralBonus($_SESSION['user_id']), 2); ?></td>
                                            </tr>
                                            <tr>
                                                <td>Total Bonus</td>
                                                <td>$<?php echo number_format(getTotalBonus($_SESSION['user_id']), 2); ?></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                                <div class="d-flex justify-content-between mt-3">
                                    <a href="transactions.php" class="btn btn-primary">
                                        <i class="fas fa-list"></i> View Transactions
                                    </a>
                                    <a href="history.php" class="btn btn-info">
                                        <i class="fas fa-chart-line"></i> View Trade History
                                    </a>
                                </div>
                            </div>
                        </div>
                        
                        <div class="card mt-4">
                            <div class="card-body">
                                <h5 class="card-title">Referral Link</h5>
                                <div class="input-group mb-3">
                                    <input type="text" class="form-control" value="<?php echo $referralLink; ?>" id="referralLink" readonly>
                                    <button class="btn btn-primary" type="button" onclick="copyReferralLink()">
                                        <i class="fas fa-copy"></i> Copy Referral Link
                                    </button>
                                </div>
                                <p class="text-muted">Share this link with your friends and earn commission on their trades.</p>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Account Settings Tab -->
                    <div class="tab-pane fade show active" id="settings" role="tabpanel" aria-labelledby="settings-tab">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="card">
                                    <div class="card-body">
                                        <h5 class="card-title">CHANGE PASSWORD</h5>
                                        <form method="POST" action="">
                                            <div class="mb-3">
                                                <label for="old_password" class="form-label">Old Password</label>
                                                <input type="password" class="form-control" id="old_password" name="old_password" required>
                                            </div>
                                            <div class="mb-3">
                                                <label for="new_password" class="form-label">New Password</label>
                                                <input type="password" class="form-control" id="new_password" name="new_password" required>
                                            </div>
                                            <div class="mb-3">
                                                <label for="confirm_password" class="form-label">Rewrite New Password</label>
                                                <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                                            </div>
                                            <div class="d-flex justify-content-between">
                                                <button type="reset" class="btn btn-secondary">Clear</button>
                                                <button type="submit" name="change_password" class="btn btn-primary">Change Password</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-md-6">
                                <div class="card">
                                    <div class="card-body">
                                        <h5 class="card-title">CHANGE PROFILE IMAGE</h5>
                                        <form method="POST" action="" enctype="multipart/form-data">
                                            <div class="mb-3 text-center">
                                                <?php if (!empty($user['profile_image'])): ?>
                                                    <img src="../uploads/profile/<?php echo $user['profile_image']; ?>" alt="Profile" class="img-thumbnail mb-3" style="max-width: 150px; max-height: 150px;">
                                                <?php else: ?>
                                                    <div class="bg-secondary text-white d-flex align-items-center justify-content-center mx-auto mb-3" style="width: 150px; height: 150px; border-radius: 5px;">
                                                        <i class="fas fa-user fa-5x"></i>
                                                    </div>
                                                <?php endif; ?>
                                                
                                                <div class="mb-3">
                                                    <input type="file" class="form-control" id="profile_image" name="profile_image" accept="image/*" required>
                                                </div>
                                                <button type="submit" name="upload_image" class="btn btn-primary">Change Profile Image</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                                
                                <div class="card mt-4">
                                    <div class="card-body">
                                        <h5 class="card-title">THEME SETTINGS</h5>
                                        <form method="POST" action="update_theme.php">
                                            <div class="mb-3">
                                                <label class="form-label">Select Theme</label>
                                                <div class="d-flex">
                                                    <div class="form-check me-3">
                                                        <input class="form-check-input" type="radio" name="theme" id="darkTheme" value="dark" <?php echo $theme === 'dark' ? 'checked' : ''; ?>>
                                                        <label class="form-check-label" for="darkTheme">
                                                            Dark Theme
                                                        </label>
                                                    </div>
                                                    <div class="form-check">
                                                        <input class="form-check-input" type="radio" name="theme" id="lightTheme" value="light" <?php echo $theme === 'light' ? 'checked' : ''; ?>>
                                                        <label class="form-check-label" for="lightTheme">
                                                            Light Theme
                                                        </label>
                                                    </div>
                                                </div>
                                            </div>
                                            <button type="submit" class="btn btn-primary">Update Theme</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="card mt-4">
                            <div class="card-body">
                                <h5 class="card-title">Referral Link</h5>
                                <div class="input-group mb-3">
                                    <input type="text" class="form-control" value="<?php echo $referralLink; ?>" id="referralLinkSettings" readonly>
                                    <button class="btn btn-primary" type="button" onclick="copyReferralLinkSettings()">
                                        <i class="fas fa-copy"></i> Copy Referral Link
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function copyReferralLink() {
            var copyText = document.getElementById("referralLink");
            copyText.select();
            copyText.setSelectionRange(0, 99999);
            document.execCommand("copy");
            alert("Referral link copied to clipboard: " + copyText.value);
        }
        
        function copyReferralLinkSettings() {
            var copyText = document.getElementById("referralLinkSettings");
            copyText.select();
            copyText.setSelectionRange(0, 99999);
            document.execCommand("copy");
            alert("Referral link copied to clipboard: " + copyText.value);
        }
    </script>
</body>
</html>
