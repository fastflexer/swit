<?php
session_start();
require_once '../config/config.php';
require_once '../includes/auth_check.php';
require_once '../includes/functions.php';

// Check if user is admin
requireAdmin();
requireOTPVerification();

// Get all withdrawals
$withdrawals = getAllWithdrawals();

// Handle withdrawal actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
   if (isset($_POST['action']) && isset($_POST['withdrawal_id'])) {
       $action = $_POST['action'];
       $withdrawalId = $_POST['withdrawal_id'];
       $adminNote = $_POST['admin_note'] ?? '';
       
       switch ($action) {
           case 'approve':
               $stmt = $conn->prepare("UPDATE withdrawals SET status = 'processed', processed_at = NOW(), processed_by = ?, admin_note = ? WHERE id = ?");
               $stmt->bind_param("isi", $_SESSION['user_id'], $adminNote, $withdrawalId);
               $stmt->execute();
               
               // Get withdrawal details for email notification
               $stmt = $conn->prepare("SELECT w.*, u.email, u.first_name, u.last_name FROM withdrawals w JOIN users u ON w.user_id = u.id WHERE w.id = ?");
               $stmt->bind_param("i", $withdrawalId);
               $stmt->execute();
               $result = $stmt->get_result();
               $withdrawal = $result->fetch_assoc();
               
               // Send email notification
               $subject = APP_NAME . " - Withdrawal Approved";
               $message = "
                   <html>
                   <head>
                       <title>Withdrawal Approved</title>
                   </head>
                   <body>
                       <h2>Withdrawal Approved</h2>
                       <p>Dear " . $withdrawal['first_name'] . " " . $withdrawal['last_name'] . ",</p>
                       <p>Your withdrawal request has been approved and processed.</p>
                       <p><strong>Amount:</strong> $" . number_format($withdrawal['amount'], 2) . "</p>
                       <p><strong>Fee:</strong> $" . number_format($withdrawal['fee'], 2) . "</p>
                       <p><strong>Net Amount:</strong> $" . number_format($withdrawal['amount'] - $withdrawal['fee'], 2) . "</p>
                       <p><strong>Payment Method:</strong> " . $withdrawal['payment_method'] . "</p>
                       <p><strong>Wallet Address:</strong> " . $withdrawal['wallet_address'] . "</p>
                       <p>The funds have been sent to your provided address. Please allow some time for the transaction to be confirmed.</p>
                       <p>Regards,<br>" . APP_NAME . " Team</p>
                   </body>
                   </html>
               ";
               
               sendEmail($withdrawal['email'], $subject, $message);
               
               $_SESSION['success'] = "Withdrawal has been approved successfully.";
               break;
               
           case 'reject':
               // Get withdrawal amount and user ID
               $stmt = $conn->prepare("SELECT amount, user_id FROM withdrawals WHERE id = ?");
               $stmt->bind_param("i", $withdrawalId);
               $stmt->execute();
               $result = $stmt->get_result();
               $withdrawal = $result->fetch_assoc();
               
               // Start transaction
               $conn->begin_transaction();
               
               try {
                   // Update withdrawal status
                   $stmt = $conn->prepare("UPDATE withdrawals SET status = 'rejected', processed_at = NOW(), processed_by = ?, admin_note = ? WHERE id = ?");
                   $stmt->bind_param("isi", $_SESSION['user_id'], $adminNote, $withdrawalId);
                   $stmt->execute();
                   
                   // Refund the amount to user's balance
                   $stmt = $conn->prepare("UPDATE users SET balance = balance + ? WHERE id = ?");
                   $stmt->bind_param("di", $withdrawal['amount'], $withdrawal['user_id']);
                   $stmt->execute();
                   
                   // Commit transaction
                   $conn->commit();
                   
                   // Get user email for notification
                   $stmt = $conn->prepare("SELECT email, first_name, last_name FROM users WHERE id = ?");
                   $stmt->bind_param("i", $withdrawal['user_id']);
                   $stmt->execute();
                   $result = $stmt->get_result();
                   $user = $result->fetch_assoc();
                   
                   // Send email notification
                   $subject = APP_NAME . " - Withdrawal Rejected";
                   $message = "
                       <html>
                       <head>
                           <title>Withdrawal Rejected</title>
                       </head>
                       <body>
                           <h2>Withdrawal Rejected</h2>
                           <p>Dear " . $user['first_name'] . " " . $user['last_name'] . ",</p>
                           <p>Your withdrawal request has been rejected.</p>
                           <p><strong>Amount:</strong> $" . number_format($withdrawal['amount'], 2) . "</p>
                           <p><strong>Reason:</strong> " . $adminNote . "</p>
                           <p>The funds have been returned to your account balance.</p>
                           <p>If you have any questions, please contact our support team.</p>
                           <p>Regards,<br>" . APP_NAME . " Team</p>
                       </body>
                       </html>
                   ";
                   
                   sendEmail($user['email'], $subject, $message);
                   
                   $_SESSION['success'] = "Withdrawal has been rejected and funds returned to user's balance.";
               } catch (Exception $e) {
                   // Rollback transaction on error
                   $conn->rollback();
                   $_SESSION['error'] = "Failed to reject withdrawal: " . $e->getMessage();
               }
               break;
               
           case 'block':
               $stmt = $conn->prepare("UPDATE withdrawals SET status = 'blocked', processed_at = NOW(), processed_by = ?, admin_note = ? WHERE id = ?");
               $stmt->bind_param("isi", $_SESSION['user_id'], $adminNote, $withdrawalId);
               $stmt->execute();
               
               // Get withdrawal details for email notification
               $stmt = $conn->prepare("SELECT w.*, u.email, u.first_name, u.last_name FROM withdrawals w JOIN users u ON w.user_id = u.id WHERE w.id = ?");
               $stmt->bind_param("i", $withdrawalId);
               $stmt->execute();
               $result = $stmt->get_result();
               $withdrawal = $result->fetch_assoc();
               
               // Send email notification
               $subject = APP_NAME . " - Withdrawal Blocked";
               $message = "
                   <html>
                   <head>
                       <title>Withdrawal Blocked</title>
                   </head>
                   <body>
                       <h2>Withdrawal Blocked</h2>
                       <p>Dear " . $withdrawal['first_name'] . " " . $withdrawal['last_name'] . ",</p>
                       <p>Your withdrawal request has been blocked due to security concerns or policy violations.</p>
                       <p><strong>Amount:</strong> $" . number_format($withdrawal['amount'], 2) . "</p>
                       <p><strong>Reason:</strong> " . $adminNote . "</p>
                       <p>Please contact our support team immediately to resolve this issue.</p>
                       <p>Regards,<br>" . APP_NAME . " Team</p>
                   </body>
                   </html>
               ";
               
               sendEmail($withdrawal['email'], $subject, $message);
               
               $_SESSION['success'] = "Withdrawal has been blocked successfully.";
               break;
               
           case 'delete':
               $stmt = $conn->prepare("DELETE FROM withdrawals WHERE id = ?");
               $stmt->bind_param("i", $withdrawalId);
               $stmt->execute();
               $_SESSION['success'] = "Withdrawal has been deleted successfully.";
               break;
       }
       
       // Refresh withdrawals
       $withdrawals = getAllWithdrawals();
   }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Manage Withdrawals - <?php echo APP_NAME; ?></title>
   <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
   <link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body>
   <div class="container-fluid">
       <div class="row">
           <!-- Sidebar -->
           <?php include 'includes/sidebar.php'; ?>
           
           <!-- Main Content -->
           <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
               <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                   <h1 class="h2">Manage clients withdrawals</h1>
                   <div class="btn-toolbar mb-2 mb-md-0">
                       <div class="input-group">
                           <input type="text" class="form-control" placeholder="Search...">
                           <button class="btn btn-outline-secondary" type="button">Search</button>
                       </div>
                   </div>
               </div>
               
               <?php if (isset($_SESSION['error'])): ?>
                   <div class="alert alert-danger"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
               <?php endif; ?>
               
               <?php if (isset($_SESSION['success'])): ?>
                   <div class="alert alert-success"><?php echo $_SESSION['success']; unset($_SESSION['success']); ?></div>
               <?php endif; ?>
               
               <div class="card">
                   <div class="card-header bg-light">
                       <div class="row">
                           <div class="col-md-12 d-flex justify-content-between">
                               <div>
                                   <button class="btn btn-sm btn-secondary">Copy</button>
                                   <button class="btn btn-sm btn-secondary">CSV</button>
                                   <button class="btn btn-sm btn-secondary">Print</button>
                               </div>
                           </div>
                       </div>
                   </div>
                   <div class="card-body">
                       <div class="table-responsive">
                           <table class="table table-striped table-hover">
                               <thead>
                                   <tr>
                                       <th>ID</th>
                                       <th>Client name</th>
                                       <th>Amount requested</th>
                                       <th>Amount + charges</th>
                                       <th>Payment Method</th>
                                       <th>Receiver's email</th>
                                       <th>Status</th>
                                       <th>Date created</th>
                                       <th>Option</th>
                                   </tr>
                               </thead>
                               <tbody>
                                   <?php foreach ($withdrawals as $withdrawal): ?>
                                   <tr>
                                       <td><?php echo $withdrawal['id']; ?></td>
                                       <td><?php echo $withdrawal['first_name'] . ' ' . $withdrawal['last_name']; ?></td>
                                       <td>$<?php echo number_format($withdrawal['amount'], 2); ?></td>
                                       <td>$<?php echo number_format($withdrawal['amount'] + ($withdrawal['fee'] ?? 0), 2); ?></td>
                                       <td><?php echo $withdrawal['payment_method']; ?></td>
                                       <td><?php echo $withdrawal['wallet_address'] ?? $withdrawal['email']; ?></td>
                                       <td>
                                           <span class="badge bg-<?php 
                                               echo $withdrawal['status'] === 'processed' ? 'success' : 
                                                   ($withdrawal['status'] === 'pending' ? 'warning' : 
                                                   ($withdrawal['status'] === 'blocked' ? 'danger' : 'danger')); 
                                           ?>">
                                               <?php echo $withdrawal['status']; ?>
                                           </span>
                                       </td>
                                       <td><?php echo date('D, M j, Y g:i A', strtotime($withdrawal['created_at'])); ?></td>
                                       <td>
                                           <button class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#viewModal<?php echo $withdrawal['id']; ?>">
                                               <i class="fas fa-eye"></i> View
                                           </button>
                                       </td>
                                   </tr>
                                   <?php endforeach; ?>
                               </tbody>
                           </table>
                       </div>
                   </div>
                   <div class="card-footer">
                       <nav aria-label="Page navigation">
                           <ul class="pagination justify-content-end">
                               <li class="page-item disabled">
                                   <a class="page-link" href="#" tabindex="-1">Previous</a>
                               </li>
                               <li class="page-item active"><a class="page-link" href="#">1</a></li>
                               <li class="page-item"><a class="page-link" href="#">2</a></li>
                               <li class="page-item"><a class="page-link" href="#">3</a></li>
                               <li class="page-item">
                                   <a class="page-link" href="#">Next</a>
                               </li>
                           </ul>
                       </nav>
                   </div>
               </div>
           </main>
       </div>
   </div>
   
   <!-- View Withdrawal Modal -->
   <?php foreach ($withdrawals as $withdrawal): ?>
   <div class="modal fade" id="viewModal<?php echo $withdrawal['id']; ?>" tabindex="-1" aria-labelledby="viewModalLabel<?php echo $withdrawal['id']; ?>" aria-hidden="true">
       <div class="modal-dialog modal-lg">
           <div class="modal-content">
               <div class="modal-header">
                   <h5 class="modal-title" id="viewModalLabel<?php echo $withdrawal['id']; ?>">Withdrawal Details</h5>
                   <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
               </div>
               <div class="modal-body">
                   <div class="row">
                       <div class="col-md-6">
                           <div class="mb-3">
                               <strong>Client:</strong> <?php echo $withdrawal['first_name'] . ' ' . $withdrawal['last_name']; ?>
                           </div>
                           <div class="mb-3">
                               <strong>Email:</strong> <?php echo $withdrawal['email']; ?>
                           </div>
                           <div class="mb-3">
                               <strong>Amount:</strong> $<?php echo number_format($withdrawal['amount'], 2); ?>
                           </div>
                           <div class="mb-3">
                               <strong>Fee:</strong> $<?php echo number_format($withdrawal['fee'] ?? 0, 2); ?>
                           </div>
                           <div class="mb-3">
                               <strong>Total:</strong> $<?php echo number_format($withdrawal['amount'] + ($withdrawal['fee'] ?? 0), 2); ?>
                           </div>
                       </div>
                       <div class="col-md-6">
                           <div class="mb-3">
                               <strong>Payment Method:</strong> <?php echo $withdrawal['payment_method']; ?>
                           </div>
                           <?php if (!empty($withdrawal['wallet_address'])): ?>
                           <div class="mb-3">
                               <strong>Wallet Address:</strong> <?php echo $withdrawal['wallet_address']; ?>
                           </div>
                           <?php endif; ?>
                           <div class="mb-3">
                               <strong>Status:</strong> 
                               <span class="badge bg-<?php 
                                   echo $withdrawal['status'] === 'processed' ? 'success' : 
                                       ($withdrawal['status'] === 'pending' ? 'warning' : 
                                       ($withdrawal['status'] === 'blocked' ? 'danger' : 'danger')); 
                               ?>">
                                   <?php echo $withdrawal['status']; ?>
                               </span>
                           </div>
                           <div class="mb-3">
                               <strong>Date:</strong> <?php echo date('D, M j, Y g:i A', strtotime($withdrawal['created_at'])); ?>
                           </div>
                           <?php if (!empty($withdrawal['processed_at'])): ?>
                           <div class="mb-3">
                               <strong>Processed Date:</strong> <?php echo date('D, M j, Y g:i A', strtotime($withdrawal['processed_at'])); ?>
                           </div>
                           <?php endif; ?>
                       </div>
                   </div>
                   
                   <?php if (!empty($withdrawal['admin_note'])): ?>
                   <div class="mb-3">
                       <strong>Admin Note:</strong>
                       <p class="mt-1"><?php echo $withdrawal['admin_note']; ?></p>
                   </div>
                   <?php endif; ?>
                   
                   <?php if ($withdrawal['status'] === 'pending'): ?>
                   <div class="mb-3">
                       <label for="admin_note<?php echo $withdrawal['id']; ?>" class="form-label">Admin Note</label>
                       <textarea class="form-control" id="admin_note<?php echo $withdrawal['id']; ?>" rows="3" placeholder="Add notes about this withdrawal"></textarea>
                   </div>
                   <?php endif; ?>
               </div>
               <div class="modal-footer">
                   <?php if ($withdrawal['status'] === 'pending'): ?>
                   <div class="d-flex justify-content-between w-100">
                       <div>
                           <form method="POST" action="" class="d-inline">
                               <input type="hidden" name="withdrawal_id" value="<?php echo $withdrawal['id']; ?>">
                               <input type="hidden" name="action" value="block">
                               <input type="hidden" name="admin_note" id="admin_note_block<?php echo $withdrawal['id']; ?>">
                               <button type="button" class="btn btn-danger" onclick="submitWithNote('block', <?php echo $withdrawal['id']; ?>)">
                                   <i class="fas fa-ban"></i> Block
                               </button>
                           </form>
                           <form method="POST" action="" class="d-inline">
                               <input type="hidden" name="withdrawal_id" value="<?php echo $withdrawal['id']; ?>">
                               <input type="hidden" name="action" value="reject">
                               <input type="hidden" name="admin_note" id="admin_note_reject<?php echo $withdrawal['id']; ?>">
                               <button type="button" class="btn btn-warning" onclick="submitWithNote('reject', <?php echo $withdrawal['id']; ?>)">
                                   <i class="fas fa-times"></i> Reject
                               </button>
                           </form>
                       </div>
                       <div>
                           <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                           <form method="POST" action="" class="d-inline">
                               <input type="hidden" name="withdrawal_id" value="<?php echo $withdrawal['id']; ?>">
                               <input type="hidden" name="action" value="approve">
                               <input type="hidden" name="admin_note" id="admin_note_approve<?php echo $withdrawal['id']; ?>">
                               <button type="button" class="btn btn-success" onclick="submitWithNote('approve', <?php echo $withdrawal['id']; ?>)">
                                   <i class="fas fa-check"></i> Approve
                               </button>
                           </form>
                       </div>
                   </div>
                   <?php else: ?>
                   <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                   <?php endif; ?>
               </div>
           </div>
       </div>
   </div>
   <?php endforeach; ?>
   
   <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
   <script>
       function submitWithNote(action, id) {
           const noteField = document.getElementById('admin_note' + id);
           const noteInput = document.getElementById('admin_note_' + action + id);
           
           if (noteField) {
               noteInput.value = noteField.value;
           }
           
           // Confirm before proceeding
           let confirmMessage = '';
           
           if (action === 'approve') {
               confirmMessage = 'Are you sure you want to approve this withdrawal?';
           } else if (action === 'reject') {
               confirmMessage = 'Are you sure you want to reject this withdrawal? The funds will be returned to the user\'s balance.';
           } else if (action === 'block') {
               confirmMessage = 'Are you sure you want to block this withdrawal? This action is for suspicious or fraudulent activities.';
           }
           
           if (confirm(confirmMessage)) {
               noteInput.closest('form').submit();
           }
       }
   </script>
</body>
</html>
