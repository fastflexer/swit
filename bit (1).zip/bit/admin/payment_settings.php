<?php
session_start();
require_once '../config/config.php';
require_once '../includes/auth_check.php';
require_once '../includes/functions.php';

// Check if user is admin
requireAdmin();
requireOTPVerification();

$error = '';
$success = '';

// Get payment methods
$stmt = $conn->prepare("SELECT * FROM payment_methods ORDER BY id ASC");
$stmt->execute();
$paymentMethods = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Handle payment method actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action']) && isset($_POST['method_id'])) {
        $action = $_POST['action'];
        $methodId = $_POST['method_id'];
        
        switch ($action) {
            case 'enable':
                $stmt = $conn->prepare("UPDATE payment_methods SET status = 'enabled' WHERE id = ?");
                $stmt->bind_param("i", $methodId);
                $stmt->execute();
                $success = "Payment method enabled successfully";
                break;
                
            case 'disable':
                $stmt = $conn->prepare("UPDATE payment_methods SET status = 'disabled' WHERE id = ?");
                $stmt->bind_param("i", $methodId);
                $stmt->execute();
                $success = "Payment method disabled successfully";
                break;
                
            case 'delete':
                $stmt = $conn->prepare("DELETE FROM payment_methods WHERE id = ?");
                $stmt->bind_param("i", $methodId);
                $stmt->execute();
                $success = "Payment method deleted successfully";
                break;
        }
        
        // Refresh payment methods
        $stmt = $conn->prepare("SELECT * FROM payment_methods ORDER BY id ASC");
        $stmt->execute();
        $paymentMethods = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }
    
    // Add new payment method
    if (isset($_POST['add_method'])) {
        $methodName = $_POST['method_name'] ?? '';
        $methodType = $_POST['method_type'] ?? '';
        $usedFor = $_POST['used_for'] ?? '';
        
        if (empty($methodName) || empty($methodType) || empty($usedFor)) {
            $error = "All fields are required";
        } else {
            $stmt = $conn->prepare("INSERT INTO payment_methods (name, type, used_for, status) VALUES (?, ?, ?, 'enabled')");
            $stmt->bind_param("sss", $methodName, $methodType, $usedFor);
            
            if ($stmt->execute()) {
                $success = "Payment method added successfully";
                
                // Refresh payment methods
                $stmt = $conn->prepare("SELECT * FROM payment_methods ORDER BY id ASC");
                $stmt->execute();
                $paymentMethods = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
            } else {
                $error = "Failed to add payment method. Please try again.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Settings - <?php echo APP_NAME; ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <?php include 'includes/sidebar.php'; ?>
            
            <!-- Main Content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Payment Settings</h1>
                </div>
                
                <?php if (!empty($error)): ?>
                    <div class="alert alert-danger"><?php echo $error; ?></div>
                <?php endif; ?>
                
                <?php if (!empty($success)): ?>
                    <div class="alert alert-success"><?php echo $success; ?></div>
                <?php endif; ?>
                
                <ul class="nav nav-tabs mb-4" id="paymentTabs" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="methods-tab" data-bs-toggle="tab" data-bs-target="#methods" type="button" role="tab" aria-controls="methods" aria-selected="true">Payment Methods</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="preference-tab" data-bs-toggle="tab" data-bs-target="#preference" type="button" role="tab" aria-controls="preference" aria-selected="false">Payment Preference</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="coinpayment-tab" data-bs-toggle="tab" data-bs-target="#coinpayment" type="button" role="tab" aria-controls="coinpayment" aria-selected="false">Coinpayment</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="gateways-tab" data-bs-toggle="tab" data-bs-target="#gateways" type="button" role="tab" aria-controls="gateways" aria-selected="false">Gateways</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="transfer-tab" data-bs-toggle="tab" data-bs-target="#transfer" type="button" role="tab" aria-controls="transfer" aria-selected="false">Transfer</button>
                    </li>
                </ul>
                
                <div class="tab-content" id="paymentTabsContent">
                    <!-- Payment Methods Tab -->
                    <div class="tab-pane fade show active" id="methods" role="tabpanel" aria-labelledby="methods-tab">
                        <div class="d-flex justify-content-end mb-3">
                            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addMethodModal">
                                <i class="fas fa-plus"></i> Add New
                            </button>
                        </div>
                        
                        <div class="card">
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-striped table-hover">
                                        <thead>
                                            <tr>
                                                <th>Method Name</th>
                                                <th>Type</th>
                                                <th>Used for</th>
                                                <th>Status</th>
                                                <th>Option</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($paymentMethods as $method): ?>
                                            <tr>
                                                <td><?php echo $method['name']; ?></td>
                                                <td><?php echo $method['type']; ?></td>
                                                <td><?php echo $method['used_for']; ?></td>
                                                <td>
                                                    <span class="badge bg-<?php echo $method['status'] === 'enabled' ? 'success' : 'danger'; ?>">
                                                        <?php echo $method['status']; ?>
                                                    </span>
                                                </td>
                                                <td>
                                                    <div class="btn-group">
                                                        <button class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#editModal<?php echo $method['id']; ?>">
                                                            <i class="fas fa-eye"></i>
                                                        </button>
                                                        <form method="POST" action="">
                                                            <input type="hidden" name="method_id" value="<?php echo $method['id']; ?>">
                                                            <input type="hidden" name="action" value="delete">
                                                            <button type="submit" class="btn btn-sm btn-danger">
                                                                <i class="fas fa-trash"></i>
                                                            </button>
                                                        </form>
                                                    </div>
                                                </td>
                                            </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Other tabs would be implemented similarly -->
                    <div class="tab-pane fade" id="preference" role="tabpanel" aria-labelledby="preference-tab">
                        <div class="card">
                            <div class="card-body">
                                <h5>Payment Preference Settings</h5>
                                <p>This section will contain payment preference settings.</p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="tab-pane fade" id="coinpayment" role="tabpanel" aria-labelledby="coinpayment-tab">
                        <div class="card">
                            <div class="card-body">
                                <h5>Coinpayment Settings</h5>
                                <p>This section will contain Coinpayment integration settings.</p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="tab-pane fade" id="gateways" role="tabpanel" aria-labelledby="gateways-tab">
                        <div class="card">
                            <div class="card-body">
                                <h5>Payment Gateways Settings</h5>
                                <p>This section will contain payment gateway integration settings.</p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="tab-pane fade" id="transfer" role="tabpanel" aria-labelledby="transfer-tab">
                        <div class="card">
                            <div class="card-body">
                                <h5>Transfer Settings</h5>
                                <p>This section will contain transfer settings.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>
    
    <!-- Add Method Modal -->
    <div class="modal fade" id="addMethodModal" tabindex="-1" aria-labelledby="addMethodModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addMethodModalLabel">Add Payment Method</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form method="POST" action="">
                        <div class="mb-3">
                            <label for="method_name" class="form-label">Method Name</label>
                            <input type="text" class="form-control" id="method_name" name="method_name" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="method_type" class="form-label">Type</label>
                            <select class="form-select" id="method_type" name="method_type" required>
                                <option value="crypto">Crypto</option>
                                <option value="currency">Currency</option>
                            </select>
                        </div>
                        
                        <div class="mb-3">
                            <label for="used_for" class="form-label">Used For</label>
                            <select class="form-select" id="used_for" name="used_for" required>
                                <option value="deposit">Deposit</option>
                                <option value="withdrawal">Withdrawal</option>
                                <option value="both">Both</option>
                            </select>
                        </div>
                        
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="submit" name="add_method" class="btn btn-primary">Add Method</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Edit Method Modals -->
    <?php foreach ($paymentMethods as $method): ?>
    <div class="modal fade" id="editModal<?php echo $method['id']; ?>" tabindex="-1" aria-labelledby="editModalLabel<?php echo $method['id']; ?>" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editModalLabel<?php echo $method['id']; ?>">Edit Payment Method</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form method="POST" action="">
                        <input type="hidden" name="method_id" value="<?php echo $method['id']; ?>">
                        
                        <div class="mb-3">
                            <label for="method_name<?php echo $method['id']; ?>" class="form-label">Method Name</label>
                            <input type="text" class="form-control" id="method_name<?php echo $method['id']; ?>" name="method_name" value="<?php echo $method['name']; ?>" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="method_type<?php echo $method['id']; ?>" class="form-label">Type</label>
                            <select class="form-select" id="method_type<?php echo $method['id']; ?>" name="method_type" required>
                                <option value="crypto" <?php echo $method['type'] === 'crypto' ? 'selected' : ''; ?>>Crypto</option>
                                <option value="currency" <?php echo $method['type'] === 'currency' ? 'selected' : ''; ?>>Currency</option>
                            </select>
                        </div>
                        
                        <div class="mb-3">
                            <label for="used_for<?php echo $method['id']; ?>" class="form-label">Used For</label>
                            <select class="form-select" id="used_for<?php echo $method['id']; ?>" name="used_for" required>
                                <option value="deposit" <?php echo $method['used_for'] === 'deposit' ? 'selected' : ''; ?>>Deposit</option>
                                <option value="withdrawal" <?php echo $method['used_for'] === 'withdrawal' ? 'selected' : ''; ?>>Withdrawal</option>
                                <option value="both" <?php echo $method['used_for'] === 'both' ? 'selected' : ''; ?>>Both</option>
                            </select>
                        </div>
                        
                        <div class="mb-3">
                            <label for="status<?php echo $method['id']; ?>" class="form-label">Status</label>
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" id="status<?php echo $method['id']; ?>" name="action" value="<?php echo $method['status'] === 'enabled' ? 'disable' : 'enable'; ?>" <?php echo $method['status'] === 'enabled' ? 'checked' : ''; ?>>
                                <label class="form-check-label" for="status<?php echo $method['id']; ?>"><?php echo $method['status'] === 'enabled' ? 'Enabled' : 'Disabled'; ?></label>
                            </div>
                        </div>
                        
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Save Changes</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
