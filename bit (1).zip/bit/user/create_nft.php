<?php
require_once '../config/config.php';
require_once '../includes/auth_check.php';
require_once '../includes/functions.php';
require_once '../includes/functions_nft.php';

// Check if NFT feature is enabled for the user
$user_id = $_SESSION['user_id'];
$user_settings = getUserSettings($user_id);
if (!$user_settings['show_nft']) {
    header('Location: dashboard.php');
    exit;
}

// Get all NFT categories
$categories = getNFTCategories();

// Handle form submission
$errors = [];
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate inputs
    $name = trim($_POST['name'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $price = floatval($_POST['price'] ?? 0);
    $category_id = intval($_POST['category_id'] ?? 0);
    
    // Validate name
    if (empty($name)) {
        $errors[] = "NFT name is required";
    }
    
    // Validate price
    if ($price <= 0) {
        $errors[] = "Price must be greater than 0";
    }
    
    // Validate category
    if ($category_id <= 0) {
        $errors[] = "Please select a valid category";
    }
    
    // Validate image
    if (!isset($_FILES['image']) || $_FILES['image']['error'] !== UPLOAD_ERR_OK) {
        $errors[] = "Please upload an image for your NFT";
    } else {
        $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
        $file_type = $_FILES['image']['type'];
        
        if (!in_array($file_type, $allowed_types)) {
            $errors[] = "Only JPG, PNG, and GIF images are allowed";
        }
        
        $max_size = 5 * 1024 * 1024; // 5MB
        if ($_FILES['image']['size'] > $max_size) {
            $errors[] = "Image size should not exceed 5MB";
        }
    }
    
    // If no errors, process the NFT creation
    if (empty($errors)) {
        // Upload image
        $upload_dir = '../uploads/nfts/';
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0755, true);
        }
        
        $file_extension = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
        $file_name = uniqid('nft_') . '.' . $file_extension;
        $file_path = $upload_dir . $file_name;
        
        if (move_uploaded_file($_FILES['image']['tmp_name'], $file_path)) {
            // Generate a unique token ID
            $token_id = uniqid('token_');
            
            // Create NFT in database
            $nft_id = createNFT($user_id, $name, $description, $price, '/uploads/nfts/' . $file_name, $category_id, $token_id);
            
            if ($nft_id) {
                $success = true;
                // Redirect to the NFT details page
                header("Location: nft_details.php?id=$nft_id&created=1");
                exit;
            } else {
                $errors[] = "Failed to create NFT. Please try again.";
            }
        } else {
            $errors[] = "Failed to upload image. Please try again.";
        }
    }
}

// Page title
$page_title = "Create NFT";
include '../includes/header.php';
?>

<div class="container-fluid">
    <div class="row">
        <!-- Sidebar -->
        <?php include 'includes/sidebar.php'; ?>

        <!-- Main Content -->
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 mt-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Mint NFT</h1>
                <div class="btn-toolbar mb-2 mb-md-0">
                    <div class="btn-group me-2">
                        <a href="nfts.php" class="btn btn-sm btn-outline-secondary">Back to Gallery</a>
                    </div>
                </div>
            </div>

            <!-- Error Messages -->
            <?php if (!empty($errors)): ?>
                <div class="alert alert-danger">
                    <ul class="mb-0">
                        <?php foreach ($errors as $error): ?>
                            <li><?php echo htmlspecialchars($error); ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>

            <!-- NFT Creation Form -->
            <div class="row">
                <div class="col-md-8 mx-auto">
                    <div class="card bg-dark text-white">
                        <div class="card-body">
                            <h3 class="card-title mb-4">Mint NFT</h3>
                            <form action="create_nft.php" method="POST" enctype="multipart/form-data">
                                <div class="mb-3">
                                    <label for="name" class="form-label">NFT Name</label>
                                    <input type="text" class="form-control bg-dark text-white" id="name" name="name" required>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="description" class="form-label">Description</label>
                                    <textarea class="form-control bg-dark text-white" id="description" name="description" rows="4"></textarea>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="price" class="form-label">Price (ETH)</label>
                                    <input type="number" step="0.0001" class="form-control bg-dark text-white" id="price" name="price" required>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="category_id" class="form-label">Category</label>
                                    <select class="form-select bg-dark text-white" id="category_id" name="category_id" required>
                                        <option value="">Select Category</option>
                                        <?php foreach ($categories as $category): ?>
                                            <option value="<?php echo $category['id']; ?>"><?php echo htmlspecialchars($category['name']); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="image" class="form-label">NFT Image</label>
                                    <input type="file" class="form-control bg-dark text-white" id="image" name="image" accept="image/*" required>
                                    <div class="form-text text-muted">Max file size: 5MB. Supported formats: JPG, PNG, GIF</div>
                                </div>
                                
                                <div class="d-grid">
                                    <button type="submit" class="btn btn-primary">Mint NFT</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
