<?php
session_start();
require_once '../config/config.php';
require_once '../includes/auth_check.php';
require_once '../includes/functions.php';
require_once '../includes/copytrade.php';

// Check if user is admin
requireAdmin();
requireOTPVerification();

// Check if trader ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: manage_traders.php");
    exit();
}

$traderId = $_GET['id'];

// Get trader details
$trader = getTraderDetails($traderId);

if (!$trader) {
    header("Location: manage_traders.php");
    exit();
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $firstName = $_POST['first_name'] ?? '';
    $lastName = $_POST['last_name'] ?? '';
    $email = $_POST['email'] ?? '';
    $phone = $_POST['phone'] ?? '';
    $biography = $_POST['biography'] ?? '';
    $tradingStrategy = $_POST['trading_strategy'] ?? '';
    $experience = $_POST['experience'] ?? '';
    $riskLevel = $_POST['risk_level'] ?? '';
    
    // Validate input
    if (empty($firstName) || empty($lastName) || empty($email) || empty($phone)) {
        $error = "All required fields must be filled";
    } else {
        // Check if email already exists (excluding current trader)
        $stmt = $conn->prepare("SELECT * FROM users WHERE email = ? AND id != ?");
        $stmt->bind_param("si", $email, $traderId);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $error = "Email already exists";
        } else {
            // Start transaction
            $conn->begin_transaction();
            
            try {
                // Update user
                $stmt = $conn->prepare("UPDATE users SET first_name = ?, last_name = ?, email = ?, phone = ? WHERE id = ?");
                $stmt->bind_param("ssssi", $firstName, $lastName, $email, $phone, $traderId);
                $stmt->execute();
                
                // Update trader details
                $stmt = $conn->prepare("UPDATE traders SET biography = ?, trading_strategy = ?, experience = ?, risk_level = ? WHERE user_id = ?");
                $stmt->bind_param("ssssi", $biography, $tradingStrategy, $experience, $riskLevel, $traderId);
                $stmt->execute();
                
                // Handle profile picture upload
                if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] === UPLOAD_ERR_OK) {
                    $allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
                    $maxSize = 5 * 1024 * 1024; // 5MB
                    
                    if (!in_array($_FILES['profile_picture']['type'], $allowedTypes)) {
                        throw new Exception("Invalid file type. Only JPG, PNG, and GIF are allowed.");
                    } elseif ($_FILES['profile_picture']['size'] > $maxSize) {
                        throw new Exception("File size exceeds the limit of 5MB.");
                    } else {
                        $fileName = 'trader_' . $traderId . '_' . time() . '.' . pathinfo($_FILES['profile_picture']['name'], PATHINFO_EXTENSION);
                        $uploadPath = '../uploads/profile/' . $fileName;
                        
                        // Create directory if it doesn't exist
                        if (!file_exists('../uploads/profile/')) {
                            mkdir('../uploads/profile/', 0777, true);
                        }
                        
                        if (move_uploaded_file($_FILES['profile_picture']['tmp_name'], $uploadPath)) {
                            // Delete old profile picture if exists
                            if (!empty($trader['profile_picture'])) {
                                $oldPicturePath = '../uploads/profile/' . $trader['profile_picture'];
                                if (file_exists($oldPicturePath)) {
                                    unlink($oldPicturePath);
                                }
                            }
                            
                            $stmt = $conn->prepare("UPDATE users SET profile_picture = ? WHERE id = ?");
                            $stmt->bind_param("si", $fileName, $traderId);
                            $stmt->execute();
                        } else {
                            throw new Exception("Failed to upload profile picture.");
                        }
                    }
                }
                
                // Handle password change
                if (!empty($_POST['password'])) {
                    $hashedPassword = password_hash($_POST['password'], PASSWORD_DEFAULT);
                    $stmt = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
                    $stmt->bind_param("si", $hashedPassword, $traderId);
                    $stmt->execute();
                }
                
                // Commit transaction
                $conn->commit();
                
                $success = "Trader updated successfully";
                
                // Refresh trader details
                $trader = getTraderDetails($traderId);
            } catch (Exception $e) {
                // Rollback transaction on error
                $conn->rollback();
                $error = "Error: " . $e->getMessage();
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Trader - <?php echo APP_NAME; ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <?php include 'includes/sidebar.php'; ?>
            
            <!-- Main Content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Edit Trader</h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <a href="trader_details.php?id=<?php echo $traderId; ?>" class="btn btn-sm btn-outline-secondary">
                            <i class="fas fa-arrow-left"></i> Back
                        </a>
                    </div>
                </div>
                
                <?php if (!empty($error)): ?>
                    <div class="alert alert-danger"><?php echo $error; ?></div>
                <?php endif; ?>
                
                <?php if (!empty($success)): ?>
                    <div class="alert alert-success"><?php echo $success; ?></div>
                <?php endif; ?>
                
                <div class="card">
                    <div class="card-body">
                        <form method="POST" action="" enctype="multipart/form-data">
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <label for="first_name" class="form-label">First Name <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="first_name" name="first_name" value="<?php echo $trader['first_name']; ?>" required>
                                </div>
                                <div class="col-md-6">
                                    <label for="last_name" class="form-label">Last Name <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="last_name" name="last_name" value="<?php echo $trader['last_name']; ?>" required>
                                </div>
                            </div>
                            
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <label for="email" class="form-label">Email <span class="text-danger">*</span></label>
                                    <input type="email" class="form-control" id="email" name="email" value="<?php echo $trader['email']; ?>" required>
                                </div>
                                <div class="col-md-6">
                                    <label for="phone" class="form-label">Phone <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="phone" name="phone" value="<?php echo $trader['phone']; ?>" required>
                                </div>
                            </div>
                            
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <label for="password" class="form-label">Password (Leave blank to keep current)</label>
                                    <input type="password" class="form-control" id="password" name="password">
                                    <div class="form-text">Only fill this if you want to change the password.</div>
                                </div>
                                <div class="col-md-6">
                                    <label for="risk_level" class="form-label">Risk Level</label>
                                    <select class="form-select" id="risk_level" name="risk_level">
                                        <option value="Low" <?php echo ($trader['risk_level'] ?? '') === 'Low' ? 'selected' : ''; ?>>Low</option>
                                        <option value="Medium" <?php echo ($trader['risk_level'] ?? '') === 'Medium' ? 'selected' : ''; ?>>Medium</option>
                                        <option value="High" <?php echo ($trader['risk_level'] ?? '') === 'High' ? 'selected' : ''; ?>>High</option>
                                    </select>
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label for="profile_picture" class="form-label">Profile Picture</label>
                                <?php if (!empty($trader['profile_picture'])): ?>
                                    <div class="mb-2">
                                        <img src="../uploads/profile/<?php echo $trader['profile_picture']; ?>" alt="Current Profile Picture" class="img-thumbnail" style="max-width: 150px;">
                                    </div>
                                <?php endif; ?>
                                <input type="file" class="form-control" id="profile_picture" name="profile_picture">
                                <div class="form-text">Recommended size: 300x300 pixels. Max file size: 5MB. Leave blank to keep current picture.</div>
                            </div>
                            
                            <div class="mb-3">
                                <label for="biography" class="form-label">Biography</label>
                                <textarea class="form-control" id="biography" name="biography" rows="3"><?php echo $trader['biography'] ?? ''; ?></textarea>
                            </div>
                            
                            <div class="mb-3">
                                <label for="trading_strategy" class="form-label">Trading Strategy</label>
                                <textarea class="form-control" id="trading_strategy" name="trading_strategy" rows="3"><?php echo $trader['trading_strategy'] ?? ''; ?></textarea>
                            </div>
                            
                            <div class="mb-3">
                                <label for="experience" class="form-label">Experience</label>
                                <textarea class="form-control" id="experience" name="experience" rows="3"><?php echo $trader['experience'] ?? ''; ?></textarea>
                            </div>
                            
                            <div class="d-grid gap-2">
                                <button type="submit" class="btn btn-primary">Update Trader</button>
                            </div>
                        </form>
                    </div>
                </div>
            </main>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
