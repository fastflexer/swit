<?php
require_once '../config/config.php';
require_once '../includes/auth_check.php';
require_once '../includes/admin_check.php';
require_once '../includes/functions.php';

// Get all NFTs
$stmt = $conn->prepare("SELECT n.*, u.username as creator_username, u2.username as owner_username FROM nfts n JOIN users u ON n.creator_id = u.id JOIN users u2 ON n.owner_id = u2.id ORDER BY n.created_at DESC");
$stmt->execute();
$nfts = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Process NFT deletion
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_nft'])) {
    $nftId = intval($_POST['nft_id']);
    
    // Get NFT details for image deletion
    $stmt = $conn->prepare("SELECT image_url FROM nfts WHERE id = ?");
    $stmt->bind_param("i", $nftId);
    $stmt->execute();
    $nft = $stmt->get_result()->fetch_assoc();
    
    // Delete NFT from database
    $stmt = $conn->prepare("DELETE FROM nfts WHERE id = ?");
    $stmt->bind_param("i", $nftId);
    
    if ($stmt->execute()) {
        // Delete image file if it exists
        if (!empty($nft['image_url'])) {
            $imagePath = '../' . $nft['image_url'];
            if (file_exists($imagePath)) {
                unlink($imagePath);
            }
        }
        
        $message = "NFT deleted successfully.";
        $messageType = "success";
    } else {
        $message = "Error deleting NFT: " . $stmt->error;
        $messageType = "danger";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage NFTs - Admin Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <style>
        .nft-thumbnail {
            width: 60px;
            height: 60px;
            object-fit: cover;
            border-radius: 5px;
        }
        .table-responsive {
            overflow-x: auto;
        }
        @media (max-width: 768px) {
            .action-buttons {
                display: flex;
                flex-direction: column;
                gap: 5px;
            }
            .action-buttons .btn {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <?php include 'includes/sidebar.php'; ?>
            
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Manage NFTs</h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <div class="btn-group me-2">
                            <a href="add_nft.php" class="btn btn-sm btn-outline-secondary">Add NFT</a>
                        </div>
                    </div>
                </div>
                
                <?php if (isset($message)): ?>
                    <div class="alert alert-<?php echo $messageType; ?> alert-dismissible fade show" role="alert">
                        <?php echo $message; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>
                
                <div class="card mb-4">
                    <div class="card-header">
                        <i class="fas fa-table me-1"></i>
                        All NFTs
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-hover" id="nftsTable">
                                <thead>
                                    <tr>
                                        <th>Image</th>
                                        <th>Name</th>
                                        <th>Category</th>
                                        <th>Price (ETH)</th>
                                        <th>Creator</th>
                                        <th>Owner</th>
                                        <th>Created</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($nfts as $nft): ?>
                                        <tr>
                                            <td>
                                                <img src="<?php echo '../' . htmlspecialchars($nft['image_url']); ?>" class="nft-thumbnail" alt="<?php echo htmlspecialchars($nft['name']); ?>">
                                            </td>
                                            <td><?php echo htmlspecialchars($nft['name']); ?></td>
                                            <td><?php echo htmlspecialchars($nft['category']); ?></td>
                                            <td><?php echo $nft['price']; ?></td>
                                            <td><?php echo htmlspecialchars($nft['creator_username']); ?></td>
                                            <td><?php echo htmlspecialchars($nft['owner_username']); ?></td>
                                            <td><?php echo date('M j, Y', strtotime($nft['created_at'])); ?></td>
                                            <td>
                                                <div class="action-buttons">
                                                    <a href="edit_nft.php?id=<?php echo $nft['id']; ?>" class="btn btn-sm btn-primary">Edit</a>
                                                    <a href="nft_details.php?id=<?php echo $nft['id']; ?>" class="btn btn-sm btn-info">View</a>
                                                    <button type="button" class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#deleteModal<?php echo $nft['id']; ?>">Delete</button>
                                                </div>
                                            </td>
                                        </tr>
                                        
                                        <!-- Delete Modal -->
                                        <div class="modal fade" id="deleteModal<?php echo $nft['id']; ?>" tabindex="-1" aria-labelledby="deleteModalLabel<?php echo $nft['id']; ?>" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="deleteModalLabel<?php echo $nft['id']; ?>">Confirm Deletion</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        Are you sure you want to delete the NFT "<?php echo htmlspecialchars($nft['name']); ?>"? This action cannot be undone.
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                                        <form method="POST">
                                                            <input type="hidden" name="nft_id" value="<?php echo $nft['id']; ?>">
                                                            <input type="hidden" name="delete_nft" value="1">
                                                            <button type="submit" class="btn btn-danger">Delete</button>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const datatablesSimple = document.getElementById('nftsTable');
            if (datatablesSimple) {
                new simpleDatatables.DataTable(datatablesSimple);
            }
        });
    </script>
</body>
</html>
