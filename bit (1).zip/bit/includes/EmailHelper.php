<?php
require_once __DIR__ . '/../vendor/autoload.php';

class EmailHelper {
    private $mailer;
    private $config;
    private $transport;

    public function __construct() {
        $configFile = __DIR__ . '/../config/email_config.php';
        if (!file_exists($configFile)) {
            throw new Exception('Email config file not found: ' . $configFile);
        }
        $this->config = require $configFile;
        if (!is_array($this->config)) {
            throw new Exception('Email config file must return an array.');
        }

        // Create the Transport
        $this->transport = (new Swift_SmtpTransport(
            $this->config['smtp_host'],
            $this->config['smtp_port'],
            $this->config['smtp_encryption']
        ))
            ->setUsername($this->config['smtp_username'])
            ->setPassword($this->config['smtp_password']);

        // Create the Mailer using your created Transport
        $this->mailer = new Swift_Mailer($this->transport);
    }

    public function sendEmail($to, $subject, $body) {
        try {
            // Create a message
            $message = (new Swift_Message($subject))
                ->setFrom([$this->config['from_email'] => $this->config['from_name']])
                ->setTo($to)
                ->setBody($body, 'text/html');

            // Send the message
            $result = $this->mailer->send($message);
            return $result > 0;
        } catch (Exception $e) {
            error_log("Email sending failed: " . $e->getMessage());
            return false;
        }
    }

    public function sendWelcomeEmail($user) {
        $subject = "Welcome to Online Broker";
        $body = $this->getEmailTemplate('welcome', [
            'username' => $user['username']
        ]);
        return $this->sendEmail($user['email'], $subject, $body);
    }

    public function sendInvestmentConfirmation($data) {
        $subject = "Investment Confirmation";
        $body = $this->getEmailTemplate('investment_confirmation', $data);
        return $this->sendEmail($data['email'], $subject, $body);
    }

    public function sendWithdrawalStatus($data) {
        $subject = "Withdrawal Status Update";
        $body = $this->getEmailTemplate('withdrawal_status', $data);
        return $this->sendEmail($data['email'], $subject, $body);
    }

    private function getEmailTemplate($template, $data) {
        ob_start();
        include __DIR__ . "/email_templates/{$template}.php";
        return ob_get_clean();
    }
}