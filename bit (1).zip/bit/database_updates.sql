-- Update withdrawals table to add new fields for enhanced withdrawal system
ALTER TABLE withdrawals ADD COLUMN IF NOT EXISTS processed_by INT DEFAULT NULL;
ALTER TABLE withdrawals ADD COLUMN IF NOT EXISTS processed_at DATETIME DEFAULT NULL;
ALTER TABLE withdrawals ADD COLUMN IF NOT EXISTS admin_note TEXT DEFAULT NULL;
ALTER TABLE withdrawals ADD COLUMN IF NOT EXISTS wallet_address TEXT DEFAULT NULL;

-- Update status field to include 'blocked' status
ALTER TABLE withdrawals MODIFY COLUMN status ENUM('pending', 'processed', 'rejected', 'blocked') DEFAULT 'pending';

-- Create transactions table to track all financial transactions
CREATE TABLE IF NOT EXISTS transactions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    type ENUM('deposit', 'withdrawal', 'trade_profit', 'trade_loss', 'copy_trade_profit', 'copy_trade_loss', 'referral_bonus', 'bonus', 'refund') NOT NULL,
    amount DECIMAL(15, 2) NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Create email_logs table to track all sent emails
CREATE TABLE IF NOT EXISTS email_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    email_type VARCHAR(50) NOT NULL,
    subject VARCHAR(255) NOT NULL,
    sent_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status ENUM('sent', 'failed') DEFAULT 'sent',
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Add withdrawal_limit field to users table
ALTER TABLE users ADD COLUMN IF NOT EXISTS withdrawal_limit DECIMAL(15, 2) DEFAULT NULL;
ALTER TABLE users ADD COLUMN IF NOT EXISTS daily_withdrawal_count INT DEFAULT 0;
ALTER TABLE users ADD COLUMN IF NOT EXISTS last_withdrawal_date DATE DEFAULT NULL;

-- Add withdrawal_blocked field to users table
ALTER TABLE users ADD COLUMN IF NOT EXISTS withdrawal_blocked TINYINT(1) DEFAULT 0;
ALTER TABLE users ADD COLUMN IF NOT EXISTS withdrawal_blocked_reason TEXT DEFAULT NULL;
