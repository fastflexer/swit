<?php
require_once 'config/config.php';
require_once 'includes/functions.php';

/**
 * Get all subscription plans
 * 
 * @return array Array of subscription plans
 */
function getAllSubscriptionPlans() {
    global $conn;
    
    $stmt = $conn->prepare("SELECT * FROM subscription_plans WHERE status = 'active' ORDER BY min_amount ASC");
    $stmt->execute();
    $result = $stmt->get_result();
    
    $plans = [];
    while ($row = $result->fetch_assoc()) {
        $plans[] = $row;
    }
    
    return $plans;
}

/**
 * Get subscription plan by ID
 * 
 * @param int $id Plan ID
 * @return array|null Plan data or null if not found
 */
function getSubscriptionPlanById($id) {
    global $conn;
    
    $stmt = $conn->prepare("SELECT * FROM subscription_plans WHERE id = ?");
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        return $result->fetch_assoc();
    }
    
    return null;
}

/**
 * Create a new subscription plan
 * 
 * @param array $data Plan data
 * @return int|bool New plan ID or false on failure
 */
function createSubscriptionPlan($data) {
    global $conn;
    
    $stmt = $conn->prepare("INSERT INTO subscription_plans (name, description, roi_percentage, min_amount, max_amount, duration_days, is_popular, is_vip, status, created_at) 
                           VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'active', NOW())");
    $stmt->bind_param('ssdddiis', $data['name'], $data['description'], $data['roi_percentage'], $data['min_amount'], $data['max_amount'], $data['duration_days'], $data['is_popular'], $data['is_vip']);
    
    if ($stmt->execute()) {
        return $conn->insert_id;
    }
    
    return false;
}

/**
 * Update a subscription plan
 * 
 * @param int $id Plan ID
 * @param array $data Updated plan data
 * @return bool Success or failure
 */
function updateSubscriptionPlan($id, $data) {
    global $conn;
    
    $stmt = $conn->prepare("UPDATE subscription_plans SET name = ?, description = ?, roi_percentage = ?, min_amount = ?, max_amount = ?, duration_days = ?, is_popular = ?, is_vip = ?, status = ? WHERE id = ?");
    $stmt->bind_param('ssddddiisi', $data['name'], $data['description'], $data['roi_percentage'], $data['min_amount'], $data['max_amount'], $data['duration_days'], $data['is_popular'], $data['is_vip'], $data['status'], $id);
    
    return $stmt->execute();
}

/**
 * Delete a subscription plan
 * 
 * @param int $id Plan ID
 * @return bool Success or failure
 */
function deleteSubscriptionPlan($id) {
    global $conn;
    
    $stmt = $conn->prepare("DELETE FROM subscription_plans WHERE id = ?");
    $stmt->bind_param('i', $id);
    
    return $stmt->execute();
}

/**
 * Subscribe user to a plan
 * 
 * @param int $userId User ID
 * @param int $planId Plan ID
 * @param float $amount Investment amount
 * @return int|bool New subscription ID or false on failure
 */
function subscribeToInvestmentPlan($userId, $planId, $amount) {
    global $conn;
    
    // Get plan details
    $plan = getSubscriptionPlanById($planId);
    if (!$plan) {
        return false;
    }
    
    // Validate amount
    if ($amount < $plan['min_amount'] || $amount > $plan['max_amount']) {
        return false;
    }
    
    // Calculate end date and expected return
    $endDate = date('Y-m-d H:i:s', strtotime("+{$plan['duration_days']} days"));
    $expectedReturn = $amount * (1 + ($plan['roi_percentage'] / 100));
    
    // Start transaction
    $conn->begin_transaction();
    
    try {
        // Create subscription
        $stmt = $conn->prepare("INSERT INTO subscriptions (user_id, plan_id, amount, expected_return, start_date, end_date, status, created_at) 
                               VALUES (?, ?, ?, ?, NOW(), ?, 'active', NOW())");
        $stmt->bind_param('iidds', $userId, $planId, $amount, $expectedReturn, $endDate);
        $stmt->execute();
        
        $subscriptionId = $conn->insert_id;
        
        // Record payment
        $stmt = $conn->prepare("INSERT INTO payments (user_id, amount, payment_type, status, reference_id, reference_type, created_at) 
                               VALUES (?, ?, 'investment_subscription', 'completed', ?, 'subscription', NOW())");
        $stmt->bind_param('idi', $userId, $amount, $subscriptionId);
        $stmt->execute();
        
        // Update user balance
        $stmt = $conn->prepare("UPDATE users SET balance = balance - ? WHERE id = ?");
        $stmt->bind_param('di', $amount, $userId);
        $stmt->execute();
