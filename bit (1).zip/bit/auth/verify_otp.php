<?php
session_start();
require_once '../config/config.php';
require_once '../includes/functions.php';

// Check if user has initiated login
if (!isset($_SESSION['temp_user_id'])) {
    header("Location: login.php");
    exit();
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $otp = $_POST['otp'] ?? '';
    
    if (empty($otp)) {
        $error = "Please enter the OTP";
    } else {
        // Verify OTP
        if (verifyOTP($_SESSION['temp_user_id'], $otp)) {
            // OTP verified, complete login
            $_SESSION['user_id'] = $_SESSION['temp_user_id'];
            $_SESSION['user_email'] = $_SESSION['temp_user_email'];
            $_SESSION['user_role'] = $_SESSION['temp_user_role'];
            $_SESSION['otp_verified'] = true;
            
            // Clear temporary session variables
            unset($_SESSION['temp_user_id']);
            unset($_SESSION['temp_user_email']);
            unset($_SESSION['temp_user_role']);
            
            // Log user activity
            logUserActivity($_SESSION['user_id'], 'Login successful');
            
            // Redirect based on role
            if ($_SESSION['user_role'] === 'admin' || $_SESSION['user_role'] === 'super_admin') {
                header("Location: ../admin/dashboard.php");
            } else {
                header("Location: ../user/dashboard.php");
            }
            exit();
        } else {
            $error = "Invalid or expired OTP. Please try again.";
        }
    }
}

// Resend OTP
if (isset($_GET['resend']) && $_GET['resend'] === '1') {
    $otp = generateOTP();
    if (storeOTP($_SESSION['temp_user_id'], $otp)) {
        if (sendOTP($_SESSION['temp_user_email'], $otp)) {
            $success = "A new OTP has been sent to your email.";
        } else {
            $error = "Failed to send OTP. Please try again.";
        }
    } else {
        $error = "Failed to generate OTP. Please try again.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verify OTP - <?php echo APP_NAME; ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/auth.css">
</head>
<body>
    <div class="container">
        <div class="row justify-content-center align-items-center min-vh-100">
            <div class="col-md-5">
                <div class="auth-card">
                    <div class="text-center mb-4">
                        <h2 class="auth-title">Verify OTP</h2>
                    </div>
                    
                    <?php if (!empty($error)): ?>
                        <div class="alert alert-danger"><?php echo $error; ?></div>
                    <?php endif; ?>
                    
                    <?php if (!empty($success)): ?>
                        <div class="alert alert-success"><?php echo $success; ?></div>
                    <?php endif; ?>
                    
                    <p class="text-center mb-4">A One-Time Password (OTP) has been sent to your email address: <strong><?php echo $_SESSION['temp_user_email']; ?></strong></p>
                    
                    <form method="POST" action="">
                        <div class="mb-4">
                            <label for="otp" class="form-label">Enter OTP Code</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="fas fa-key"></i></span>
                                <input type="text" class="form-control" id="otp" name="otp" placeholder="Enter 6-digit OTP" required>
                            </div>
                        </div>
                        
                        <div class="d-grid mb-4">
                            <button type="submit" class="btn btn-primary btn-lg">Verify OTP</button>
                        </div>
                    </form>
                    
                    <div class="text-center">
                        <p>Didn't receive the OTP? <a href="?resend=1" class="text-decoration-none">Resend OTP</a></p>
                        <p><a href="login.php" class="text-decoration-none">Back to Login</a></p>
                    </div>
                    
                    <div class="text-center mt-4">
                        <p class="small text-muted">© Copyright 2025 JetFx Growth All Rights Reserved.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
