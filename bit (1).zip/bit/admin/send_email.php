<?php
session_start();
require_once '../config/config.php';
require_once '../includes/auth_check.php';
require_once '../includes/functions.php';
require_once '../includes/mail_helper.php';

// Check if user is admin
requireAdmin();
requireOTPVerification();

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['user_id']) || !isset($_POST['email_subject']) || !isset($_POST['email_message'])) {
    header("Location: manage_users.php");
    exit();
}

$userId = $_POST['user_id'];
$subject = $_POST['email_subject'];
$message = $_POST['email_message'];

// Get user data
$user = getUserById($userId);

if (!$user) {
    $_SESSION['error'] = "User not found";
    header("Location: manage_users.php");
    exit();
}

// Send email
if (sendEmail($user['email'], $subject, $message)) {
    $_SESSION['success'] = "Email sent successfully to " . $user['email'];
} else {
    $_SESSION['error'] = "Failed to send email";
}

// Redirect back to user details
header("Location: user_details.php?id=" . $userId);
exit();
?>
