<?php
session_start();
require_once '../config/config.php';
require_once '../includes/auth_check.php';
require_once '../includes/functions.php';
require_once '../includes/copytrade.php';

// Check if user is admin
requireAdmin();
requireOTPVerification();

// Check if trader ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: manage_traders.php");
    exit();
}

$traderId = $_GET['id'];

// Get trader details
$trader = getTraderDetails($traderId);

if (!$trader) {
    header("Location: manage_traders.php");
    exit();
}

// Get trader's trades
$trades = getTraderTrades($traderId);

// Get trader's followers (users who are copy trading this trader)
$stmt = $conn->prepare("SELECT c.*, u.first_name, u.last_name, u.email FROM copy_trades c JOIN users u ON c.user_id = u.id WHERE c.trader_id = ? AND c.status = 'active'");
$stmt->bind_param("i", $traderId);
$stmt->execute();
$followers = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Handle trade actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action']) && isset($_POST['trade_id'])) {
        $action = $_POST['action'];
        $tradeId = $_POST['trade_id'];
        
        switch ($action) {
            case 'pause':
                $stmt = $conn->prepare("UPDATE trades SET status = 'paused' WHERE id = ?");
                $stmt->bind_param("i", $tradeId);
                $stmt->execute();
                $_SESSION['success'] = "Trade has been paused successfully";
                break;
                
            case 'resume':
                $stmt = $conn->prepare("UPDATE trades SET status = 'active' WHERE id = ?");
                $stmt->bind_param("i", $tradeId);
                $stmt->execute();
                $_SESSION['success'] = "Trade has been resumed successfully";
                break;
                
            case 'stop':
                $stmt = $conn->prepare("UPDATE trades SET status = 'stopped', closed_at = NOW() WHERE id = ?");
                $stmt->bind_param("i", $tradeId);
                $stmt->execute();
                $_SESSION['success'] = "Trade has been stopped successfully";
                break;
                
            case 'delete':
                $stmt = $conn->prepare("DELETE FROM trades WHERE id = ?");
                $stmt->bind_param("i", $tradeId);
                $stmt->execute();
                $_SESSION['success'] = "Trade has been deleted successfully";
                break;
        }
        
        // Refresh trades
        $trades = getTraderTrades($traderId);
    }
    
    // Handle trader status change
    if (isset($_POST['trader_action'])) {
        $traderAction = $_POST['trader_action'];
        
        switch ($traderAction) {
            case 'activate':
                $stmt = $conn->prepare("UPDATE users SET status = 'active' WHERE id = ? AND role = 'trader'");
                $stmt->bind_param("i", $traderId);
                $stmt->execute();
                $_SESSION['success'] = "Trader has been activated successfully";
                break;
                
            case 'deactivate':
                $stmt = $conn->prepare("UPDATE users SET status = 'inactive' WHERE id = ? AND role = 'trader'");
                $stmt->bind_param("i", $traderId);
                $stmt->execute();
                $_SESSION['success'] = "Trader has been deactivated successfully";
                break;
        }
        
        // Refresh trader details
        $trader = getTraderDetails($traderId);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trader Details - <?php echo APP_NAME; ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <style>
        .trader-profile {
            text-align: center;
            padding: 20px;
        }
        .trader-profile img {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            object-fit: cover;
            margin-bottom: 15px;
            border: 5px solid #f8f9fa;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        .trader-stats {
            background-color: #f8f9fa;
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 20px;
        }
        .stat-item {
            text-align: center;
            padding: 10px;
        }
        .stat-value {
            font-size: 24px;
            font-weight: bold;
            color: #2470dc;
        }
        .stat-label {
            font-size: 14px;
            color: #6c757d;
        }
        .trade-card {
            margin-bottom: 15px;
            border-radius: 10px;
            overflow: hidden;
        }
        .trade-card.profit {
            border-left: 5px solid #28a745;
        }
        .trade-card.loss {
            border-left: 5px solid #dc3545;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <?php include 'includes/sidebar.php'; ?>
            
            <!-- Main Content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Trader Details</h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <a href="manage_traders.php" class="btn btn-sm btn-outline-secondary me-2">
                            <i class="fas fa-arrow-left"></i> Back
                        </a>
                        <a href="edit_trader.php?id=<?php echo $traderId; ?>" class="btn btn-sm btn-warning me-2">
                            <i class="fas fa-edit"></i> Edit Trader
                        </a>
                        <a href="add_trade.php?trader_id=<?php echo $traderId; ?>" class="btn btn-sm btn-primary">
                            <i class="fas fa-plus"></i> Add Trade
                        </a>
                    </div>
                </div>
                
                <?php if (isset($_SESSION['error'])): ?>
                    <div class="alert alert-danger"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
                <?php endif; ?>
                
                <?php if (isset($_SESSION['success'])): ?>
                    <div class="alert alert-success"><?php echo $_SESSION['success']; unset($_SESSION['success']); ?></div>
                <?php endif; ?>
                
                <div class="row mb-4">
                    <div class="col-md-4">
                        <div class="card">
                            <div class="card-body">
                                <div class="trader-profile">
                                    <img src="<?php echo !empty($trader['profile_picture']) ? '../uploads/profile/' . $trader['profile_picture'] : '../assets/img/default-avatar.png'; ?>" 
                                         alt="Profile" class="img-fluid">
                                    <h4><?php echo $trader['first_name'] . ' ' . $trader['last_name']; ?></h4>
                                    <p class="text-muted"><?php echo $trader['email']; ?></p>
                                    <p>
                                        <span class="badge bg-<?php echo $trader['status'] === 'active' ? 'success' : 'danger'; ?>">
                                            <?php echo ucfirst($trader['status']); ?>
                                        </span>
                                    </p>
                                    
                                    <?php if ($trader['status'] === 'active'): ?>
                                        <form method="POST" action="" class="d-inline">
                                            <input type="hidden" name="trader_action" value="deactivate">
                                            <button type="submit" class="btn btn-danger btn-sm">Deactivate Trader</button>
                                        </form>
                                    <?php else: ?>
                                        <form method="POST" action="" class="d-inline">
                                            <input type="hidden" name="trader_action" value="activate">
                                            <button type="submit" class="btn btn-success btn-sm">Activate Trader</button>
                                        </form>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-8">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="mb-0">Trader Statistics</h5>
                            </div>
                            <div class="card-body">
                                <div class="row trader-stats">
                                    <div class="col-md-3 stat-item">
                                        <div class="stat-value"><?php echo number_format($trader['success_rate'], 2); ?>%</div>
                                        <div class="stat-label">Success Rate</div>
                                    </div>
                                    <div class="col-md-3 stat-item">
                                        <div class="stat-value"><?php echo $trader['total_trades']; ?></div>
                                        <div class="stat-label">Total Trades</div>
                                    </div>
                                    <div class="col-md-3 stat-item">
                                        <div class="stat-value"><?php echo $trader['profitable_trades']; ?></div>
                                        <div class="stat-label">Profitable Trades</div>
                                    </div>
                                    <div class="col-md-3 stat-item">
                                        <div class="stat-value"><?php echo count($followers); ?></div>
                                        <div class="stat-label">Followers</div>
                                    </div>
                                </div>
                                
                                <div class="row">
                                    <div class="col-md-6">
                                        <h6>Biography</h6>
                                        <p><?php echo $trader['biography'] ?? 'No biography available.'; ?></p>
                                    </div>
                                    <div class="col-md-6">
                                        <h6>Trading Strategy</h6>
                                        <p><?php echo $trader['trading_strategy'] ?? 'No trading strategy available.'; ?></p>
                                    </div>
                                </div>
                                
                                <div class="row mt-3">
                                    <div class="col-md-6">
                                        <h6>Experience</h6>
                                        <p><?php echo $trader['experience'] ?? 'No experience information available.'; ?></p>
                                    </div>
                                    <div class="col-md-6">
                                        <h6>Risk Level</h6>
                                        <p><?php echo $trader['risk_level'] ?? 'Not specified'; ?></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-12">
                        <ul class="nav nav-tabs" id="traderTabs" role="tablist">
                            <li class="nav-item" role="presentation">
                                <button class="nav-link active" id="trades-tab" data-bs-toggle="tab" data-bs-target="#trades" type="button" role="tab" aria-controls="trades" aria-selected="true">Trades</button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="followers-tab" data-bs-toggle="tab" data-bs-target="#followers" type="button" role="tab" aria-controls="followers" aria-selected="false">Followers</button>
                            </li>
                        </ul>
                        
                        <div class="tab-content" id="traderTabsContent">
                            <!-- Trades Tab -->
                            <div class="tab-pane fade show active" id="trades" role="tabpanel" aria-labelledby="trades-tab">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="table-responsive">
                                            <table class="table table-striped table-hover">
                                                <thead>
                                                    <tr>
                                                        <th>Symbol</th>
                                                        <th>Type</th>
                                                        <th>Entry Price</th>
                                                        <th>Exit Price</th>
                                                        <th>Volume</th>
                                                        <th>Profit/Loss</th>
                                                        <th>Status</th>
                                                        <th>Date</th>
                                                        <th>Actions</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php if (empty($trades)): ?>
                                                        <tr>
                                                            <td colspan="9" class="text-center">No trades found</td>
                                                        </tr>
                                                    <?php else: ?>
                                                        <?php foreach ($trades as $trade): ?>
                                                            <tr>
                                                                <td><?php echo $trade['symbol']; ?></td>
                                                                <td><?php echo ucfirst($trade['type']); ?></td>
                                                                <td><?php echo $trade['entry_price']; ?></td>
                                                                <td><?php echo $trade['exit_price']; ?></td>
                                                                <td><?php echo $trade['volume']; ?></td>
                                                                <td class="<?php echo $trade['profit'] >= 0 ? 'text-success' : 'text-danger'; ?>">
                                                                    <?php echo $trade['profit'] >= 0 ? '+' : ''; ?><?php echo number_format($trade['profit'], 2); ?>
                                                                </td>
                                                                <td>
                                                                    <span class="badge bg-<?php 
                                                                        echo $trade['status'] === 'active' ? 'success' : 
                                                                            ($trade['status'] === 'paused' ? 'warning' : 'danger'); 
                                                                    ?>">
                                                                        <?php echo ucfirst($trade['status']); ?>
                                                                    </span>
                                                                </td>
                                                                <td><?php echo date('M j, Y', strtotime($trade['created_at'])); ?></td>
                                                                <td>
                                                                    <div class="dropdown">
                                                                        <button class="btn btn-sm btn-secondary dropdown-toggle" type="button" id="tradeActions<?php echo $trade['id']; ?>" data-bs-toggle="dropdown" aria-expanded="false">
                                                                            Actions
                                                                        </button>
                                                                        <ul class="dropdown-menu" aria-labelledby="tradeActions<?php echo $trade['id']; ?>">
                                                                            <li>
                                                                                <a class="dropdown-item" href="edit_trade.php?id=<?php echo $trade['id']; ?>">
                                                                                    <i class="fas fa-edit"></i> Edit
                                                                                </a>
                                                                            </li>
                                                                            <?php if ($trade['status'] === 'active'): ?>
                                                                                <li>
                                                                                    <form method="POST" action="">
                                                                                        <input type="hidden" name="trade_id" value="<?php echo $trade['id']; ?>">
                                                                                        <input type="hidden" name="action" value="pause">
                                                                                        <button type="submit" class="dropdown-item">
                                                                                            <i class="fas fa-pause"></i> Pause
                                                                                        </button>
                                                                                    </form>
                                                                                </li>
                                                                                <li>
                                                                                    <form method="POST" action="">
                                                                                        <input type="hidden" name="trade_id" value="<?php echo $trade['id']; ?>">
                                                                                        <input type="hidden" name="action" value="stop">
                                                                                        <button type="submit" class="dropdown-item">
                                                                                            <i class="fas fa-stop"></i> Stop
                                                                                        </button>
                                                                                    </form>
                                                                                </li>
                                                                            <?php elseif ($trade['status'] === 'paused'): ?>
                                                                                <li>
                                                                                    <form method="POST" action="">
                                                                                        <input type="hidden" name="trade_id" value="<?php echo $trade['id']; ?>">
                                                                                        <input type="hidden" name="action" value="resume">
                                                                                        <button type="submit" class="dropdown-item">
                                                                                            <i class="fas fa-play"></i> Resume
                                                                                        </button>
                                                                                    </form>
                                                                                </li>
                                                                            <?php endif; ?>
                                                                            <li><hr class="dropdown-divider"></li>
                                                                            <li>
                                                                                <form method="POST" action="" onsubmit="return confirm('Are you sure you want to delete this trade?');">
                                                                                    <input type="hidden" name="trade_id" value="<?php echo $trade['id']; ?>">
                                                                                    <input type="hidden" name="action" value="delete">
                                                                                    <button type="submit" class="dropdown-item text-danger">
                                                                                        <i class="fas fa-trash"></i> Delete
                                                                                    </button>
                                                                                </form>
                                                                            </li>
                                                                        </ul>
                                                                    </div>
