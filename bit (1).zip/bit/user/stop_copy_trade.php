<?php
session_start();
require_once '../config/config.php';
require_once '../includes/auth_check.php';
require_once '../includes/functions.php';
require_once '../includes/copytrade.php';

// Check if user is logged in
requireLogin();
requireOTPVerification();

// Check if copy trade ID is provided
if (!isset($_POST['copy_trade_id']) || empty($_POST['copy_trade_id'])) {
    $_SESSION['error'] = "Invalid request";
    header("Location: my_trades.php");
    exit();
}

$copyTradeId = $_POST['copy_trade_id'];

// Stop copy trade
$result = stopCopyTrading($copyTradeId, $_SESSION['user_id']);

if ($result['success']) {
    $_SESSION['success'] = $result['message'];
} else {
    $_SESSION['error'] = $result['message'];
}

// Redirect back to my trades page
header("Location: my_trades.php");
exit();
?>
