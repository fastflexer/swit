<?php
session_start();
require_once '../config/config.php';
require_once '../includes/auth_check.php';
require_once '../includes/functions.php';
require_once '../includes/copytrade.php';

// Check if user is logged in
requireLogin();
requireOTPVerification();

// Get user data
$user = getUserById($_SESSION['user_id']);

// Get master traders
$traders = getMasterTraders();

// Get user's copy trades
$copyTrades = getUserCopyTrades($_SESSION['user_id']);

// Get user's trading accounts
$stmt = $conn->prepare("SELECT * FROM trading_accounts WHERE user_id = ? AND status = 'active'");
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$tradingAccounts = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

$error = '';
$success = '';

// Handle copy trade actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        $action = $_POST['action'];
        
        if ($action === 'start') {
            $traderId = $_POST['trader_id'] ?? 0;
            $amount = $_POST['amount'] ?? 0;
            $accountId = $_POST['account_id'] ?? '';
            
            if (empty($traderId) || empty($amount) || empty($accountId)) {
                $error = "All fields are required";
            } else {
                $result = startCopyTrading($_SESSION['user_id'], $traderId, $amount, $accountId);
                
                if ($result['success']) {
                    $success = $result['message'];
                    
                    // Refresh copy trades
                    $copyTrades = getUserCopyTrades($_SESSION['user_id']);
                } else {
                    $error = $result['message'];
                }
            }
        } elseif ($action === 'stop') {
            $copyTradeId = $_POST['copy_trade_id'] ?? 0;
            
            if (empty($copyTradeId)) {
                $error = "Invalid copy trade ID";
            } else {
                $result = stopCopyTrading($copyTradeId, $_SESSION['user_id']);
                
                if ($result['success']) {
                    $success = $result['message'] . " Profit: " . formatCurrency($result['profit']);
                    
                    // Refresh copy trades
                    $copyTrades = getUserCopyTrades($_SESSION['user_id']);
                } else {
                    $error = $result['message'];
                }
            }
        } elseif ($action === 'register_trader') {
            $result = registerAsTrader($_SESSION['user_id']);
            
            if ($result['success']) {
                $success = $result['message'];
            } else {
                $error = $result['message'];
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Copy Trade - <?php echo APP_NAME; ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <?php include 'includes/sidebar.php'; ?>
            
            <!-- Main Content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-
