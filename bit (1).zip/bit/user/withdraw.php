<?php
session_start();
require_once '../config/config.php';
require_once '../includes/auth_check.php';
require_once '../includes/functions.php';

// Check if user is logged in
requireLogin();
requireOTPVerification();

// Get user data
$user = getUserById($_SESSION['user_id']);

$error = '';
$success = '';

// Process withdrawal form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['request_withdrawal'])) {
        $amount = $_POST['amount'] ?? 0;
        $paymentMethod = $_POST['payment_method'] ?? '';
        $walletAddress = $_POST['wallet_address'] ?? '';
        
        // Validate input
        if (empty($amount) || !is_numeric($amount) || $amount <= 0) {
            $error = "Please enter a valid amount";
        } elseif (empty($paymentMethod)) {
            $error = "Please select a payment method";
        } elseif (empty($walletAddress)) {
            $error = "Please enter your wallet address or account details";
        } elseif ($amount > $user['balance']) {
            $error = "Insufficient balance. Your current balance is $" . number_format($user['balance'], 2);
        } else {
            // Generate OTP for withdrawal verification
            $withdrawalOTP = generateOTP();
            
            // Store withdrawal request in session for verification
            $_SESSION['withdrawal_request'] = [
                'amount' => $amount,
                'payment_method' => $paymentMethod,
                'wallet_address' => $walletAddress,
                'otp' => $withdrawalOTP,
                'otp_expiry' => time() + (OTP_EXPIRY_MINUTES * 60)
            ];
            
            // Send OTP to user's email
            $subject = APP_NAME . " - Withdrawal Verification OTP";
            $message = "
                <html>
                <head>
                    <title>Withdrawal Verification</title>
                </head>
                <body>
                    <h2>Withdrawal Verification</h2>
                    <p>You have requested to withdraw $" . number_format($amount, 2) . " from your account.</p>
                    <p>Your OTP code for withdrawal verification is: <strong>" . $withdrawalOTP . "</strong></p>
                    <p>This code will expire in " . OTP_EXPIRY_MINUTES . " minutes.</p>
                    <p>If you did not request this withdrawal, please contact support immediately.</p>
                    <p>Regards,<br>" . APP_NAME . " Team</p>
                </body>
                </html>
            ";
            
            if (sendEmail($user['email'], $subject, $message)) {
                // Redirect to OTP verification page
                header("Location: verify_withdrawal_otp.php");
                exit();
            } else {
                $error = "Failed to send OTP. Please try again.";
            }
        }
    }
}

// Get withdrawal history
$stmt = $conn->prepare("SELECT * FROM withdrawals WHERE user_id = ? ORDER BY created_at DESC");
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$result = $stmt->get_result();

$withdrawals = [];
while ($row = $result->fetch_assoc()) {
    $withdrawals[] = $row;
}

// Get payment methods
$stmt = $conn->prepare("SELECT * FROM payment_methods WHERE status = 'enabled' AND (used_for = 'withdrawal' OR used_for = 'both')");
$stmt->execute();
$result = $stmt->get_result();

$paymentMethods = [];
while ($row = $result->fetch_assoc()) {
    $paymentMethods[] = $row;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Withdraw - <?php echo APP_NAME; ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <?php include 'includes/sidebar.php'; ?>
            
            <!-- Main Content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Withdraw Funds</h1>
                </div>
                
                <?php if (!empty($error)): ?>
                    <div class="alert alert-danger"><?php echo $error; ?></div>
                <?php endif; ?>
                
                <?php if (!empty($success)): ?>
                    <div class="alert alert-success"><?php echo $success; ?></div>
                <?php endif; ?>
                
                <div class="row">
                    <div class="col-md-8 mb-4">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="mb-0">Request Withdrawal</h5>
                            </div>
                            <div class="card-body">
                                <div class="alert alert-info">
                                    <p class="mb-0"><i class="fas fa-info-circle me-2"></i> Withdrawals require OTP verification sent to your email.</p>
                                    <p class="mb-0"><i class="fas fa-info-circle me-2"></i> Minimum withdrawal amount: $10.00</p>
                                    <p class="mb-0"><i class="fas fa-info-circle me-2"></i> Withdrawal fee: 2%</p>
                                </div>
                                
                                <form method="POST" action="">
                                    <div class="mb-3">
                                        <label for="amount" class="form-label">Amount</label>
                                        <div class="input-group">
                                            <span class="input-group-text">$</span>
                                            <input type="number" class="form-control" id="amount" name="amount" min="10" step="0.01" max="<?php echo $user['balance']; ?>" required>
                                        </div>
                                        <div class="form-text">Available balance: $<?php echo number_format($user['balance'], 2); ?></div>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="payment_method" class="form-label">Payment Method</label>
                                        <select class="form-select" id="payment_method" name="payment_method" required>
                                            <option value="">Select Payment Method</option>
                                            <?php foreach ($paymentMethods as $method): ?>
                                                <option value="<?php echo $method['name']; ?>"><?php echo $method['name']; ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="wallet_address" class="form-label">Wallet Address / Account Details</label>
                                        <textarea class="form-control" id="wallet_address" name="wallet_address" rows="3" required></textarea>
                                        <div class="form-text">Enter your wallet address or account details where you want to receive the funds.</div>
                                    </div>
                                    
                                    <div class="d-grid">
                                        <button type="submit" name="request_withdrawal" class="btn btn-primary">Request Withdrawal</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-4 mb-4">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="mb-0">Withdrawal Information</h5>
                            </div>
                            <div class="card-body">
                                <ul class="list-group">
                                    <li class="list-group-item d-flex justify-content-between align-items-center">
                                        Available Balance
                                        <span class="badge bg-primary rounded-pill">$<?php echo number_format($user['balance'], 2); ?></span>
                                    </li>
                                    <li class="list-group-item d-flex justify-content-between align-items-center">
                                        Withdrawal Fee
                                        <span class="badge bg-secondary rounded-pill">2%</span>
                                    </li>
                                    <li class="list-group-item d-flex justify-content-between align-items-center">
                                        Processing Time
                                        <span class="badge bg-info rounded-pill">24-48 hours</span>
                                    </li>
                                </ul>
                                
                                <div class="mt-3">
                                    <h6>Withdrawal Process:</h6>
                                    <ol class="small">
                                        <li>Submit withdrawal request</li>
                                        <li>Verify with OTP sent to your email</li>
                                        <li>Admin reviews your request</li>
                                        <li>Funds are sent to your provided address</li>
                                    </ol>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">Withdrawal History</h5>
                    </div>
                    <div class="card-body">
                        <?php if (empty($withdrawals)): ?>
                            <p class="text-center">No withdrawal history found.</p>
                        <?php else: ?>
                            <div class="table-responsive">
                                <table class="table table-striped table-hover">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Amount</th>
                                            <th>Fee</th>
                                            <th>Net Amount</th>
                                            <th>Payment Method</th>
                                            <th>Status</th>
                                            <th>Date</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($withdrawals as $withdrawal): ?>
                                            <tr>
                                                <td><?php echo $withdrawal['id']; ?></td>
                                                <td>$<?php echo number_format($withdrawal['amount'], 2); ?></td>
                                                <td>$<?php echo number_format($withdrawal['fee'], 2); ?></td>
                                                <td>$<?php echo number_format($withdrawal['amount'] - $withdrawal['fee'], 2); ?></td>
                                                <td><?php echo $withdrawal['payment_method']; ?></td>
                                                <td>
                                                    <?php if ($withdrawal['status'] === 'pending'): ?>
                                                        <span class="badge bg-warning">Pending</span>
                                                    <?php elseif ($withdrawal['status'] === 'processed'): ?>
                                                        <span class="badge bg-success">Processed</span>
                                                    <?php elseif ($withdrawal['status'] === 'rejected'): ?>
                                                        <span class="badge bg-danger">Rejected</span>
                                                    <?php elseif ($withdrawal['status'] === 'blocked'): ?>
                                                        <span class="badge bg-danger">Blocked</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td><?php echo date('M j, Y g:i A', strtotime($withdrawal['created_at'])); ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </main>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
