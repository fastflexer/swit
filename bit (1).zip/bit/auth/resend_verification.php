<?php
session_start();
require_once '../config/config.php';
require_once '../includes/functions.php';

$error = '';
$success = '';

// Check if email is provided
if (!isset($_GET['email']) || empty($_GET['email'])) {
    $error = "Email address is required";
} else {
    $email = $_GET['email'];
    
    // Check if user exists
    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();
        
        // Check if email is already verified
        if ($user['email_verified'] == 1) {
            $error = "Your email has already been verified. You can now login.";
        } else {
            // Generate new verification token
            $verificationToken = bin2hex(random_bytes(32));
            
            // Update user's verification token
            $stmt = $conn->prepare("UPDATE users SET verification_token = ? WHERE id = ?");
            $stmt->bind_param("si", $verificationToken, $user['id']);
            
            if ($stmt->execute()) {
                // Send verification email
                $verificationLink = APP_URL . "/auth/verify_email.php?token=" . $verificationToken;
                $subject = "Verify Your Email Address - " . APP_NAME;
                $message = "
                    <html>
                    <head>
                        <title>Email Verification</title>
                    </head>
                    <body>
                        <h2>Welcome to " . APP_NAME . "!</h2>
                        <p>You requested a new verification email. Please click the link below to verify your email address:</p>
                        <p><a href='" . $verificationLink . "'>Verify Email Address</a></p>
                        <p>If you did not request this email, no further action is required.</p>
                        <p>Regards,<br>" . APP_NAME . " Team</p>
                    </body>
                    </html>
                ";
                
                if (sendEmail($email, $subject, $message)) {
                    $success = "Verification email has been resent. Please check your inbox.";
                } else {
                    $error = "Failed to send verification email. Please try again.";
                }
            } else {
                $error = "Failed to generate new verification token. Please try again.";
            }
        }
    } else {
        $error = "No account found with this email address";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resend Verification - <?php echo APP_NAME; ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/auth.css">
</head>
<body>
    <div class="container">
        <div class="row justify-content-center align-items-center min-vh-100">
            <div class="col-md-5">
                <div class="auth-card">
                    <div class="text-center mb-4">
                        <h2 class="auth-title">Resend Verification Email</h2>
                    </div>
                    
                    <?php if (!empty($error)): ?>
                        <div class="alert alert-danger">
                            <i class="fas fa-exclamation-circle me-2"></i>
                            <?php echo $error; ?>
                        </div>
                    <?php endif; ?>
                    
                    <?php if (!empty($success)): ?>
                        <div class="alert alert-success">
                            <i class="fas fa-check-circle me-2"></i>
                            <?php echo $success; ?>
                        </div>
                    <?php endif; ?>
                    
                    <div class="text-center">
                        <div class="verification-icon mb-4">
                            <i class="fas fa-envelope"></i>
                        </div>
                        <p>A verification email has been sent to your email address.</p>
                        <p>Please check your inbox and click on the verification link to complete your registration.</p>
                        <a href="login.php" class="btn btn-primary btn-lg mt-3">Back to Login</a>
                    </div>
                    
                    <div class="text-center mt-4">
                        <p class="small text-muted">© Copyright 2025 JetFx Growth All Rights Reserved.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
