<nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-dark sidebar collapse">
   <div class="position-sticky pt-3">
       <div class="text-center mb-3">
           <h5 class="text-white">JetFx Growth</h5>
       </div>
       <div class="text-center mb-3">
           <span class="badge bg-secondary">Admin Admin</span>
       </div>
       <ul class="nav flex-column">
           <li class="nav-item">
               <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'active' : ''; ?>" href="dashboard.php">
                   <i class="fas fa-tachometer-alt me-2"></i>
                   Dashboard
               </a>
           </li>
           <li class="nav-item">
               <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'investment.php' ? 'active' : ''; ?>" href="investment.php">
                   <i class="fas fa-chart-line me-2"></i>
                   Investment
               </a>
           </li>
           <li class="nav-item">
               <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'manage_users.php' ? 'active' : ''; ?>" href="manage_users.php">
                   <i class="fas fa-users me-2"></i>
                   Manage Users
               </a>
           </li>
           <li class="nav-item">
               <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'manage_deposits.php' ? 'active' : ''; ?>" href="manage_deposits.php">
                   <i class="fas fa-money-bill-wave me-2"></i>
                   Manage Deposits
               </a>
           </li>
           <li class="nav-item">
               <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'manage_withdrawals.php' ? 'active' : ''; ?>" href="manage_withdrawals.php">
                   <i class="fas fa-money-bill-transfer me-2"></i>
                   Manage Withdrawal
               </a>
           </li>
           <li class="nav-item">
               <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'manage_accounts.php' ? 'active' : ''; ?>" href="manage_accounts.php">
                   <i class="fas fa-wallet me-2"></i>
                   Manage Accounts
               </a>
           </li>
           <li class="nav-item">
               <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'manage_traders.php' || basename($_SERVER['PHP_SELF']) == 'trader_details.php' || basename($_SERVER['PHP_SELF']) == 'add_trader.php' || basename($_SERVER['PHP_SELF']) == 'edit_trader.php' ? 'active' : ''; ?>" href="manage_traders.php">
                   <i class="fas fa-user-tie me-2"></i>
                   Manage Traders
               </a>
           </li>
           <li class="nav-item">
               <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'manage_trades.php' || basename($_SERVER['PHP_SELF']) == 'add_trade.php' || basename($_SERVER['PHP_SELF']) == 'edit_trade.php' ? 'active' : ''; ?>" href="manage_trades.php">
                   <i class="fas fa-exchange-alt me-2"></i>
                   Manage Trades
               </a>
           </li>
           <li class="nav-item">
               <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'administrators.php' ? 'active' : ''; ?>" href="administrators.php">
                   <i class="fas fa-user-shield me-2"></i>
                   Administrator(s)
               </a>
           </li>
           <li class="nav-item">
               <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'settings.php' ? 'active' : ''; ?>" href="settings.php">
                   <i class="fas fa-cog me-2"></i>
                   Settings
               </a>
           </li>
           <li class="nav-item">
               <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'tasks.php' ? 'active' : ''; ?>" href="tasks.php">
                   <i class="fas fa-tasks me-2"></i>
                   Task
               </a>
           </li>
           <li class="nav-item">
               <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'leads.php' ? 'active' : ''; ?>" href="leads.php">
                   <i class="fas fa-user-plus me-2"></i>
                   Leads
               </a>
           </li>
           <li class="nav-item">
               <a class="nav-link" href="../about.php">
                   <i class="fas fa-info-circle me-2"></i>
                   About Onlinetrader
               </a>
           </li>
       </ul>
   </div>
</nav>
