<?php
require_once '../config/config.php';
require_once '../includes/auth_check.php';
require_once '../includes/functions.php';

// Get NFT ID from URL
$nftId = isset($_GET['id']) ? intval($_GET['id']) : 0;
if ($nftId <= 0) {
    header('Location: nfts.php');
    exit;
}

// Get NFT details
$stmt = $conn->prepare("SELECT n.*, u1.username as creator_username, u1.first_name as creator_first_name, u1.last_name as creator_last_name, u2.username as owner_username, u2.first_name as owner_first_name, u2.last_name as owner_last_name FROM nfts n JOIN users u1 ON n.creator_id = u1.id JOIN users u2 ON n.owner_id = u2.id WHERE n.id = ?");
$stmt->bind_param("i", $nftId);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    header('Location: nfts.php');
    exit;
}

$nft = $result->fetch_assoc();

// Get user information
$userId = $_SESSION['user_id'];
$user = getUserById($userId);

// Handle bid submission
$message = '';
$messageType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['bid_amount'])) {
    $bidAmount = floatval($_POST['bid_amount']);
    
    // Validate bid amount
    if ($bidAmount <= 0) {
        $message = "Bid amount must be greater than 0.";
        $messageType = "danger";
    } elseif ($bidAmount <= $nft['price']) {
        $message = "Bid amount must be greater than the current price.";
        $messageType = "danger";
    } elseif ($bidAmount > $user['balance']) {
        $message = "Insufficient balance to place this bid.";
        $messageType = "danger";
    } else {
        // Insert bid
        $stmt = $conn->prepare("INSERT INTO nft_bids (nft_id, user_id, amount, status, created_at) VALUES (?, ?, ?, 'pending', NOW())");
        $stmt->bind_param("iid", $nftId, $userId, $bidAmount);
        
        if ($stmt->execute()) {
            $message = "Your bid has been placed successfully!";
            $messageType = "success";
        } else {
            $message = "Error placing bid: " . $stmt->error;
            $messageType = "danger";
        }
    }
}

// Handle buy now
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['buy_now'])) {
    // Check if user has enough balance
    if ($user['balance'] < $nft['price']) {
        $message = "Insufficient balance to purchase this NFT.";
        $messageType = "danger";
    } elseif ($nft['owner_id'] == $userId) {
        $message = "You already own this NFT.";
        $messageType = "warning";
    } else {
        // Start transaction
        $conn->begin_transaction();
        
        try {
            // Deduct amount from buyer's balance
            $stmt = $conn->prepare("UPDATE users SET balance = balance - ? WHERE id = ?");
            $stmt->bind_param("di", $nft['price'], $userId);
            $stmt->execute();
            
            // Add amount to seller's balance
            $stmt = $conn->prepare("UPDATE users SET balance = balance + ? WHERE id = ?");
            $stmt->bind_param("di", $nft['price'], $nft['owner_id']);
            $stmt->execute();
            
            // Record transaction
            $stmt = $conn->prepare("INSERT INTO nft_transactions (nft_id, seller_id, buyer_id, price, transaction_type, created_at) VALUES (?, ?, ?, ?, 'direct_purchase', NOW())");
            $stmt->bind_param("iiid", $nftId, $nft['owner_id'], $userId, $nft['price']);
            $stmt->execute();
            
            // Update NFT ownership
            $stmt = $conn->prepare("UPDATE nfts SET owner_id = ?, last_sold_price = ?, last_sold_at = NOW() WHERE id = ?");
            $stmt->bind_param("idi", $userId, $nft['price'], $nftId);
            $stmt->execute();
            
            // Reject all pending bids
            $stmt = $conn->prepare("UPDATE nft_bids SET status = 'rejected' WHERE nft_id = ? AND status = 'pending'");
            $stmt->bind_param("i", $nftId);
            $stmt->execute();
            
            // Commit transaction
            $conn->commit();
            
            $message = "Congratulations! You have successfully purchased this NFT.";
            $messageType = "success";
            
            // Refresh NFT data
            $stmt = $conn->prepare("SELECT n.*, u1.username as creator_username, u1.first_name as creator_first_name, u1.last_name as creator_last_name, u2.username as owner_username, u2.first_name as owner_first_name, u2.last_name as owner_last_name FROM nfts n JOIN users u1 ON n.creator_id = u1.id JOIN users u2 ON n.owner_id = u2.id WHERE n.id = ?");
            $stmt->bind_param("i", $nftId);
            $stmt->execute();
            $nft = $stmt->get_result()->fetch_assoc();
        } catch (Exception $e) {
            // Rollback transaction on error
            $conn->rollback();
            $message = "Error processing purchase: " . $e->getMessage();
            $messageType = "danger";
        }
    }
}

// Get bid history
$stmt = $conn->prepare("SELECT b.*, u.username, u.first_name, u.last_name FROM nft_bids b JOIN users u ON b.user_id = u.id WHERE b.nft_id = ? ORDER BY b.amount DESC, b.created_at DESC");
$stmt->bind_param("i", $nftId);
$stmt->execute();
$bids = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Get transaction history
$stmt = $conn->prepare("SELECT t.*, s.username as seller_username, b.username as buyer_username FROM nft_transactions t JOIN users s ON t.seller_id = s.id JOIN users b ON t.buyer_id = b.id WHERE t.nft_id = ? ORDER BY t.created_at DESC");
$stmt->bind_param("i", $nftId);
$stmt->execute();
$transactions = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NFT Details - JetFx Growth</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        .nft-image {
            width: 100%;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .bid-history {
            max-height: 300px;
            overflow-y: auto;
        }
        .transaction-history {
            max-height: 300px;
            overflow-y: auto;
        }
        @media (max-width: 768px) {
            .nft-details-container {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <?php include 'includes/sidebar.php'; ?>
            
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">NFT Details</h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <div class="btn-group me-2">
                            <a href="nfts.php" class="btn btn-sm btn-outline-secondary">Back to NFTs</a>
                        </div>
                    </div>
                </div>
                
                <?php if (!empty($message)): ?>
                    <div class="alert alert-<?php echo $messageType; ?> alert-dismissible fade show" role="alert">
                        <?php echo $message; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>
                
                <div class="row nft-details-container">
                    <div class="col-md-5 mb-4">
                        <div class="card h-100">
                            <img src="<?php echo '../' . htmlspecialchars($nft['image_url']); ?>" class="nft-image" alt="<?php echo htmlspecialchars($nft['name']); ?>">
                        </div>
                    </div>
                    
                    <div class="col-md-7 mb-4">
                        <div class="card h-100">
                            <div class="card-body">
                                <h2 class="card-title"><?php echo htmlspecialchars($nft['name']); ?></h2>
                                <p class="text-muted">
                                    Category: <?php echo htmlspecialchars($nft['category']); ?>
                                </p>
                                
                                <div class="mb-4">
                                    <h5>Description</h5>
                                    <p><?php echo nl2br(htmlspecialchars($nft['description'])); ?></p>
                                </div>
                                
                                <div class="d-flex justify-content-between align-items-center mb-4">
                                    <div>
                                        <h4>Price: <?php echo $nft['price']; ?> ETH</h4>
                                    </div>
                                    <div>
                                        <p class="mb-0">
                                            <strong>Creator:</strong> <?php echo htmlspecialchars($nft['creator_first_name'] . ' ' . $nft['creator_last_name']); ?> (@<?php echo htmlspecialchars($nft['creator_username']); ?>)
                                        </p>
                                        <p class="mb-0">
                                            <strong>Owner:</strong> <?php echo htmlspecialchars($nft['owner_first_name'] . ' ' . $nft['owner_last_name']); ?> (@<?php echo htmlspecialchars($nft['owner_username']); ?>)
                                        </p>
                                    </div>
                                </div>
                                
                                <?php if ($nft['owner_id'] != $userId): ?>
                                    <div class="d-grid gap-2 mb-4">
                                        <form method="POST">
                                            <input type="hidden" name="buy_now" value="1">
                                            <button type="submit" class="btn btn-primary btn-lg w-100">Buy Now (<?php echo $nft['price']; ?> ETH)</button>
                                        </form>
                                    </div>
                                    
                                    <div class="card mb-3">
                                        <div class="card-header">
                                            <h5 class="mb-0">Place a Bid</h5>
                                        </div>
                                        <div class="card-body">
                                            <form method="POST">
                                                <div class="mb-3">
                                                    <label for="bid_amount" class="form-label">Bid Amount (ETH)</label>
                                                    <input type="number" step="0.001" min="<?php echo $nft['price'] + 0.001; ?>" class="form-control" id="bid_amount" name="bid_amount" placeholder="Enter your bid amount" required>
                                                    <div class="form-text">Your bid must be higher than the current price.</div>
                                                </div>
                                                <div class="d-grid">
                                                    <button type="submit" class="btn btn-outline-primary">Submit Bid</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                <?php else: ?>
                                    <div class="alert alert-info">
                                        <i class="fas fa-info-circle me-2"></i> You are the owner of this NFT.
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-6 mb-4">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="mb-0">Bid History</h5>
                            </div>
                            <div class="card-body bid-history">
                                <?php if (empty($bids)): ?>
                                    <p class="text-muted">No bids have been placed yet.</p>
                                <?php else: ?>
                                    <div class="table-responsive">
                                        <table class="table table-striped table-hover">
                                            <thead>
                                                <tr>
                                                    <th>Bidder</th>
                                                    <th>Amount</th>
                                                    <th>Date</th>
                                                    <th>Status</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php foreach ($bids as $bid): ?>
                                                    <tr>
                                                        <td><?php echo htmlspecialchars($bid['first_name'] . ' ' . $bid['last_name']); ?></td>
                                                        <td><?php echo $bid['amount']; ?> ETH</td>
                                                        <td><?php echo date('M j, Y H:i', strtotime($bid['created_at'])); ?></td>
                                                        <td>
                                                            <?php if ($bid['status'] == 'pending'): ?>
                                                                <span class="badge bg-warning">Pending</span>
                                                            <?php elseif ($bid['status'] == 'accepted'): ?>
                                                                <span class="badge bg-success">Accepted</span>
                                                            <?php else: ?>
                                                                <span class="badge bg-danger">Rejected</span>
                                                            <?php endif; ?>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-6 mb-4">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="mb-0">Transaction History</h5>
                            </div>
                            <div class="card-body transaction-history">
                                <?php if (empty($transactions)): ?>
                                    <p class="text-muted">No transactions have been recorded yet.</p>
                                <?php else: ?>
                                    <div class="table-responsive">
                                        <table class="table table-striped table-hover">
                                            <thead>
                                                <tr>
                                                    <th>Type</th>
                                                    <th>From</th>
                                                    <th>To</th>
                                                    <th>Price</th>
                                                    <th>Date</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php foreach ($transactions as $transaction): ?>
                                                    <tr>
                                                        <td>
                                                            <?php if ($transaction['transaction_type'] == 'direct_purchase'): ?>
                                                                <span class="badge bg-primary">Purchase</span>
                                                            <?php else: ?>
                                                                <span class="badge bg-info">Bid Accepted</span>
                                                            <?php endif; ?>
                                                        </td>
                                                        <td><?php echo htmlspecialchars($transaction['seller_username']); ?></td>
                                                        <td><?php echo htmlspecialchars($transaction['buyer_username']); ?></td>
                                                        <td><?php echo $transaction['price']; ?> ETH</td>
                                                        <td><?php echo date('M j, Y H:i', strtotime($transaction['created_at'])); ?></td>
                                                    </tr>
                                                <?php endforeach; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
