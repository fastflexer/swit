<?php
session_start();
require_once '../config/config.php';
require_once '../includes/auth_check.php';
require_once '../includes/functions.php';

// Check if user is logged in
requireLogin();

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate inputs
    $loanId = isset($_POST['loan_id']) ? intval($_POST['loan_id']) : 0;
    $paymentAmount = isset($_POST['payment_amount']) ? floatval($_POST['payment_amount']) : 0;
    $paymentMethodId = isset($_POST['payment_method']) ? intval($_POST['payment_method']) : 0;
    $transactionId = isset($_POST['transaction_id']) ? trim($_POST['transaction_id']) : '';
    $notes = isset($_POST['notes']) ? trim($_POST['notes']) : '';
    
    // Validate required fields
    $errors = [];
    
    if (empty($loanId)) {
        $errors[] = "Loan ID is required.";
    }
    
    if (empty($paymentAmount) || $paymentAmount <= 0) {
        $errors[] = "Valid payment amount is required.";
    }
    
    if (empty($paymentMethodId)) {
        $errors[] = "Payment method is required.";
    }
    
    if (empty($transactionId)) {
        $errors[] = "Transaction ID is required.";
    }
    
    // Check if proof image is uploaded
    if (!isset($_FILES['proof_image']) || $_FILES['proof_image']['error'] !== UPLOAD_ERR_OK) {
        $errors[] = "Payment proof image is required.";
    } else {
        // Validate image file
        $allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
        $maxSize = 5 * 1024 * 1024; // 5MB
        
        if (!in_array($_FILES['proof_image']['type'], $allowedTypes)) {
            $errors[] = "Invalid file type. Only JPG, PNG, and GIF images are allowed.";
        }
        
        if ($_FILES['proof_image']['size'] > $maxSize) {
            $errors[] = "File size exceeds the maximum limit of 5MB.";
        }
    }
    
    // If no errors, proceed with payment processing
    if (empty($errors)) {
        // Get loan details
        $loan = getLoanById($loanId);
        
        if (!$loan || $loan['user_id'] != $_SESSION['user_id'] || $loan['status'] !== 'approved') {
            $_SESSION['repay_message'] = "Loan not found, not approved, or you don't have permission to repay it.";
            $_SESSION['repay_message_type'] = "danger";
            header("Location: repay_loan.php?id=" . $loanId);
            exit;
        }
        
        // Calculate remaining amount
        $remainingAmount = $loan['total_repayment'] - $loan['amount_paid'];
        
        // Validate payment amount
        if ($paymentAmount > $remainingAmount) {
            $_SESSION['repay_message'] = "Payment amount cannot exceed the remaining balance of $" . number_format($remainingAmount, 2) . ".";
            $_SESSION['repay_message_type'] = "danger";
            header("Location: repay_loan.php?id=" . $loanId);
            exit;
        }
        
        // Get payment method details
        $paymentMethod = getPaymentMethodById($paymentMethodId);
        
        if (!$paymentMethod) {
            $_SESSION['repay_message'] = "Invalid payment method selected.";
            $_SESSION['repay_message_type'] = "danger";
            header("Location: repay_loan.php?id=" . $loanId);
            exit;
        }
        
        // Upload proof image
        $uploadDir = '../uploads/loan_payments/';
        if (!file_exists($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }
        
        $fileName = time() . '_' . $_SESSION['user_id'] . '_' . basename($_FILES['proof_image']['name']);
        $uploadPath = $uploadDir . $fileName;
        
        if (move_uploaded_file($_FILES['proof_image']['tmp_name'], $uploadPath)) {
            // Insert payment record
            $result = recordLoanPayment(
                $loanId,
                $_SESSION['user_id'],
                $paymentAmount,
                $paymentMethod['name'],
                $transactionId,
                $fileName,
                $notes
            );
            
            if ($result) {
                // Update loan amount paid
                updateLoanAmountPaid($loanId, $paymentAmount);
                
                // Check if loan is fully paid
                $newRemainingAmount = $remainingAmount - $paymentAmount;
                if ($newRemainingAmount <= 0) {
                    // Mark loan as paid
                    updateLoanStatus($loanId, 'paid');
                }
                
                // Get user data
                $user = getUserById($_SESSION['user_id']);
                
                // Send email notification
                $paymentDetails = [
                    'loan_id' => $loan['loan_id'],
                    'amount' => $paymentAmount,
                    'payment_method' => $paymentMethod['name'],
                    'transaction_id' => $transactionId,
                    'created_at' => date('Y-m-d H:i:s')
                ];
                
                sendLoanPaymentNotification($user, $paymentDetails);
                
                $_SESSION['loan_message'] = "Your payment has been submitted successfully and is pending confirmation.";
                $_SESSION['loan_message_type'] = "success";
                header("Location: loans.php");
                exit;
            } else {
                $_SESSION['repay_message'] = "Failed to record payment. Please try again.";
                $_SESSION['repay_message_type'] = "danger";
            }
        } else {
            $_SESSION['repay_message'] = "Failed to upload proof image. Please try again.";
            $_SESSION['repay_message_type'] = "danger";
        }
    } else {
        // If there are errors, set error message
        $_SESSION['repay_message'] = "Please correct the following errors: " . implode(" ", $errors);
        $_SESSION['repay_message_type'] = "danger";
    }
    
    // Redirect back to repay loan page
    header("Location: repay_loan.php?id=" . $loanId);
    exit;
} else {
    // If not POST request, redirect to loans page
    header("Location: loans.php");
    exit;
}
?>
