<?php
require_once '../config/config.php';
require_once '../includes/auth_check.php';
require_once '../includes/admin_check.php';
require_once '../includes/functions.php';

// Get all signals
$stmt = $conn->prepare("SELECT s.*, p.name as plan_name FROM signals s LEFT JOIN subscription_plans p ON s.min_plan_id = p.id ORDER BY s.created_at DESC");
$stmt->execute();
$signals = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Process signal deletion
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_signal'])) {
    $signalId = intval($_POST['signal_id']);
    
    // Delete signal
    $stmt = $conn->prepare("DELETE FROM signals WHERE id = ?");
    $stmt->bind_param("i", $signalId);
    
    if ($stmt->execute()) {
        $message = "Signal deleted successfully.";
        $messageType = "success";
        
        // Refresh signals list
        $stmt = $conn->prepare("SELECT s.*, p.name as plan_name FROM signals s LEFT JOIN subscription_plans p ON s.min_plan_id = p.id ORDER BY s.created_at DESC");
        $stmt->execute();
        $signals = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    } else {
        $message = "Error deleting signal: " . $stmt->error;
        $messageType = "danger";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Signals - Admin Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <style>
        .table-responsive {
            overflow-x: auto;
        }
        @media (max-width: 768px) {
            .action-buttons {
                display: flex;
                flex-direction: column;
                gap: 5px;
            }
            .action-buttons .btn {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <?php include 'includes/sidebar.php'; ?>
            
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Manage Signals</h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <div class="btn-group me-2">
                            <a href="add_signal.php" class="btn btn-sm btn-outline-secondary">Add Signal</a>
                        </div>
                    </div>
                </div>
                
                <?php if (isset($message)): ?>
                    <div class="alert alert-<?php echo $messageType; ?> alert-dismissible fade show" role="alert">
                        <?php echo $message; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>
                
                <div class="card mb-4">
                    <div class="card-header">
                        <i class="fas fa-table me-1"></i>
                        All Signals
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-hover" id="signalsTable">
                                <thead>
                                    <tr>
                                        <th>Title</th>
                                        <th>Asset</th>
                                        <th>Direction</th>
                                        <th>Entry Price</th>
                                        <th>Take Profit</th>
                                        <th>Stop Loss</th>
                                        <th>Min Plan</th>
                                        <th>Status</th>
                                        <th>Created</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($signals as $signal): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($signal['title']); ?></td>
                                            <td><?php echo htmlspecialchars($signal['asset']); ?></td>
                                            <td>
                                                <?php if ($signal['direction'] == 'buy'): ?>
                                                    <span class="badge bg-success">BUY</span>
                                                <?php else: ?>
                                                    <span class="badge bg-danger">SELL</span>
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo $signal['entry_price']; ?></td>
                                            <td><?php echo $signal['take_profit']; ?></td>
                                            <td><?php echo $signal['stop_loss']; ?></td>
                                            <td><?php echo htmlspecialchars($signal['plan_name'] ?? 'All Plans'); ?></td>
                                            <td>
                                                <?php if ($signal['status'] == 'active'): ?>
                                                    <span class="badge bg-success">Active</span>
                                                <?php elseif ($signal['status'] == 'expired'): ?>
                                                    <span class="badge bg-warning">Expired</span>
                                                <?php else: ?>
                                                    <span class="badge bg-danger">Cancelled</span>
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo date('M j, Y', strtotime($signal['created_at'])); ?></td>
                                            <td>
                                                <div class="action-buttons">
                                                    <a href="edit_signal.php?id=<?php echo $signal['id']; ?>" class="btn btn-sm btn-primary">Edit</a>
                                                    <button type="button" class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#deleteModal<?php echo $signal['id']; ?>">Delete</button>
                                                </div>
                                            </td>
                                        </tr>
                                        
                                        <!-- Delete Modal -->
                                        <div class="modal fade" id="deleteModal<?php echo $signal['id']; ?>" tabindex="-1" aria-labelledby="deleteModalLabel<?php echo $signal['id']; ?>" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="deleteModalLabel<?php echo $signal['id']; ?>">Confirm Deletion</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        Are you sure you want to delete the signal "<?php echo htmlspecialchars($signal['title']); ?>"? This action cannot be undone.
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                                        <form method="POST">
                                                            <input type="hidden" name="signal_id" value="<?php echo $signal['id']; ?>">
                                                            <input type="hidden" name="delete_signal" value="1">
                                                            <button type="submit" class="btn btn-danger">Delete</button>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const datatablesSimple = document.getElementById('signalsTable');
            if (datatablesSimple) {
                new simpleDatatables.DataTable(datatablesSimple);
            }
        });
    </script>
</body>
</html>
