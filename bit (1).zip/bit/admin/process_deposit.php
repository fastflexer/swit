<?php
session_start();
require_once '../config/config.php';
require_once '../includes/functions.php';
require_once '../includes/admin_auth_check.php';

if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: deposits.php");
    exit();
}

$depositId = $_GET['id'];
$action = $_GET['action'] ?? '';

if ($action !== 'approve' && $action !== 'reject') {
    header("Location: deposits.php");
    exit();
}

// Get deposit information
$stmt = $conn->prepare("SELECT d.*, u.id as user_id, u.full_name, u.email, u.balance FROM deposits d JOIN users u ON d.user_id = u.id WHERE d.id = ?");
$stmt->bind_param("i", $depositId);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows !== 1) {
    header("Location: deposits.php");
    exit();
}

$deposit = $result->fetch_assoc();

// Check if deposit is already processed
if ($deposit['status'] !== 'pending') {
    $_SESSION['error'] = "This deposit has already been processed.";
    header("Location: deposits.php");
    exit();
}

// Process the deposit
if ($action === 'approve') {
    // Start transaction
    $conn->begin_transaction();
    
    try {
        // Update deposit status
        $stmt = $conn->prepare("UPDATE deposits SET status = 'processed', processed_at = NOW(), processed_by = ? WHERE id = ?");
        $stmt->bind_param("ii", $_SESSION['user_id'], $depositId);
        $stmt->execute();
        
        // Update user balance
        $newBalance = $deposit['balance'] + $deposit['amount'];
        $stmt = $conn->prepare("UPDATE users SET balance = ? WHERE id = ?");
        $stmt->bind_param("di", $newBalance, $deposit['user_id']);
        $stmt->execute();
        
        // Add transaction record
        $stmt = $conn->prepare("INSERT INTO transactions (user_id, type, amount, description, created_at) VALUES (?, 'deposit', ?, 'Deposit via " . $deposit['payment_method'] . "', NOW())");
        $stmt->bind_param("id", $deposit['user_id'], $deposit['amount']);
        $stmt->execute();
        
        // Commit transaction
        $conn->commit();
        
        // Update deposit status for email notification
        $deposit['status'] = 'processed';
        
        // Send deposit notification email
        $user = [
            'full_name' => $deposit['full_name'],
            'email' => $deposit['email']
        ];
        sendDepositNotification($user, $deposit);
        
        $_SESSION['success'] = "Deposit approved successfully.";
    } catch (Exception $e) {
        // Rollback transaction on error
        $conn->rollback();
        $_SESSION['error'] = "Failed to approve deposit: " . $e->getMessage();
    }
} else if ($action === 'reject') {
    // Update deposit status
    $stmt = $conn->prepare("UPDATE deposits SET status = 'rejected', processed_at = NOW(), processed_by = ? WHERE id = ?");
    $stmt->bind_param("ii", $_SESSION['user_id'], $depositId);
    
    if ($stmt->execute()) {
        // Update deposit status for email notification
        $deposit['status'] = 'rejected';
        
        // Send deposit notification email
        $user = [
            'full_name' => $deposit['full_name'],
            'email' => $deposit['email']
        ];
        sendDepositNotification($user, $deposit);
        
        $_SESSION['success'] = "Deposit rejected successfully.";
    } else {
        $_SESSION['error'] = "Failed to reject deposit.";
    }
}

header("Location: deposits.php");
exit();
?>
