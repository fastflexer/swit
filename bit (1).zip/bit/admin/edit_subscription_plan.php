<?php
require_once '../config/config.php';
require_once '../includes/auth_check.php';
require_once '../includes/admin_check.php';
require_once '../includes/functions.php';

// Check if plan ID is provided
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header('Location: manage_subscription_plans.php');
    exit;
}

$planId = intval($_GET['id']);

// Get plan details
$stmt = $conn->prepare("SELECT * FROM subscription_plans WHERE id = ?");
$stmt->bind_param("i", $planId);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    header('Location: manage_subscription_plans.php');
    exit;
}

$plan = $result->fetch_assoc();
$planFeatures = [];

if ($plan['type'] == 'signal' && !empty($plan['features'])) {
    $planFeatures = json_decode($plan['features'], true);
    if (!is_array($planFeatures)) {
        $planFeatures = [];
    }
}

// Process form submission
$message = '';
$messageType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $duration = intval($_POST['duration']);
    $status = trim($_POST['status']);
    
    // Validate inputs
    if (empty($name) || $duration <= 0) {
        $message = 'All fields are required and duration must be greater than 0.';
        $messageType = 'danger';
    } else {
        // Prepare data based on plan type
        if ($plan['type'] == 'investment') {
            $minAmount = floatval($_POST['min_amount']);
            $maxAmount = floatval($_POST['max_amount']);
            $roiRate = floatval($_POST['roi_rate']);
            
            if ($minAmount <= 0 || $roiRate <= 0) {
                $message = 'Minimum amount and ROI rate must be greater than 0.';
                $messageType = 'danger';
            } else {
                // Update investment plan
                $stmt = $conn->prepare("UPDATE subscription_plans SET name = ?, min_amount = ?, max_amount = ?, roi_rate = ?, duration = ?, status = ? WHERE id = ?");
                $stmt->bind_param("sdddssi", $name, $minAmount, $maxAmount, $roiRate, $duration, $status, $planId);
            }
        } else { // Signal plan
            $price = floatval($_POST['price']);
            $featuresArray = isset($_POST['features']) ? $_POST['features'] : [];
            $features = json_encode($featuresArray);
            
            if ($price <= 0) {
                $message = 'Price must be greater than 0.';
                $messageType = 'danger';
            } else {
                // Update signal plan
                $stmt = $conn->prepare("UPDATE subscription_plans SET name = ?, price = ?, duration = ?, features = ?, status = ? WHERE id = ?");
                $stmt->bind_param("sdssi", $name, $price, $duration, $features, $status, $planId);
            }
        }
        
        // Execute query if validation passed
        if (!isset($stmt)) {
            // Do nothing, validation failed
        } elseif ($stmt->execute()) {
            $message = "Subscription plan updated successfully!";
            $messageType = 'success';
            
            // Refresh plan data
            $stmt = $conn->prepare("SELECT * FROM subscription_plans WHERE id = ?");
            $stmt->bind_param("i", $planId);
            $stmt->execute();
            $plan = $stmt->get_result()->fetch_assoc();
            
            if ($plan['type'] == 'signal' && !empty($plan['features'])) {
                $planFeatures = json_decode($plan['features'], true);
                if (!is_array($planFeatures)) {
                    $planFeatures = [];
                }
            }
        } else {
            $message = "Error: " . $stmt->error;
            $messageType = 'danger';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Subscription Plan - Admin Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <style>
        .form-container {
            max-width: 800px;
            margin: 0 auto;
        }
        .feature-input-group {
            margin-bottom: 10px;
        }
        @media (max-width: 768px) {
            .feature-controls {
                margin-top: 10px;
            }
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <?php include 'includes/sidebar.php'; ?>
            
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Edit Subscription Plan</h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <div class="btn-group me-2">
                            <a href="manage_subscription_plans.php" class="btn btn-sm btn-outline-secondary">Back to Plans</a>
                        </div>
                    </div>
                </div>
                
                <?php if (!empty($message)): ?>
                    <div class="alert alert-<?php echo $messageType; ?> alert-dismissible fade show" role="alert">
                        <?php echo $message; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>
                
                <div class="card mb-4">
                    <div class="card-header">
                        <i class="fas fa-edit me-1"></i>
                        Edit Subscription Plan: <?php echo htmlspecialchars($plan['name']); ?>
                    </div>
                    <div class="card-body">
                        <div class="form-container">
                            <form method="POST" id="planForm">
                                <div class="mb-3">
                                    <label for="name" class="form-label">Plan Name</label>
                                    <input type="text" class="form-control" id="name" name="name" value="<?php echo htmlspecialchars($plan['name']); ?>" required>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="type" class="form-label">Plan Type</label>
                                    <input type="text" class="form-control" value="<?php echo $plan['type'] == 'investment' ? 'Investment Plan' : 'Signal Plan'; ?>" readonly>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="duration" class="form-label">Duration (days)</label>
                                    <input type="number" class="form-control" id="duration" name="duration" min="1" value="<?php echo $plan['duration']; ?>" required>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="status" class="form-label">Status</label>
                                    <select class="form-select" id="status" name="status" required>
                                        <option value="active" <?php echo $plan['status'] == 'active' ? 'selected' : ''; ?>>Active</option>
                                        <option value="inactive" <?php echo $plan['status'] == 'inactive' ? 'selected' : ''; ?>>Inactive</option>
                                    </select>
                                </div>
                                
                                <?php if ($plan['type'] == 'investment'): ?>
                                    <!-- Investment Plan Fields -->
                                    <div id="investmentFields">
                                        <div class="mb-3">
                                            <label for="min_amount" class="form-label">Minimum Amount ($)</label>
                                            <input type="number" class="form-control" id="min_amount" name="min_amount" step="0.01" min="0.01" value="<?php echo $plan['min_amount']; ?>" required>
                                        </div>
                                        
                                        <div class="mb-3">
                                            <label for="max_amount" class="form-label">Maximum Amount ($)</label>
                                            <input type="number" class="form-control" id="max_amount" name="max_amount" step="0.01" min="0" value="<?php echo $plan['max_amount']; ?>">
                                            <div class="form-text">Enter 0 for unlimited.</div>
                                        </div>
                                        
                                        <div class="mb-3">
                                            <label for="roi_rate" class="form-label">ROI Rate (% daily)</label>
                                            <input type="number" class="form-control" id="roi_rate" name="roi_rate" step="0.01" min="0.01" value="<?php echo $plan['roi_rate']; ?>" required>
                                        </div>
                                    </div>
                                <?php else: ?>
                                    <!-- Signal Plan Fields -->
                                    <div id="signalFields">
                                        <div class="mb-3">
                                            <label for="price" class="form-label">Price ($)</label>
                                            <input type="number" class="form-control" id="price" name="price" step="0.01" min="0.01" value="<?php echo $plan['price']; ?>" required>
                                        </div>
                                        
                                        <div class="mb-3">
                                            <label class="form-label">Features</label>
                                            <div id="featuresContainer">
                                                <?php if (empty($planFeatures)): ?>
                                                    <div class="feature-input-group row">
                                                        <div class="col-md-10">
                                                            <input type="text" class="form-control" name="features[]" placeholder="Enter a feature">
                                                        </div>
                                                        <div class="col-md-2 feature-controls">
                                                            <button type="button"
