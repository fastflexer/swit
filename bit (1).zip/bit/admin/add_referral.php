<?php
session_start();
require_once '../config/config.php';
require_once '../includes/auth_check.php';
require_once '../includes/functions.php';

// Check if user is admin
requireAdmin();
requireOTPVerification();

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: manage_users.php");
    exit();
}

$userId = $_POST['user_id'] ?? 0;
$referralEmail = $_POST['referral_email'] ?? '';
$bonusAmount = $_POST['bonus_amount'] ?? 0;

// Validate input
if (empty($userId) || empty($referralEmail)) {
    $_SESSION['error'] = "User ID and referral email are required";
    header("Location: user_details.php?id=" . $userId);
    exit();
}

// Check if referral email exists
$stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
$stmt->bind_param("s", $referralEmail);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    $_SESSION['error'] = "Referral email does not exist in the system";
    header("Location: user_details.php?id=" . $userId);
    exit();
}

$referral = $result->fetch_assoc();

// Update referral
$stmt = $conn->prepare("UPDATE users SET referred_by = ? WHERE id = ?");
$stmt->bind_param("ii", $userId, $referral['id']);

if ($stmt->execute()) {
    // Add bonus if specified
    if ($bonusAmount > 0) {
        // Add bonus to referrer
        $stmt = $conn->prepare("UPDATE users SET balance = balance + ? WHERE id = ?");
        $stmt->bind_param("di", $bonusAmount, $userId);
        $stmt->execute();
        
        // Log bonus
        $stmt = $conn->prepare("INSERT INTO bonuses (user_id, amount, type, description, created_at) VALUES (?, ?, 'referral', 'Referral bonus for referring " . $referral['email'] . "', NOW())");
        $stmt->bind_param("id", $userId, $bonusAmount);
        $stmt->execute();
    }
    
    $_SESSION['success'] = "Referral added successfully";
} else {
    $_SESSION['error'] = "Failed to add referral";
}

// Redirect back to user details
header("Location: user_details.php?id=" . $userId);
exit();
?>
