<?php
session_start();
require_once '../config/config.php';
require_once '../includes/functions.php';
require_once '../includes/admin_auth_check.php';

if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: trades.php");
    exit();
}

$tradeId = $_GET['id'];
$action = $_GET['action'] ?? '';

if ($action !== 'close') {
    header("Location: trades.php");
    exit();
}

// Get trade information
$stmt = $conn->prepare("SELECT t.*, u.id as user_id, u.full_name, u.email, u.balance FROM trades t JOIN users u ON t.user_id = u.id WHERE t.id = ?");
$stmt->bind_param("i", $tradeId);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows !== 1) {
    header("Location: trades.php");
    exit();
}

$trade = $result->fetch_assoc();

// Check if trade is already closed
if ($trade['status'] !== 'open') {
    $_SESSION['error'] = "This trade is already closed.";
    header("Location: trades.php");
    exit();
}

// Get POST data
$exitPrice = $_POST['exit_price'] ?? 0;
$result = $_POST['result'] ?? '';
$profit = $_POST['profit'] ?? 0;
$loss = $_POST['loss'] ?? 0;

// Validate input
if (empty($exitPrice) || $exitPrice <= 0) {
    $_SESSION['error'] = "Please enter a valid exit price.";
    header("Location: close_trade.php?id=" . $tradeId);
    exit();
}

if (empty($result) || ($result !== 'win' && $result !== 'loss')) {
    $_SESSION['error'] = "Please select a valid result.";
    header("Location: close_trade.php?id=" . $tradeId);
    exit();
}

if ($result === 'win' && (empty($profit) || $profit <= 0)) {
    $_SESSION['error'] = "Please enter a valid profit amount.";
    header("Location: close_trade.php?id=" . $tradeId);
    exit();
}

if ($result === 'loss' && (empty($loss) || $loss <= 0)) {
    $_SESSION['error'] = "Please enter a valid loss amount.";
    header("Location: close_trade.php?id=" . $tradeId);
    exit();
}

// Start transaction
$conn->begin_transaction();

try {
    // Update trade
    $stmt = $conn->prepare("UPDATE trades SET exit_price = ?, result = ?, profit = ?, loss = ?, status = 'closed', close_time = NOW() WHERE id = ?");
    $stmt->bind_param("dsddi", $exitPrice, $result, $profit, $loss, $tradeId);
    $stmt->execute();
    
    // Update user balance
    $newBalance = $trade['balance'];
    if ($result === 'win') {
        $newBalance += $profit;
    } else {
        $newBalance -= $loss;
    }
    
    $stmt = $conn->prepare("UPDATE users SET balance = ? WHERE id = ?");
    $stmt->bind_param("di", $newBalance, $trade['user_id']);
    $stmt->execute();
    
    // Add transaction record
    $transactionType = $result === 'win' ? 'trade_profit' : 'trade_loss';
    $transactionAmount = $result === 'win' ? $profit : $loss;
    $transactionDescription = "Trade " . ($result === 'win' ? "profit" : "loss") . " for " . $trade['symbol'];
    
    $stmt = $conn->prepare("INSERT INTO transactions (user_id, type, amount, description, created_at) VALUES (?, ?, ?, ?, NOW())");
    $stmt->bind_param("idss", $trade['user_id'], $transactionType, $transactionAmount, $transactionDescription);
    $stmt->execute();
    
    // Commit transaction
    $conn->commit();
    
    // Get updated trade for email
    $stmt = $conn->prepare("SELECT * FROM trades WHERE id = ?");
    $stmt->bind_param("i", $tradeId);
    $stmt->execute();
    $result = $stmt->get_result();
    $updatedTrade = $result->fetch_assoc();
    
    // Send trade result notification email
    $user = [
        'full_name' => $trade['full_name'],
        'email' => $trade['email']
    ];
    sendTradeResultNotification($user, $updatedTrade);
    
    // Process copy trades if this is a trader's trade
    processCopyTrades($tradeId, $updatedTrade);
    
    $_SESSION['success'] = "Trade closed successfully.";
} catch (Exception $e) {
    // Rollback transaction on error
    $conn->rollback();
    $_SESSION['error'] = "Failed to close trade: " . $e->getMessage();
}

header("Location: trades.php");
exit();

// Function to process copy trades
function processCopyTrades($tradeId, $trade) {
    global $conn;
    
    // Check if this trade belongs to a trader
    $stmt = $conn->prepare("SELECT * FROM traders WHERE user_id = ?");
    $stmt->bind_param("i", $trade['user_id']);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        // Not a trader's trade, no copy trades to process
        return;
    }
    
    $trader = $result->fetch_assoc();
    
    // Get all users who are copying this trader
    $stmt = $conn->prepare("SELECT * FROM copy_trades WHERE trader_id = ? AND status = 'active'");
    $stmt->bind_param("i", $trader['id']);
    $stmt->execute();
    $result = $stmt->get_result();
    
    while ($copyTrade = $result->fetch_assoc()) {
        // Get user information
        $stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
        $stmt->bind_param("i", $copyTrade['user_id']);
        $stmt->execute();
        $userResult = $stmt->get_result();
        $user = $userResult->fetch_assoc();
        
        // Calculate proportional profit/loss based on copy percentage
        $copyPercentage = $copyTrade['copy_percentage'] / 100;
        $profit = $trade['result'] === 'win' ? $trade['profit'] * $copyPercentage : 0;
        $loss = $trade['result'] === 'loss' ? $trade['loss'] * $copyPercentage : 0;
        
        // Start transaction for this copy trade
        $conn->begin_transaction();
        
        try {
            // Create copy trade record
            $stmt = $conn->prepare("INSERT INTO user_copy_trades (user_id, trader_id, original_trade_id, symbol, type, entry_price, exit_price, volume, result, profit, loss, status, open_time, close_time) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'closed', ?, NOW())");
            $stmt->bind_param("iiissdddsddss", $copyTrade['user_id'], $trader['id'], $trade['id'], $trade['symbol'], $trade['type'], $trade['entry_price'], $trade['exit_price'], $trade['volume'] * $copyPercentage, $trade['result'], $profit, $loss, $trade['open_time']);
            $stmt->execute();
            $copyTradeId = $conn->insert_id;
            
            // Update user balance
            $newBalance = $user['balance'];
            if ($trade['result'] === 'win') {
                $newBalance += $profit;
            } else {
                $newBalance -= $loss;
            }
            
            $stmt = $conn->prepare("UPDATE users SET balance = ? WHERE id = ?");
            $stmt->bind_param("di", $newBalance, $user['id']);
            $stmt->execute();
            
            // Add transaction record
            $transactionType = $trade['result'] === 'win' ? 'copy_trade_profit' : 'copy_trade_loss';
            $transactionAmount = $trade['result'] === 'win' ? $profit : $loss;
            $transactionDescription = "Copy trade " . ($trade['result'] === 'win' ? "profit" : "loss") . " for " . $trade['symbol'] . " from trader " . $trader['name'];
            
            $stmt = $conn->prepare("INSERT INTO transactions (user_id, type, amount, description, created_at) VALUES (?, ?, ?, ?, NOW())");
            $stmt->bind_param("idss", $user['id'], $transactionType, $transactionAmount, $transactionDescription);
            $stmt->execute();
            
            // Commit transaction
            $conn->commit();
            
            // Get the trader's user information for the email
            $stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
            $stmt->bind_param("i", $trader['user_id']);
            $stmt->execute();
            $traderUserResult = $stmt->get_result();
            $traderUser = $traderUserResult->fetch_assoc();
            
            // Get the copy trade for email
            $stmt = $conn->prepare("SELECT * FROM user_copy_trades WHERE id = ?");
            $stmt->bind_param("i", $copyTradeId);
            $stmt->execute();
            $copyTradeResult = $stmt->get_result();
            $copyTradeDetails = $copyTradeResult->fetch_assoc();
            
            // Send copy trade notification email
            $traderInfo = [
                'full_name' => $traderUser['full_name'],
                'win_rate' => $trader['win_rate']
            ];
            sendCopyTradeNotification($user, $copyTradeDetails, $traderInfo);
            
        } catch (Exception $e) {
            // Rollback transaction on error
            $conn->rollback();
            error_log("Failed to process copy trade for user " . $copyTrade['user_id'] . ": " . $e->getMessage());
        }
    }
}
?>
