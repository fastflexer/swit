<?php
session_start();
require_once '../config/config.php';
require_once '../includes/auth_check.php';
require_once '../includes/functions.php';

// Check if user is logged in
requireLogin();

// Get user data
$user = getUserById($_SESSION['user_id']);

// Get user's theme preference
$theme = $user['theme'] ?? 'dark';

// Handle deposit form submission
$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['submit_deposit'])) {
        $amount = $_POST['amount'] ?? 0;
        $paymentMethod = $_POST['payment_method'] ?? '';
        $transactionId = $_POST['transaction_id'] ?? '';
        
        if (empty($amount) || !is_numeric($amount) || $amount <= 0) {
            $error = "Please enter a valid amount";
        } elseif (empty($paymentMethod)) {
            $error = "Please select a payment method";
        } else {
            // Handle file upload if provided
            $proofFileName = null;
            if (isset($_FILES['payment_proof']) && $_FILES['payment_proof']['error'] === UPLOAD_ERR_OK) {
                $allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'application/pdf'];
                $maxSize = 5 * 1024 * 1024; // 5MB
                
                if (!in_array($_FILES['payment_proof']['type'], $allowedTypes)) {
                    $error = "Invalid file type. Only JPG, PNG, GIF, and PDF are allowed.";
                } elseif ($_FILES['payment_proof']['size'] > $maxSize) {
                    $error = "File size exceeds the limit of 5MB.";
                } else {
                    $proofFileName = 'proof_' . $_SESSION['user_id'] . '_' . time() . '.' . pathinfo($_FILES['payment_proof']['name'], PATHINFO_EXTENSION);
                    $uploadDir = '../uploads/payment_proofs/';
                    
                    // Create directory if it doesn't exist
                    if (!file_exists($uploadDir)) {
                        mkdir($uploadDir, 0777, true);
                    }
                    
                    $uploadPath = $uploadDir . $proofFileName;
                    
                    if (!move_uploaded_file($_FILES['payment_proof']['tmp_name'], $uploadPath)) {
                        $error = "Failed to upload payment proof. Please try again.";
                        $proofFileName = null;
                    }
                }
            }
            
            if (empty($error)) {
                // Insert deposit record
                $stmt = $conn->prepare("INSERT INTO deposits (user_id, amount, payment_method, transaction_id, payment_proof, status, created_at) VALUES (?, ?, ?, ?, ?, 'pending', NOW())");
                $stmt->bind_param("idsss", $_SESSION['user_id'], $amount, $paymentMethod, $transactionId, $proofFileName);
                
                if ($stmt->execute()) {
                    $success = "Deposit request submitted successfully. Your account will be credited once the payment is confirmed.";
                    
                    // Log activity
                    logUserActivity($_SESSION['user_id'], "Submitted deposit request of $" . number_format($amount, 2) . " via " . $paymentMethod);
                    
                    // Send notification to admin
                    $adminNotification = "New deposit request of $" . number_format($amount, 2) . " from " . $user['first_name'] . " " . $user['last_name'] . " (" . $user['email'] . ")";
                    addAdminNotification($adminNotification, 'deposit');
                    
                    // Send email notification to user
                    $subject = APP_NAME . " - Deposit Request Received";
                    $message = "
                        <html>
                        <head>
                            <title>Deposit Request Received</title>
                        </head>
                        <body>
                            <h2>Deposit Request Received</h2>
                            <p>Dear " . $user['first_name'] . ",</p>
                            <p>We have received your deposit request of $" . number_format($amount, 2) . " via " . $paymentMethod . ".</p>
                            <p>Your account will be credited once the payment is confirmed.</p>
                            <p>Transaction ID: " . ($transactionId ? $transactionId : 'Not provided') . "</p>
                            <p>If you have any questions, please contact our support team.</p>
                            <p>Thank you for choosing " . APP_NAME . ".</p>
                            <p>Regards,<br>" . APP_NAME . " Team</p>
                        </body>
                        </html>
                    ";
                    sendEmail($user['email'], $subject, $message);
                } else {
                    $error = "Failed to submit deposit request. Please try again.";
                }
            }
        }
    }
}

// Get payment methods
$paymentMethods = getPaymentMethods();

// Get crypto addresses
$cryptoAddresses = [
    'bitcoin' => 'bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh',
    'ethereum' => '0x71C7656EC7ab88b098defB751B7401B5f6d8976F',
    'usdt' => 'TKrJ3aq9Qx5N7zSVCyxTxDcuFd2HEpHFSL',
    'solana' => '5YNmS1R9nNSCDzb5a7mMJ1dwK9uHeAAQmNBZnZoYXU1'
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Deposit - <?php echo APP_NAME; ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <?php if ($theme === 'dark'): ?>
    <link rel="stylesheet" href="../assets/css/dark-theme.css">
    <?php else: ?>
    <link rel="stylesheet" href="../assets/css/light-theme.css">
    <?php endif; ?>
</head>
<body class="<?php echo $theme; ?>-theme">
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <?php include 'includes/sidebar.php'; ?>
            
            <!-- Main Content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
                <!-- Top Navigation Bar -->
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3">
                    <div class="d-flex align-items-center">
                        <?php if (!empty($user['profile_image'])): ?>
                            <img src="../uploads/profile/<?php echo $user['profile_image']; ?>" alt="Profile" class="rounded-circle me-2" style="width: 40px; height: 40px; object-fit: cover;">
                        <?php else: ?>
                            <div class="rounded-circle bg-secondary text-white d-flex align-items-center justify-content-center me-2" style="width: 40px; height: 40px;">
                                <?php echo strtoupper(substr($user['first_name'], 0, 1)); ?>
                            </div>
                        <?php endif; ?>
                        <div>
                            <h6 class="mb-0"><?php echo $user['first_name'] . ' ' . $user['last_name']; ?></h6>
                            <small class="text-muted"><?php echo $user['email']; ?></small>
                        </div>
                    </div>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <a href="account.php" class="btn btn-sm btn-primary me-2">
                            <i class="fas fa-user-circle"></i> Account
                        </a>
                        <a href="deposit.php" class="btn btn-sm btn-success me-2">
                            <i class="fas fa-money-bill-wave"></i> Make Deposit
                        </a>
                        <a href="withdraw.php" class="btn btn-sm btn-warning me-2">
                            <i class="fas fa-money-bill-transfer"></i> Withdraw Funds
                        </a>
                        <a href="contact.php" class="btn btn-sm btn-info me-2">
                            <i class="fas fa-envelope"></i> Mail Us
                        </a>
                        <a href="settings.php" class="btn btn-sm btn-danger">
                            <i class="fas fa-cog"></i> Settings
                        </a>
                    </div>
                </div>
                
                <!-- Market Ticker -->
                <div class="market-ticker mb-4">
                    <div class="ticker-item">
                        <span class="ticker-symbol">Nasdaq 100:</span>
                        <span class="ticker-value">19,445.4</span>
                        <span class="ticker-change positive">+209.8 (+1.09%)</span>
                    </div>
                    <div class="ticker-item">
                        <span class="ticker-symbol">EUR/USD:</span>
                        <span class="ticker-value">1.13640</span>
                        <span class="ticker-change negative">-0.00220 (-0.19%)</span>
                    </div>
                    <div class="ticker-item">
                        <span class="ticker-symbol">BTC/USD:</span>
                        <span class="ticker-value">93,852</span>
                        <span class="ticker-change negative">-810 (-0.86%)</span>
                    </div>
                    <div class="ticker-item">
                        <span class="ticker-symbol">ETH/USD:</span>
                        <span class="ticker-value">1,901.5</span>
                        <span class="ticker-change positive">+15.5 (+0.82%)</span>
                    </div>
                </div>
                
                <?php if (!empty($error)): ?>
                    <div class="alert alert-danger"><?php echo $error; ?></div>
                <?php endif; ?>
                
                <?php if (!empty($success)): ?>
                    <div class="alert alert-success"><?php echo $success; ?></div>
                <?php endif; ?>
                
                <div class="row">
                    <div class="col-md-6 mb-4">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="mb-0">Deposit Using Bitcoin/Ethereum</h5>
                            </div>
                            <div class="card-body">
                                <div class="mb-4">
                                    <h6>Bitcoin Deposit Method</h6>
                                    <p class="text-warning">Please make sure you upload your payment proof for quick payment verification.</p>
                                    <p class="text-info">On confirmation, our system will automatically connect your funds to the value of Dollars. Ensure that you deposit the actual Bitcoin to the address specified on the payment Page.</p>
                                    
                                    <div class="text-center mb-3">
                                        <div class="qr-code-container p-3 d-inline-block border rounded">
                                            <p class="mb-2">Scan Bitcoin QR Code to copy wallet address</p>
                                            <img src="https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=<?php echo $cryptoAddresses['bitcoin']; ?>" alt="Bitcoin QR Code" class="img-fluid mb-2" style="max-width: 200px;">
                                            <div class="input-group mb-2">
                                                <input type="text" class="form-control" value="<?php echo $cryptoAddresses['bitcoin']; ?>" id="btcAddress" readonly>
                                                <button class="btn btn-primary" type="button" onclick="copyToClipboard('btcAddress')">Copy Wallet</button>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <button class="btn btn-primary w-100" data-bs-toggle="modal" data-bs-target="#bitcoinDepositModal">Make Deposit</button>
                                </div>
                                
                                <div class="mb-4">
                                    <h6>Ethereum Deposit Method</h6>
                                    <p class="text-warning">Please make sure you upload your payment proof for quick payment verification.</p>
                                    <p class="text-info">On confirmation, our system will automatically connect your funds to the value of Dollars. Ensure that you deposit the actual Ethereum to the address specified on the payment Page.</p>
                                    
                                    <button class="btn btn-primary w-100" data-bs-toggle="modal" data-bs-target="#ethereumDepositModal">Make Deposit</button>
                                </div>
                                
                                <div class="mb-4">
                                    <h6>USDT Deposit Method</h6>
                                    <p class="text-warning">Please make sure you upload your payment proof for quick payment verification.</p>
                                    <p class="text-info">Our system will automatically connect your funds to the value of Dollars once you make payment. Ensure that you deposit the actual USDT to the address specified on the payment Page.</p>
                                    
                                    <button class="btn btn-primary w-100" data-bs-toggle="modal" data-bs-target="#usdtDepositModal">Make Deposit</button>
                                </div>
                                
                                <div class="mb-4">
                                    <h6>Solana Deposit Method</h6>
                                    <p class="text-warning">Please make sure you upload your payment proof for quick payment verification.</p>
                                    <p class="text-info">Our system will automatically connect your funds to the value of Dollars once you make payment. Ensure that you deposit the actual Solana to the address specified on the payment Page.</p>
                                    
                                    <button class="btn btn-primary w-100" data-bs-toggle="modal" data-bs-target="#solanaDepositModal">Make Deposit</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-6 mb-4">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="mb-0">Other Deposit Options</h5>
                            </div>
                            <div class="card-body">
                                <h6>Request other available Deposit Method</h6>
                                <p class="text-info">Once payment is made using this method you are to send your payment proof to our support email.</p>
                                <p class="text-warning">Once requested, you will receive the payment details via our support email.</p>
                                
                                <form method="POST" action="" enctype="multipart/form-data" class="mt-4">
                                    <div class="mb-3">
                                        <label for="amount" class="form-label">Amount: $</label>
                                        <input type="number" class="form-control" id="amount" name="amount" min="100" step="0.01" required>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="payment_method" class="form-label">Payment Method:</label>
                                        <select class="form-select" id="payment_method" name="payment_method" required>
                                            <option value="">Select Payment Method</option>
                                            <?php foreach ($paymentMethods as $method): ?>
                                                <option value="<?php echo $method['name']; ?>"><?php echo $method['name']; ?></option>
                                            <?php endforeach; ?>
                                            <option value="Bank Transfer">Bank Transfer</option>
                                            <option value="Credit Card">Credit Card</option>
                                            <option value="PayPal">PayPal</option>
                                        </select>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="transaction_id" class="form-label">Transaction ID (Optional):</label>
                                        <input type="text" class="form-control" id="transaction_id" name="transaction_id">
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="payment_proof" class="form-label">Upload Payment Proof (Optional):</label>
                                        <input type="file" class="form-control" id="payment_proof" name="payment_proof">
                                        <small class="text-muted">Accepted formats: JPG, PNG, GIF, PDF. Max size: 5MB</small>
                                    </div>
                                    
                                    <button type="submit" name="submit_deposit" class="btn btn-primary w-100">Proceed</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>
    
    <!-- Bitcoin Deposit Modal -->
    <div class="modal fade" id="bitcoinDepositModal" tabindex="-1" aria-labelledby="bitcoinDepositModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="bitcoinDepositModalLabel">Bitcoin Deposit</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="text-center mb-3">
                        <p>Scan Bitcoin QR Code to copy wallet address</p>
                        <img src="https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=<?php echo $cryptoAddresses['bitcoin']; ?>" alt="Bitcoin QR Code" class="img-fluid mb-2" style="max-width: 200px;">
                        <div class="input-group mb-2">
                            <input type="text" class="form-control" value="<?php echo $cryptoAddresses['bitcoin']; ?>" id="btcAddressModal" readonly>
                            <button class="btn btn-primary" type="button" onclick="copyToClipboard('btcAddressModal')">Copy Wallet</button>
                        </div>
                    </div>
                    
                    <p class="text-warning">If your payment was successful, Please upload payment proof below.</p>
                    
                    <form method="POST" action="" enctype="multipart/form-data">
                        <input type="hidden" name="payment_method" value="Bitcoin">
                        
                        <div class="mb-3">
                            <label for="btc_amount" class="form-label">Amount: $</label>
                            <input type="number" class="form-control" id="btc_amount" name="amount" min="100" step="0.01" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="btc_transaction_id" class="form-label">Transaction ID:</label>
                            <input type="text" class="form-control" id="btc_transaction_id" name="transaction_id">
                        </div>
                        
                        <div class="mb-3">
                            <label for="btc_payment_proof" class="form-label">Upload Payment Proof:</label>
                            <input type="file" class="form-control" id="btc_payment_proof" name="payment_proof" required>
                        </div>
                        
                        <div class="d-flex justify-content-between">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" name="submit_deposit" class="btn btn-primary">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Ethereum Deposit Modal -->
    <div class="modal fade" id="ethereumDepositModal" tabindex="-1" aria-labelledby="ethereumDepositModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="ethereumDepositModalLabel">Ethereum Deposit</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="text-center mb-3">
                        <p>Scan Ethereum QR Code to copy wallet address</p>
                        <img src="https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=<?php echo $cryptoAddresses['ethereum']; ?>" alt="Ethereum QR Code" class="img-fluid mb-2" style="max-width: 200px;">
                        <div class="input-group mb-2">
                            <input type="text" class="form-control" value="<?php echo $cryptoAddresses['ethereum']; ?>" id="ethAddressModal" readonly>
                            <button class="btn btn-primary" type="button" onclick="copyToClipboard('ethAddressModal')">Copy Wallet</button>
                        </div>
                    </div>
                    
                    <p class="text-warning">If your payment was successful, Please upload payment proof below.</p>
                    
                    <form method="POST" action="" enctype="multipart/form-data">
                        <input type="hidden" name="payment_method" value="Ethereum">
                        
                        <div class="mb-3">
                            <label for="eth_amount" class="form-label">Amount: $</label>
                            <input type="number" class="form-control" id="eth_amount" name="amount" min="100" step="0.01" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="eth_transaction_id" class="form-label">Transaction ID:</label>
                            <input type="text" class="form-control" id="eth_transaction_id" name="transaction_id">
                        </div>
                        
                        <div class="mb-3">
                            <label for="eth_payment_proof" class="form-label">Upload Payment Proof:</label>
                            <input type="file" class="form-control" id="eth_payment_proof" name="payment_proof" required>
                        </div>
                        
                        <div class="d-flex justify-content-between">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" name="submit_deposit" class="btn btn-primary">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
    <!-- USDT Deposit Modal -->
    <div class="modal fade" id="usdtDepositModal" tabindex="-1" aria-labelledby="usdtDepositModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="usdtDepositModalLabel">USDT Deposit</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <!-- Modal content similar to Bitcoin and Ethereum -->
                    <div class="text-center mb-3">
                        <p>Scan USDT QR Code to copy wallet address</p>
                        <img src="https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=<?php echo $cryptoAddresses['usdt']; ?>" alt="USDT QR Code" class="img-fluid mb-2" style="max-width: 200px;">
                        <div class="input-group mb-2">
                            <input type="text" class="form-control" value="<?php echo $cryptoAddresses['usdt']; ?>" id="usdtAddressModal" readonly>
                            <button class="btn btn-primary" type="button" onclick="copyToClipboard('usdtAddressModal')">Copy Wallet</button>
                        </div>
                    </div>
                    
                    <p class="text-warning">If your payment was successful, Please upload payment proof below.</p>
                    
                    <form method="POST" action="" enctype="multipart/form-data">
                        <input type="hidden" name="payment_method" value="USDT">
                        
                        <div class="mb-3">
                            <label for="usdt_amount" class="form-label">Amount: $</label>
                            <input type="number" class="form-control" id="usdt_amount" name="amount" min="100" step="0.01" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="usdt_transaction_id" class="form-label">Transaction ID:</label>
                            <input type="text" class="form-control" id="usdt_transaction_id" name="transaction_id">
                        </div>
                        
                        <div class="mb-3">
                            <label for="usdt_payment_proof" class="form-label">Upload Payment Proof:</label>
                            <input type="file" class="form-control" id="usdt_payment_proof" name="payment_proof" required>
                        </div>
                        
                        <div class="d-flex justify-content-between">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" name="submit_deposit" class="btn btn-primary">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Solana Deposit Modal -->
    <div class="modal fade" id="solanaDepositModal" tabindex="-1" aria-labelledby="solanaDepositModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="solanaDepositModalLabel">Solana Deposit</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <!-- Modal content similar to Bitcoin and Ethereum -->
                    <div class="text-center mb-3">
                        <p>Scan Solana QR Code to copy wallet address</p>
                        <img src="https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=<?php echo $cryptoAddresses['solana']; ?>" alt="Solana QR Code" class="img-fluid mb-2" style="max-width: 200px;">
                        <div class="input-group mb-2">
                            <input type="text" class="form-control" value="<?php echo $cryptoAddresses['solana']; ?>" id="solanaAddressModal" readonly>
                            <button class="btn btn-primary" type="button" onclick="copyToClipboard('solanaAddressModal')">Copy Wallet</button>
                        </div>
                    </div>
                    
                    <p class="text-warning">If your payment was successful, Please upload payment proof below.</p>
                    
                    <form method="POST" action="" enctype="multipart/form-data">
                        <input type="hidden" name="payment_method" value="Solana">
                        
                        <div class="mb-3">
                            <label for="sol_amount" class="form-label">Amount: $</label>
                            <input type="number" class="form-control" id="sol_amount" name="amount" min="100" step="0.01" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="sol_transaction_id" class="form-label">Transaction ID:</label>
                            <input type="text" class="form-control" id="sol_transaction_id" name="transaction_id">
                        </div>
                        
                        <div class="mb-3">
                            <label for="sol_payment_proof" class="form-label">Upload Payment Proof:</label>
                            <input type="file" class="form-control" id="sol_payment_proof" name="payment_proof" required>
                        </div>
                        
                        <div class="d-flex justify-content-between">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" name="submit_deposit" class="btn btn-primary">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function copyToClipboard(elementId) {
            var copyText = document.getElementById(elementId);
            copyText.select();
            copyText.setSelectionRange(0, 99999);
            document.execCommand("copy");
            alert("Copied to clipboard: " + copyText.value);
        }
    </script>
</body>
</html>
