<?php
// Generate unique loan ID
function generateLoanId() {
    $prefix = 'LN';
    $timestamp = time();
    $random = mt_rand(1000, 9999);
    return $prefix . $timestamp . $random;
}

// Get all loan plans
function getAllLoanPlans() {
    global $conn;
    
    $stmt = $conn->prepare("SELECT * FROM loan_plans ORDER BY min_amount ASC");
    $stmt->execute();
    $result = $stmt->get_result();
    
    $plans = [];
    while ($row = $result->fetch_assoc()) {
        $plans[] = $row;
    }
    
    return $plans;
}

// Get active loan plans
function getLoanPlans() {
    global $conn;
    
    $stmt = $conn->prepare("SELECT * FROM loan_plans WHERE status = 'active' ORDER BY min_amount ASC");
    $stmt->execute();
    $result = $stmt->get_result();
    
    $plans = [];
    while ($row = $result->fetch_assoc()) {
        $plans[] = $row;
    }
    
    return $plans;
}

// Get loan plan by ID
function getLoanPlanById($planId) {
    global $conn;
    
    $stmt = $conn->prepare("SELECT * FROM loan_plans WHERE id = ?");
    $stmt->bind_param("i", $planId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        return $result->fetch_assoc();
    }
    
    return null;
}

// Apply for loan
function applyForLoan($userId, $planId, $amount, $interestAmount, $totalRepayment, $processingFee, $duration, $purpose, $repaymentSource, $loanId) {
    global $conn;
    
    $stmt = $conn->prepare("INSERT INTO loans (user_id, plan_id, loan_id, amount, interest_amount, total_repayment, processing_fee, duration, purpose, repayment_source) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("iisddddiss", $userId, $planId, $loanId, $amount, $interestAmount, $totalRepayment, $processingFee, $duration, $purpose, $repaymentSource);
    
    return $stmt->execute();
}

// Get user's loans
function getUserLoans($userId) {
    global $conn;
    
    $stmt = $conn->prepare("SELECT l.*, p.name as plan_name FROM loans l JOIN loan_plans p ON l.plan_id = p.id WHERE l.user_id = ? ORDER BY l.created_at DESC");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $loans = [];
    while ($row = $result->fetch_assoc()) {
        $loans[] = $row;
    }
    
    return $loans;
}

// Get all loans
function getAllLoans() {
    global $conn;
    
    $stmt = $conn->prepare("SELECT l.*, u.first_name, u.last_name, u.email, p.name as plan_name FROM loans l JOIN users u ON l.user_id = u.id JOIN loan_plans p ON l.plan_id = p.id ORDER BY l.created_at DESC");
    $stmt->execute();
    $result = $stmt->get_result();
    
    $loans = [];
    while ($row = $result->fetch_assoc()) {
        $loans[] = $row;
    }
    
    return $loans;
}

// Get loan by ID
function getLoanById($loanId) {
    global $conn;
    
    $stmt = $conn->prepare("SELECT * FROM loans WHERE id = ?");
    $stmt->bind_param("i", $loanId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        return $result->fetch_assoc();
    }
    
    return null;
}

// Approve loan
function approveLoan($loanId, $dueDate) {
    global $conn;
    
    $stmt = $conn->prepare("UPDATE loans SET status = 'approved', approved_at = NOW(), due_date = ? WHERE id = ?");
    $stmt->bind_param("si", $dueDate, $loanId);
    
    return $stmt->execute();
}

// Reject loan
function rejectLoan($loanId) {
    global $conn;
    
    $stmt = $conn->prepare("UPDATE loans SET status = 'rejected' WHERE id = ?");
    $stmt->bind_param("i", $loanId);
    
    return $stmt->execute();
}

// Update loan status
function updateLoanStatus($loanId, $status) {
    global $conn;
    
    $stmt = $conn->prepare("UPDATE loans SET status = ? WHERE id = ?");
    $stmt->bind_param("si", $status, $loanId);
    
    return $stmt->execute();
}

// Record loan payment
function recordLoanPayment($loanId, $userId, $amount, $paymentMethod, $transactionId, $proofImage, $notes) {
    global $conn;
    
    $stmt = $conn->prepare("INSERT INTO loan_payments (loan_id, user_id, amount, payment_method, transaction_id, proof_image, notes) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("iidssss", $loanId, $userId, $amount, $paymentMethod, $transactionId, $proofImage, $notes);
    
    return $stmt->execute();
}

// Get loan repayments
function getLoanRepayments($loanId) {
    global $conn;
    
    $stmt = $conn->prepare("SELECT * FROM loan_payments WHERE loan_id = ? ORDER BY created_at DESC");
    $stmt->bind_param("i", $loanId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $repayments = [];
    while ($row = $result->fetch_assoc()) {
        $repayments[] = $row;
    }
    
    return $repayments;
}

// Update loan amount paid
function updateLoanAmountPaid($loanId, $amount) {
    global $conn;
    
    $stmt = $conn->prepare("UPDATE loans SET amount_paid = amount_paid + ? WHERE id = ?");
    $stmt->bind_param("di", $amount, $loanId);
    
    return $stmt->execute();
}

// Confirm loan payment
function confirmLoanPayment($paymentId) {
    global $conn;
    
    $stmt = $conn->prepare("UPDATE loan_payments SET status = 'confirmed', confirmed_at = NOW() WHERE id = ?");
    $stmt->bind_param("i", $paymentId);
    
    return $stmt->execute();
}

// Reject loan payment
function rejectLoanPayment($paymentId) {
    global $conn;
    
    $stmt = $conn->prepare("UPDATE loan_payments SET status = 'rejected' WHERE id = ?");
    $stmt->bind_param("i", $paymentId);
    
    return $stmt->execute();
}

// Update loan comment
function updateLoanComment($loanId, $comment) {
    global $conn;
    
    $stmt = $conn->prepare("UPDATE loans SET admin_comment = ? WHERE id = ?");
    $stmt->bind_param("si", $comment, $loanId);
    
    return $stmt->execute();
}

// Add loan plan
function addLoanPlan($name, $minAmount, $maxAmount, $interestRate, $duration, $processingFee, $status) {
    global $conn;
    
    $stmt = $conn->prepare("INSERT INTO loan_plans (name, min_amount, max_amount, interest_rate, duration, processing_fee, status) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sdddiis", $name, $minAmount, $maxAmount, $interestRate, $duration, $processingFee, $status);
    
    return $stmt->execute();
}

// Update loan plan
function updateLoanPlan($id, $name, $minAmount, $maxAmount, $interestRate, $duration, $processingFee, $status) {
    global $conn;
    
    $stmt = $conn->prepare("UPDATE loan_plans SET name = ?, min_amount = ?, max_amount = ?, interest_rate = ?, duration = ?, processing_fee = ?, status = ? WHERE id = ?");
    $stmt->bind_param("sdddiisi", $name, $minAmount, $maxAmount, $interestRate, $duration, $processingFee, $status, $id);
    
    return $stmt->execute();
}

// Delete loan plan
function deleteLoanPlan($id) {
    global $conn;
    
    $stmt = $conn->prepare("DELETE FROM loan_plans WHERE id = ?");
    $stmt->bind_param("i", $id);
    
    return $stmt->execute();
}

// Toggle loan plan status
function toggleLoanPlanStatus($id, $status) {
    global $conn;
    
    $stmt = $conn->prepare("UPDATE loan_plans SET status = ? WHERE id = ?");
    $stmt->bind_param("si", $status, $id);
    
    return $stmt->execute();
}

// Send loan application notification
function sendLoanApplicationNotification($user, $loanDetails) {
    $subject = APP_NAME . " - Loan Application Received";
    
    $message = "
        <html>
        <head>
            <title>Loan Application Notification</title>
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                .header { background-color: #7000ff; color: white; padding: 10px 20px; text-align: center; }
                .content { padding: 20px; border: 1px solid #ddd; }
                .footer { font-size: 12px; text-align: center; margin-top: 20px; color: #777; }
                .details { margin: 20px 0; }
                .details table { width: 100%; border-collapse: collapse; }
                .details th, .details td { padding: 10px; border-bottom: 1px solid #ddd; text-align: left; }
            </style>
        </head>
        <body>
            <div class='container'>
                <div class='header'>
                    <h2>" . APP_NAME . " - Loan Application</h2>
                </div>
                <div class='content'>
                    <p>Dear " . $user['first_name'] . " " . $user['last_name'] . ",</p>
                    
                    <p>Your loan application has been received and is currently under review. We will notify you once a decision has been made.</p>
                    
                    <div class='details'>
                        <table>
                            <tr>
                                <th>Loan ID:</th>
                                <td>" . $loanDetails['loan_id'] . "</td>
                            </tr>
                            <tr>
                                <th>Plan:</th>
                                <td>" . $loanDetails['plan_name'] . "</td>
                            </tr>
                            <tr>
                                <th>Amount:</th>
                                <td>$" . number_format($loanDetails['amount'], 2) . "</td>
                            </tr>
                            <tr>
                                <th>Interest Amount:</th>
                                <td>$" . number_format($loanDetails['interest_amount'], 2) . "</td>
                            </tr>
                            <tr>
                                <th>Total Repayment:</th>
                                <td>$" . number_format($loanDetails['total_repayment'], 2) . "</td>
                            </tr>
                            <tr>
                                <th>Processing Fee:</th>
                                <td>$" . number_format($loanDetails['processing_fee'], 2) . "</td>
                            </tr>
                            <tr>
                                <th>Duration:</th>
                                <td>" . $loanDetails['duration'] . " days</td>
                            </tr>
                            <tr>
                                <th>Purpose:</th>
                                <td>" . $loanDetails['purpose'] . "</td>
                            </tr>
                            <tr>
                                <th>Application Date:</th>
                                <td>" . date('F j, Y, g:i a', strtotime($loanDetails['created_at'])) . "</td>
                            </tr>
                        </table>
                    </div>
                    
                    <p>If you have any questions, please contact our support team.</p>
                    
                    <p>Thank you for choosing " . APP_NAME . ".</p>
                </div>
                <div class='footer'>
                    <p>© " . date('Y') . " " . APP_NAME . ". All rights reserved.</p>
                    <p>This is an automated email, please do not reply.</p>
                </div>
            </div>
        </body>
        </html>
    ";
    
    return sendEmail($user['email'], $subject, $message);
}

// Send loan approval notification
function sendLoanApprovalNotification($user, $loan) {
    $subject = APP_NAME . " - Loan Application Approved";
    
    $message = "
        <html>
        <head>
            <title>Loan Approval Notification</title>
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                .header { background-color: #28a745; color: white; padding: 10px 20px; text-align: center; }
                .content { padding: 20px; border: 1px solid #ddd; }
                .footer { font-size: 12px; text-align: center; margin-top: 20px; color: #777; }
                .details { margin: 20px 0; }
                .details table { width: 100%; border-collapse: collapse; }
                .details th, .details td { padding: 10px; border-bottom: 1px solid #ddd; text-align: left; }
                .highlight { background-color: #f8f9fa; padding: 15px; margin: 20px 0; border-radius: 5px; }
            </style>
        </head>
        <body>
            <div class='container'>
                <div class='header'>
                    <h2>" . APP_NAME . " - Loan Approved</h2>
                </div>
                <div class='content'>
                    <p>Dear " . $user['first_name'] . " " . $user['last_name'] . ",</p>
                    
                    <p>Congratulations! Your loan application has been approved. The loan amount has been added to your account balance.</p>
                    
                    <div class='highlight'>
                        <p><strong>Loan ID:</strong> " . $loan['loan_id'] . "</p>
                        <p><strong>Amount:</strong> $" . number_format($loan['amount'], 2) . "</p>
                        <p><strong>Due Date:</strong> " . date('F j, Y', strtotime($loan['due_date'])) . "</p>
                        <p><strong>Total Repayment:</strong> $" . number_format($loan['total_repayment'], 2) . "</p>
                    </div>
                    
                    <p>Please ensure that you repay the loan on or before the due date to avoid any penalties or negative impact on your credit score.</p>
                    
                    <p>You can make repayments through your account dashboard.</p>
                    
                    <p>If you have any questions, please contact our support team.</p>
                    
                    <p>Thank you for choosing " . APP_NAME . ".</p>
                </div>
                <div class='footer'>
                    <p>© " . date('Y') . " " . APP_NAME . ". All rights reserved.</p>
                    <p>This is an automated email, please do not reply.</p>
                </div>
            </div>
        </body>
        </html>
    ";
    
    return sendEmail($user['email'], $subject, $message);
}

// Send loan rejection notification
function sendLoanRejectionNotification($user, $loan) {
    $subject = APP_NAME . " - Loan Application Rejected";
    
    $message = "
        <html>
        <head>
            <title>Loan Rejection Notification</title>
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                .header { background-color: #dc3545; color: white; padding: 10px 20px; text-align: center; }
                .content { padding: 20px; border: 1px solid #ddd; }
                .footer { font-size: 12px; text-align: center; margin-top: 20px; color: #777; }
            </style>
        </head>
        <body>
            <div class='container'>
                <div class='header'>
                    <h2>" . APP_NAME . " - Loan Rejected</h2>
                </div>
                <div class='content'>
                    <p>Dear " . $user['first_name'] . " " . $user['last_name'] . ",</p>
                    
                    <p>We regret to inform you that your loan application (ID: " . $loan['loan_id'] . ") has been rejected.</p>
                    
                    <p>There could be several reasons for this decision, including but not limited to:</p>
                    <ul>
                        <li>Insufficient account history</li>
                        <li>Credit risk assessment</li>
                        <li>Incomplete or incorrect information provided</li>
                        <li>Current market conditions</li>
                    </ul>
                    
                    <p>You are welcome to apply again after 30 days or contact our support team for more information about this decision.</p>
                    
                    <p>Thank you for choosing " . APP_NAME . ".</p>
                </div>
                <div class='footer'>
                    <p>© " . date('Y') . " " . APP_NAME . ". All rights reserved.</p>
                    <p>This is an automated email, please do not reply.</p>
                </div>
            </div>
        </body>
        </html>
    ";
    
    return sendEmail($user['email'], $subject, $message);
}

// Send loan payment notification
function sendLoanPaymentNotification($user, $paymentDetails) {
    $subject = APP_NAME . " - Loan Payment Received";
    
    $message = "
        <html>
        <head>
            <title>Loan Payment Notification</title>
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                .header { background-color: #7000ff; color: white; padding: 10px 20px; text-align: center; }
                .content { padding: 20px; border: 1px solid #ddd; }
                .footer { font-size: 12px; text-align: center; margin-top: 20px; color: #777; }
                .details { margin: 20px 0; }
                .details table { width: 100%; border-collapse: collapse; }
                .details th, .details td { padding: 10px; border-bottom: 1px solid #ddd; text-align: left; }
            </style>
        </head>
        <body>
            <div class='container'>
                <div class='header'>
                    <h2>" . APP_NAME . " - Loan Payment</h2>
                </div>
                <div class='content'>
                    <p>Dear " . $user['first_name'] . " " . $user['last_name'] . ",</p>
                    
                    <p>We have received your loan payment and it is currently pending confirmation. We will notify you once the payment has been confirmed.</p>
                    
                    <div class='details'>
                        <table>
                            <tr>
                                <th>Loan ID:</th>
                                <td>" . $paymentDetails['loan_id'] . "</td>
                            </tr>
                            <tr>
                                <th>Amount:</th>
                                <td>$" . number_format($paymentDetails['amount'], 2) . "</td>
                            </tr>
                            <tr>
                                <th>Payment Method:</th>
                                <td>" . $paymentDetails['payment_method'] . "</td>
                            </tr>
                            <tr>
                                <th>Transaction ID:</th>
                                <td>" . $paymentDetails['transaction_id'] . "</td>
                            </tr>
                            <tr>
                                <th>Date:</th>
                                <td>" . date('F j, Y, g:i a', strtotime($paymentDetails['created_at'])) . "</td>
                            </tr>
                        </table>
                    </div>
                    
                    <p>If you have any questions, please contact our support team.</p>
                    
                    <p>Thank you for choosing " . APP_NAME . ".</p>
                </div>
                <div class='footer'>
                    <p>© " . date('Y') . " " . APP_NAME . ". All rights reserved.</p>
                    <p>This is an automated email, please do not reply.</p>
                </div>
            </div>
        </body>
        </html>
    ";
    
    return sendEmail($user['email'], $subject, $message);
}
?>
