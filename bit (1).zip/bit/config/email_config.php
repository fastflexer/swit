<?php
// Mail Configuration
return [
    'smtp_host' => 'mail.jetfxgrowth.online',
    'smtp_port' => 587,
    'smtp_username' => 'bitreply@jetfxgrowth.online',
    'smtp_password' => '10@Jetfxgrowth10@',
    'smtp_encryption' => 'tls',
    'from_email' => 'bitreply@jetfxgrowth.online',
    'from_name' => 'JetFx Growth'
];