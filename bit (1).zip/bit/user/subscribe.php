<?php
require_once '../config/config.php';
require_once '../includes/auth_check.php';
require_once '../includes/functions.php';

// Get user information
$userId = $_SESSION['user_id'];
$user = getUserById($userId);

// Get subscription plans
$stmt = $conn->prepare("SELECT * FROM subscription_plans WHERE type = 'investment' ORDER BY min_amount ASC");
$stmt->execute();
$plans = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Process subscription
$message = '';
$messageType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['plan_id'], $_POST['amount'])) {
    $planId = intval($_POST['plan_id']);
    $amount = floatval($_POST['amount']);
    
    // Get plan details
    $stmt = $conn->prepare("SELECT * FROM subscription_plans WHERE id = ?");
    $stmt->bind_param("i", $planId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        $message = 'Invalid plan selected.';
        $messageType = 'danger';
    } else {
        $plan = $result->fetch_assoc();
        
        // Validate amount
        if ($amount < $plan['min_amount']) {
            $message = 'Amount must be at least ' . $plan['min_amount'] . '.';
            $messageType = 'danger';
        } elseif ($plan['max_amount'] > 0 && $amount > $plan['max_amount']) {
            $message = 'Amount cannot exceed ' . $plan['max_amount'] . '.';
            $messageType = 'danger';
        } elseif ($amount > $user['balance']) {
            $message = 'Insufficient balance.';
            $messageType = 'danger';
        } else {
            // Start transaction
            $conn->begin_transaction();
            
            try {
                // Deduct amount from user balance
                $stmt = $conn->prepare("UPDATE users SET balance = balance - ? WHERE id = ?");
                $stmt->bind_param("di", $amount, $userId);
                $stmt->execute();
                
                // Calculate end date based on duration
                $endDate = date('Y-m-d H:i:s', strtotime('+' . $plan['duration'] . ' days'));
                
                // Insert subscription
                $stmt = $conn->prepare("INSERT INTO subscriptions (user_id, plan_id, amount, roi_rate, start_date, end_date, status, created_at) VALUES (?, ?, ?, ?, NOW(), ?, 'active', NOW())");
                $stmt->bind_param("iidds", $userId, $planId, $amount, $plan['roi_rate'], $endDate);
                $stmt->execute();
                
                // Commit transaction
                $conn->commit();
                
                $message = 'Subscription successful! Your investment plan is now active.';
                $messageType = 'success';
                
                // Redirect to investments page after a short delay
                header("Refresh: 2; URL=investments.php");
            } catch (Exception $e) {
                // Rollback transaction on error
                $conn->rollback();
                $message = 'Error processing subscription: ' . $e->getMessage();
                $messageType = 'danger';
            }
        }
    }
}

// Get user's active subscriptions
$stmt = $conn->prepare("SELECT s.*, p.name as plan_name, p.roi_rate, p.duration FROM subscriptions s JOIN subscription_plans p ON s.plan_id = p.id WHERE s.user_id = ? AND s.status = 'active' ORDER BY s.created_at DESC");
$stmt->bind_param("i", $userId);
$stmt->execute();
$activeSubscriptions = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Subscribe - JetFx Growth</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        .plan-card {
            border-radius: 10px;
            overflow: hidden;
            transition: transform 0.3s ease;
            height: 100%;
        }
        .plan-card:hover {
            transform: translateY(-5px);
        }
        .plan-header {
            padding: 20px;
            text-align: center;
            color: white;
        }
        .plan-price {
            font-size: 2rem;
            font-weight: bold;
        }
        .plan-features {
            padding: 20px;
        }
        .plan-feature {
            margin-bottom: 10px;
        }
        .starter-plan {
            background-color: #3498db;
        }
        .basic-plan {
            background-color: #2ecc71;
        }
        .premium-plan {
            background-color: #9b59b6;
        }
        .elite-plan {
            background-color: #e74c3c;
        }
        .amount-input {
            border: 1px solid #ced4da;
            border-radius: 5px;
            padding: 8px 12px;
            width: 100%;
            margin-bottom: 10px;
        }
        @media (max-width: 768px) {
            .plan-cards {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <?php include 'includes/sidebar.php'; ?>
            
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Investment Plans</h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <div class="btn-group me-2">
                            <a href="investments.php" class="btn btn-sm btn-outline-secondary">My Investments</a>
                        </div>
                    </div>
                </div>
                
                <?php if (!empty($message)): ?>
                    <div class="alert alert-<?php echo $messageType; ?> alert-dismissible fade show" role="alert">
                        <?php echo $message; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>
                
                <div class="alert alert-info">
                    <strong>Your Balance:</strong> $<?php echo number_format($user['balance'], 2); ?>
                </div>
                
                <div class="row row-cols-1 row-cols-md-2 row-cols-xl-4 g-4 plan-cards">
                    <?php 
                    $planClasses = ['starter-plan', 'basic-plan', 'premium-plan', 'elite-plan'];
                    $planIndex = 0;
                    
                    foreach ($plans as $plan): 
                        $planClass = $planClasses[$planIndex % count($planClasses)];
                        $planIndex++;
                    ?>
                        <div class="col">
                            <div class="card plan-card h-100">
                                <div class="plan-header <?php echo $planClass; ?>">
                                    <h3><?php echo htmlspecialchars($plan['name']); ?></h3>
                                    <div class="plan-price"><?php echo $plan['roi_rate']; ?>% ROI DAILY</div>
                                    <p><?php echo $plan['duration']; ?> Days</p>
                                </div>
                                <div class="card-body plan-features">
                                    <div class="plan-feature">
                                        <strong>Minimum Amount:</strong> $<?php echo number_format($plan['min_amount'], 2); ?>
                                    </div>
                                    <?php if ($plan['max_amount'] > 0): ?>
                                        <div class="plan-feature">
                                            <strong>Maximum Amount:</strong> $<?php echo number_format($plan['max_amount'], 2); ?>
                                        </div>
                                    <?php else: ?>
                                        <div class="plan-feature">
                                            <strong>Maximum Amount:</strong> Unlimited
                                        </div>
                                    <?php endif; ?>
                                    
                                    <hr>
                                    
                                    <form method="POST" class="subscribe-form">
                                        <input type="hidden" name="plan_id" value="<?php echo $plan['id']; ?>">
                                        <div class="mb-3">
                                            <label for="amount-<?php echo $plan['id']; ?>" class="form-label">Investment Amount ($)</label>
                                            <input type="number" id="amount-<?php echo $plan['id']; ?>" name="amount" class="amount-input" min="<?php echo $plan['min_amount']; ?>" <?php echo $plan['max_amount'] > 0 ? 'max="' . $plan['max_amount'] . '"' : ''; ?> step="0.01" required>
                                        </div>
                                        <button type="submit" class="btn btn-primary w-100">Join Plan</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
                
                <?php if (empty($plans)): ?>
                    <div class="alert alert-info mt-4">No investment plans available at the moment.</div>
                <?php endif; ?>
                
                <?php if (!empty($activeSubscriptions)): ?>
                    <div class="mt-5">
                        <h3>Your Active Investments</h3>
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th>Plan</th>
                                        <th>Amount</th>
                                        <th>ROI Rate</th>
                                        <th>Start Date</th>
                                        <th>End Date</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($activeSubscriptions as $subscription): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($subscription['plan_name']); ?></td>
                                            <td>$<?php echo number_format($subscription['amount'], 2); ?></td>
                                            <td><?php echo $subscription['roi_rate']; ?>% Daily</td>
                                            <td><?php echo date('M j, Y', strtotime($subscription['start_date'])); ?></td>
                                            <td><?php echo date('M j, Y', strtotime($subscription['end_date'])); ?></td>
                                            <td>
                                                <span class="badge bg-success">Active</span>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                <?php endif; ?>
            </main>
        </div>
    </div>
    
    <!-- Confirmation Modal -->
    <div class="modal fade" id="confirmModal" tabindex="-1" aria-labelledby="confirmModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="confirmModalLabel">Are you sure?</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p>Do you want to join this plan?</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">No, Cancel</button>
                    <button type="button" class="btn btn-primary" id="confirmSubscribe">Yes, Join</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const subscribeForms = document.querySelectorAll('.subscribe-form');
            const confirmModal = new bootstrap.Modal(document.getElementById('confirmModal'));
            let activeForm = null;
            
            subscribeForms.forEach(form => {
                form.addEventListener('submit', function(e) {
                    e.preventDefault();
                    activeForm = this;
                    confirmModal.show();
                });
            });
            
            document.getElementById('confirmSubscribe').addEventListener('click', function() {
                if (activeForm) {
                    confirmModal.hide();
                    activeForm.submit();
                }
            });
        });
    </script>
</body>
</html>
