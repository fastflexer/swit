<?php
require_once '../config/config.php';
require_once '../includes/auth_check.php';
require_once '../includes/functions.php';

// Get user information
$userId = $_SESSION['user_id'];
$user = getUserById($userId);

// Get user's NFTs
$stmt = $conn->prepare("SELECT * FROM nfts WHERE owner_id = ? ORDER BY created_at DESC");
$stmt->bind_param("i", $userId);
$stmt->execute();
$myNfts = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Get user's created NFTs
$stmt = $conn->prepare("SELECT * FROM nfts WHERE creator_id = ? AND owner_id != ? ORDER BY created_at DESC");
$stmt->bind_param("ii", $userId, $userId);
$stmt->execute();
$createdNfts = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My NFTs - JetFx Growth</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        .nft-card {
            border-radius: 10px;
            overflow: hidden;
            transition: transform 0.3s ease;
            height: 100%;
        }
        .nft-card:hover {
            transform: translateY(-5px);
        }
        .nft-image {
            width: 100%;
            height: 200px;
            object-fit: cover;
        }
        .nav-tabs .nav-link {
            border: none;
            color: var(--secondary-color);
        }
        .nav-tabs .nav-link.active {
            color: var(--primary-color);
            border-bottom: 2px solid var(--primary-color);
            background-color: transparent;
        }
        @media (max-width: 768px) {
            .nft-image {
                height: 150px;
            }
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <?php include 'includes/sidebar.php'; ?>
            
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">My NFTs</h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <div class="btn-group me-2">
                            <a href="create_nft.php" class="btn btn-sm btn-primary">Create NFT</a>
                            <a href="nfts.php" class="btn btn-sm btn-outline-secondary">NFT Marketplace</a>
                        </div>
                    </div>
                </div>
                
                <ul class="nav nav-tabs mb-4">
                    <li class="nav-item">
                        <a class="nav-link active" id="owned-tab" data-bs-toggle="tab" href="#owned">Owned NFTs</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="created-tab" data-bs-toggle="tab" href="#created">Created NFTs</a>
                    </li>
                </ul>
                
                <div class="tab-content">
                    <div class="tab-pane fade show active" id="owned">
                        <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 row-cols-xl-4 g-4">
                            <?php foreach ($myNfts as $nft): ?>
                                <div class="col">
                                    <div class="card nft-card h-100">
                                        <img src="<?php echo '../' . htmlspecialchars($nft['image_url']); ?>" class="nft-image" alt="<?php echo htmlspecialchars($nft['name']); ?>">
                                        <div class="card-body">
                                            <h5 class="card-title"><?php echo htmlspecialchars($nft['name']); ?></h5>
                                            <p class="card-text text-muted">Price: <?php echo htmlspecialchars($nft['price']); ?> ETH</p>
                                        </div>
                                        <div class="card-footer">
                                            <a href="nft_details.php?id=<?php echo $nft['id']; ?>" class="btn btn-primary w-100">View Details</a>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                            
                            <?php if (empty($myNfts)): ?>
                                <div class="col-12">
                                    <div class="alert alert-info">
                                        You don't own any NFTs yet. <a href="nfts.php">Browse the marketplace</a> to find NFTs to purchase.
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="tab-pane fade" id="created">
                        <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 row-cols-xl-4 g-4">
                            <?php foreach ($createdNfts as $nft): ?>
                                <div class="col">
                                    <div class="card nft-card h-100">
                                        <img src="<?php echo '../' . htmlspecialchars($nft['image_url']); ?>" class="nft-image" alt="<?php echo htmlspecialchars($nft['name']); ?>">
                                        <div class="card-body">
                                            <h5 class="card-title"><?php echo htmlspecialchars($nft['name']); ?></h5>
                                            <p class="card-text text-muted">Price: <?php echo htmlspecialchars($nft['price']); ?> ETH</p>
                                            <p class="card-text"><small class="text-muted">Created: <?php echo date('M j, Y', strtotime($nft['created_at'])); ?></small></p>
                                        </div>
                                        <div class="card-footer">
                                            <a href="nft_details.php?id=<?php echo $nft['id']; ?>" class="btn btn-primary w-100">View Details</a>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                            
                            <?php if (empty($createdNfts)): ?>
                                <div class="col-12">
                                    <div class="alert alert-info">
                                        You haven't created any NFTs that are owned by others. <a href="create_nft.php">Create an NFT</a> to get started.
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
