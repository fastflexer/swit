<?php
session_start();
require_once '../config/config.php';
require_once '../includes/auth_check.php';
require_once '../includes/functions.php';

// Check if user is logged in
requireLogin();

// Get user data
$user = getUserById($_SESSION['user_id']);

// Get user's theme preference
$theme = $user['theme'] ?? 'dark';

// Get user's loans
$loans = getUserLoans($_SESSION['user_id']);

// Get loan plans
$loanPlans = getLoanPlans();

// Process messages
$message = '';
$messageType = '';

if (isset($_SESSION['loan_message'])) {
    $message = $_SESSION['loan_message'];
    $messageType = $_SESSION['loan_message_type'] ?? 'success';
    unset($_SESSION['loan_message']);
    unset($_SESSION['loan_message_type']);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Loans - <?php echo APP_NAME; ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <?php if ($theme === 'dark'): ?>
    <link rel="stylesheet" href="../assets/css/dark-theme.css">
    <?php else: ?>
    <link rel="stylesheet" href="../assets/css/light-theme.css">
    <?php endif; ?>
</head>
<body class="<?php echo $theme; ?>-theme">
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <?php include 'includes/sidebar.php'; ?>
            
            <!-- Main Content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Loans</h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#applyLoanModal">
                            <i class="fas fa-plus-circle me-2"></i>Apply for Loan
                        </button>
                    </div>
                </div>
                
                <?php if (!empty($message)): ?>
                <div class="alert alert-<?php echo $messageType; ?> alert-dismissible fade show" role="alert">
                    <?php echo $message; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <?php endif; ?>
                
                <!-- Loan Plans -->
                <div class="row mb-4">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="mb-0">Available Loan Plans</h5>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <?php foreach ($loanPlans as $plan): ?>
                                    <div class="col-md-4 mb-3">
                                        <div class="card h-100 loan-plan-card">
                                            <div class="card-body">
                                                <h5 class="card-title"><?php echo $plan['name']; ?></h5>
                                                <div class="loan-plan-details">
                                                    <div class="loan-plan-item">
                                                        <span class="loan-plan-label">Amount Range:</span>
                                                        <span class="loan-plan-value">$<?php echo number_format($plan['min_amount'], 2); ?> - $<?php echo number_format($plan['max_amount'], 2); ?></span>
                                                    </div>
                                                    <div class="loan-plan-item">
                                                        <span class="loan-plan-label">Interest Rate:</span>
                                                        <span class="loan-plan-value"><?php echo $plan['interest_rate']; ?>%</span>
                                                    </div>
                                                    <div class="loan-plan-item">
                                                        <span class="loan-plan-label">Duration:</span>
                                                        <span class="loan-plan-value"><?php echo $plan['duration']; ?> days</span>
                                                    </div>
                                                    <div class="loan-plan-item">
                                                        <span class="loan-plan-label">Processing Fee:</span>
                                                        <span class="loan-plan-value"><?php echo $plan['processing_fee']; ?>%</span>
                                                    </div>
                                                </div>
                                                <button class="btn btn-primary mt-3 w-100" onclick="selectLoanPlan(<?php echo $plan['id']; ?>, '<?php echo $plan['name']; ?>', <?php echo $plan['min_amount']; ?>, <?php echo $plan['max_amount']; ?>)">
                                                    Apply Now
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- My Loans -->
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">My Loans</h5>
                    </div>
                    <div class="card-body">
                        <?php if (empty($loans)): ?>
                        <div class="text-center py-5">
                            <i class="fas fa-file-invoice-dollar fa-4x mb-3 text-muted"></i>
                            <h5>No Loans Found</h5>
                            <p class="text-muted">You haven't applied for any loans yet.</p>
                            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#applyLoanModal">
                                Apply for a Loan
                            </button>
                        </div>
                        <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Loan ID</th>
                                        <th>Plan</th>
                                        <th>Amount</th>
                                        <th>Interest</th>
                                        <th>Total Repayment</th>
                                        <th>Duration</th>
                                        <th>Applied Date</th>
                                        <th>Due Date</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($loans as $loan): ?>
                                    <tr>
                                        <td><?php echo $loan['loan_id']; ?></td>
                                        <td><?php echo $loan['plan_name']; ?></td>
                                        <td>$<?php echo number_format($loan['amount'], 2); ?></td>
                                        <td>$<?php echo number_format($loan['interest_amount'], 2); ?></td>
                                        <td>$<?php echo number_format($loan['total_repayment'], 2); ?></td>
                                        <td><?php echo $loan['duration']; ?> days</td>
                                        <td><?php echo date('M d, Y', strtotime($loan['created_at'])); ?></td>
                                        <td><?php echo $loan['due_date'] ? date('M d, Y', strtotime($loan['due_date'])) : 'N/A'; ?></td>
                                        <td>
                                            <?php
                                            $statusClass = '';
                                            switch ($loan['status']) {
                                                case 'pending':
                                                    $statusClass = 'bg-warning';
                                                    break;
                                                case 'approved':
                                                    $statusClass = 'bg-success';
                                                    break;
                                                case 'rejected':
                                                    $statusClass = 'bg-danger';
                                                    break;
                                                case 'paid':
                                                    $statusClass = 'bg-info';
                                                    break;
                                                case 'overdue':
                                                    $statusClass = 'bg-danger';
                                                    break;
                                            }
                                            ?>
                                            <span class="badge <?php echo $statusClass; ?>"><?php echo ucfirst($loan['status']); ?></span>
                                        </td>
                                        <td>
                                            <a href="loan_details.php?id=<?php echo $loan['id']; ?>" class="btn btn-sm btn-info">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                            <?php if ($loan['status'] === 'approved'): ?>
                                            <a href="repay_loan.php?id=<?php echo $loan['id']; ?>" class="btn btn-sm btn-success">
                                                <i class="fas fa-money-bill-wave"></i> Repay
                                            </a>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </main>
        </div>
    </div>
    
    <!-- Apply Loan Modal -->
    <div class="modal fade" id="applyLoanModal" tabindex="-1" aria-labelledby="applyLoanModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="applyLoanModalLabel">Apply for Loan</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="apply_loan.php" method="post">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="loan_plan" class="form-label">Loan Plan</label>
                            <select class="form-select" id="loan_plan" name="loan_plan" required>
                                <option value="">Select Loan Plan</option>
                                <?php foreach ($loanPlans as $plan): ?>
                                <option value="<?php echo $plan['id']; ?>" data-min="<?php echo $plan['min_amount']; ?>" data-max="<?php echo $plan['max_amount']; ?>" data-interest="<?php echo $plan['interest_rate']; ?>" data-duration="<?php echo $plan['duration']; ?>" data-fee="<?php echo $plan['processing_fee']; ?>">
                                    <?php echo $plan['name']; ?> - $<?php echo number_format($plan['min_amount'], 2); ?> to $<?php echo number_format($plan['max_amount'], 2); ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="mb-3">
                            <label for="loan_amount" class="form-label">Loan Amount</label>
                            <div class="input-group">
                                <span class="input-group-text">$</span>
                                <input type="number" class="form-control" id="loan_amount" name="loan_amount" min="0" step="0.01" required>
                            </div>
                            <div class="form-text" id="amount_range">Amount range: $0.00 - $0.00</div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="purpose" class="form-label">Purpose of Loan</label>
                            <select class="form-select" id="purpose" name="purpose" required>
                                <option value="">Select Purpose</option>
                                <option value="Trading Capital">Trading Capital</option>
                                <option value="Account Upgrade">Account Upgrade</option>
                                <option value="Margin Call">Margin Call</option>
                                <option value="Investment">Investment</option>
                                <option value="Other">Other</option>
                            </select>
                        </div>
                        
                        <div class="mb-3" id="other_purpose_div" style="display: none;">
                            <label for="other_purpose" class="form-label">Specify Other Purpose</label>
                            <textarea class="form-control" id="other_purpose" name="other_purpose" rows="2"></textarea>
                        </div>
                        
                        <div class="mb-3">
                            <label for="repayment_source" class="form-label">Source of Repayment</label>
                            <select class="form-select" id="repayment_source" name="repayment_source" required>
                                <option value="">Select Source</option>
                                <option value="Trading Profits">Trading Profits</option>
                                <option value="Investment Returns">Investment Returns</option>
                                <option value="Salary/Income">Salary/Income</option>
                                <option value="Business Revenue">Business Revenue</option>
                                <option value="Other">Other</option>
                            </select>
                        </div>
                        
                        <div class="mb-3" id="other_source_div" style="display: none;">
                            <label for="other_source" class="form-label">Specify Other Source</label>
                            <textarea class="form-control" id="other_source" name="other_source" rows="2"></textarea>
                        </div>
                        
                        <div class="loan-summary p-3 rounded mb-3" style="background-color: rgba(0,0,0,0.05);">
                            <h6 class="mb-3">Loan Summary</h6>
                            <div class="row">
                                <div class="col-md-6">
                                    <p class="mb-2">Loan Amount: <span id="summary_amount">$0.00</span></p>
                                    <p class="mb-2">Interest Rate: <span id="summary_rate">0%</span></p>
                                    <p class="mb-2">Processing Fee: <span id="summary_fee">$0.00</span></p>
                                </div>
                                <div class="col-md-6">
                                    <p class="mb-2">Interest Amount: <span id="summary_interest">$0.00</span></p>
                                    <p class="mb-2">Duration: <span id="summary_duration">0 days</span></p>
                                    <p class="mb-2 fw-bold">Total Repayment: <span id="summary_total">$0.00</span></p>
                                </div>
                            </div>
                        </div>
                        
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" id="agree_terms" name="agree_terms" required>
                            <label class="form-check-label" for="agree_terms">
                                I agree to the <a href="../terms.php" target="_blank">terms and conditions</a> of the loan agreement.
                            </label>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Submit Application</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Function to select loan plan from the cards
        function selectLoanPlan(planId, planName, minAmount, maxAmount) {
            // Set the selected plan in the dropdown
            document.getElementById('loan_plan').value = planId;
            
            // Trigger the change event to update the form
            const event = new Event('change');
            document.getElementById('loan_plan').dispatchEvent(event);
            
            // Set a default amount (minimum amount)
            document.getElementById('loan_amount').value = minAmount;
            updateLoanSummary();
            
            // Open the modal
            const modal = new bootstrap.Modal(document.getElementById('applyLoanModal'));
            modal.show();
        }
        
        // Handle purpose selection
        document.getElementById('purpose').addEventListener('change', function() {
            const otherPurposeDiv = document.getElementById('other_purpose_div');
            if (this.value === 'Other') {
                otherPurposeDiv.style.display = 'block';
                document.getElementById('other_purpose').setAttribute('required', 'required');
            } else {
                otherPurposeDiv.style.display = 'none';
                document.getElementById('other_purpose').removeAttribute('required');
            }
        });
        
        // Handle repayment source selection
        document.getElementById('repayment_source').addEventListener('change', function() {
            const otherSourceDiv = document.getElementById('other_source_div');
            if (this.value === 'Other') {
                otherSourceDiv.style.display = 'block';
                document.getElementById('other_source').setAttribute('required', 'required');
            } else {
                otherSourceDiv.style.display = 'none';
                document.getElementById('other_source').removeAttribute('required');
            }
        });
        
        // Handle loan plan selection
        document.getElementById('loan_plan').addEventListener('change', function() {
            const selectedOption = this.options[this.selectedIndex];
            const minAmount = parseFloat(selectedOption.dataset.min);
            const maxAmount = parseFloat(selectedOption.dataset.max);
            
            // Update amount range text
            document.getElementById('amount_range').textContent = `Amount range: $${minAmount.toFixed(2)} - $${maxAmount.toFixed(2)}`;
            
            // Update loan amount input constraints
            const loanAmountInput = document.getElementById('loan_amount');
            loanAmountInput.min = minAmount;
            loanAmountInput.max = maxAmount;
            
            // Set default value to minimum amount
            if (!loanAmountInput.value || parseFloat(loanAmountInput.value) < minAmount) {
                loanAmountInput.value = minAmount;
            } else if (parseFloat(loanAmountInput.value) > maxAmount) {
                loanAmountInput.value = maxAmount;
            }
            
            updateLoanSummary();
        });
        
        // Handle loan amount changes
        document.getElementById('loan_amount').addEventListener('input', updateLoanSummary);
        
        // Update loan summary
        function updateLoanSummary() {
            const loanPlanSelect = document.getElementById('loan_plan');
            const loanAmountInput = document.getElementById('loan_amount');
            
            if (loanPlanSelect.value && loanAmountInput.value) {
                const selectedOption = loanPlanSelect.options[loanPlanSelect.selectedIndex];
                const interestRate = parseFloat(selectedOption.dataset.interest);
                const duration = parseInt(selectedOption.dataset.duration);
                const processingFeeRate = parseFloat(selectedOption.dataset.fee);
                const loanAmount = parseFloat(loanAmountInput.value);
                
                // Calculate values
                const processingFee = (loanAmount * processingFeeRate) / 100;
                const interestAmount = (loanAmount * interestRate * duration) / (100 * 365);
                const totalRepayment = loanAmount + interestAmount;
                
                // Update summary
                document.getElementById('summary_amount').textContent = `$${loanAmount.toFixed(2)}`;
                document.getElementById('summary_rate').textContent = `${interestRate}%`;
                document.getElementById('summary_fee').textContent = `$${processingFee.toFixed(2)}`;
                document.getElementById('summary_interest').textContent = `$${interestAmount.toFixed(2)}`;
                document.getElementById('summary_duration').textContent = `${duration} days`;
                document.getElementById('summary_total').textContent = `$${totalRepayment.toFixed(2)}`;
            }
        }
    </script>
</body>
</html>
