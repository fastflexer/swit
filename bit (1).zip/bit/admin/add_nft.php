<?php
require_once '../config/config.php';
require_once '../includes/auth_check.php';
require_once '../includes/admin_check.php';
require_once '../includes/functions.php';

// Get all users for creator/owner selection
$stmt = $conn->prepare("SELECT id, username, first_name, last_name FROM users ORDER BY username ASC");
$stmt->execute();
$users = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Process form submission
$message = '';
$messageType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $description = trim($_POST['description']);
    $price = floatval($_POST['price']);
    $category = trim($_POST['category']);
    $creatorId = intval($_POST['creator_id']);
    $ownerId = intval($_POST['owner_id']);
    
    // Validate inputs
    if (empty($name) || empty($description) || $price <= 0 || empty($category) || $creatorId <= 0 || $ownerId <= 0) {
        $message = 'All fields are required and price must be greater than 0.';
        $messageType = 'danger';
    } else {
        // Handle file upload
        $targetDir = "../uploads/nfts/";
        if (!file_exists($targetDir)) {
            mkdir($targetDir, 0777, true);
        }
        
        $imageUrl = '';
        $uploadOk = 1;
        
        if (isset($_FILES["nft_image"]) && $_FILES["nft_image"]["error"] == 0) {
            $fileName = basename($_FILES["nft_image"]["name"]);
            $targetFile = $targetDir . time() . '_' . $fileName;
            $imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));
            
            // Check if image file is a actual image
            $check = getimagesize($_FILES["nft_image"]["tmp_name"]);
            if ($check === false) {
                $message = "File is not an image.";
                $messageType = 'danger';
                $uploadOk = 0;
            }
            
            // Check file size (limit to 5MB)
            if ($_FILES["nft_image"]["size"] > 5000000) {
                $message = "Sorry, your file is too large.";
                $messageType = 'danger';
                $uploadOk = 0;
            }
            
            // Allow certain file formats
            if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif") {
                $message = "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
                $messageType = 'danger';
                $uploadOk = 0;
            }
            
            // If everything is ok, try to upload file
            if ($uploadOk == 1) {
                if (move_uploaded_file($_FILES["nft_image"]["tmp_name"], $targetFile)) {
                    $imageUrl = str_replace('../', '', $targetFile);
                } else {
                    $message = "Sorry, there was an error uploading your file.";
                    $messageType = 'danger';
                    $uploadOk = 0;
                }
            }
        } else {
            $message = "Please select an image for your NFT.";
            $messageType = 'danger';
            $uploadOk = 0;
        }
        
        // If upload was successful, insert NFT into database
        if ($uploadOk == 1) {
            $stmt = $conn->prepare("INSERT INTO nfts (name, description, price, category, image_url, creator_id, owner_id, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, NOW())");
            $stmt->bind_param("ssdssis", $name, $description, $price, $category, $imageUrl, $creatorId, $ownerId);
            
            if ($stmt->execute()) {
                $message = "NFT created successfully!";
                $messageType = 'success';
                
                // Redirect after a short delay
                header("Refresh: 2; URL=manage_nfts.php");
            } else {
                $message = "Error: " . $stmt->error;
                $messageType = 'danger';
            }
        }
    }
}

// Get available categories
$categories = ['Art', 'Music', 'Photography', 'Sports', 'Collectibles', 'Virtual Worlds', 'Trading Cards', 'Utility', 'Domain Names'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add NFT - Admin Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <style>
        .form-container {
            max-width: 800px;
            margin: 0 auto;
        }
        .image-preview {
            width: 100%;
            height: 300px;
            border: 2px dashed #ddd;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 20px;
            overflow: hidden;
        }
        .image-preview img {
            max-width: 100%;
            max-height: 100%;
            display: none;
        }
        .image-preview-text {
            color: #999;
        }
        @media (max-width: 768px) {
            .image-preview {
                height: 200px;
            }
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <?php include 'includes/sidebar.php'; ?>
            
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Add NFT</h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <div class="btn-group me-2">
                            <a href="manage_nfts.php" class="btn btn-sm btn-outline-secondary">Back to NFTs</a>
                        </div>
                    </div>
                </div>
                
                <?php if (!empty($message)): ?>
                    <div class="alert alert-<?php echo $messageType; ?> alert-dismissible fade show" role="alert">
                        <?php echo $message; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>
                
                <div class="card mb-4">
                    <div class="card-header">
                        <i class="fas fa-plus-circle me-1"></i>
                        Add New NFT
                    </div>
                    <div class="card-body">
                        <div class="form-container">
                            <form method="POST" enctype="multipart/form-data">
                                <div class="mb-3">
                                    <label for="name" class="form-label">NFT Name</label>
                                    <input type="text" class="form-control" id="name" name="name" required>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="description" class="form-label">Description</label>
                                    <textarea class="form-control" id="description" name="description" rows="4" required></textarea>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="price" class="form-label">Price (ETH)</label>
                                    <input type="number" class="form-control" id="price" name="price" step="0.001" min="0.001" required>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="category" class="form-label">Category</label>
                                    <select class="form-select" id="category" name="category" required>
                                        <option value="">Select a category</option>
                                        <?php foreach ($categories as $category): ?>
                                            <option value="<?php echo $category; ?>"><?php echo $category; ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="creator_id" class="form-label">Creator</label>
                                    <select class="form-select" id="creator_id" name="creator_id" required>
                                        <option value="">Select a creator</option>
                                        <?php foreach ($users as $user): ?>
                                            <option value="<?php echo $user['id']; ?>"><?php echo htmlspecialchars($user['username'] . ' (' . $user['first_name'] . ' ' . $user['last_name'] . ')'); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="owner_id" class="form-label">Owner</label>
                                    <select class="form-select" id="owner_id" name="owner_id" required>
                                        <option value="">Select an owner</option>
                                        <?php foreach ($users as $user): ?>
                                            <option value="<?php echo $user['id']; ?>"><?php echo htmlspecialchars($user['username'] . ' (' . $user['first_name'] . ' ' . $user['last_name'] . ')'); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="nft_image" class="form-label">NFT Image</label>
                                    <div class="image-preview" id="imagePreview">
                                        <span class="image-preview-text">Image Preview</span>
                                        <img src="/placeholder.svg" alt="Image Preview" class="preview-img">
                                    </div>
                                    <input class="form-control" type="file" id="nft_image" name="nft_image" accept="image/*" required>
                                </div>
                                
                                <div class="d-grid gap-2">
                                    <button type="submit" class="btn btn-primary">Create NFT</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const imageInput = document.getElementById('nft_image');
            const imagePreview = document.getElementById('imagePreview');
            const previewImg = imagePreview.querySelector('.preview-img');
            const previewText = imagePreview.querySelector('.image-preview-text');
            
            imageInput.addEventListener('change', function() {
                const file = this.files[0];
                
                if (file) {
                    const reader = new FileReader();
                    
                    previewText.style.display = "none";
                    previewImg.style.display = "block";
                    
                    reader.addEventListener("load", function() {
                        previewImg.setAttribute("src", this.result);
                    });
                    
                    reader.readAsDataURL(file);
                } else {
                    previewText.style.display = "block";
                    previewImg.style.display = "none";
                    previewImg.setAttribute("src", "");
                }
            });
        });
    </script>
</body>
</html>
