<?php
require_once '../config/config.php';
require_once '../includes/auth_check.php';
require_once '../includes/functions.php';
require_once '../includes/functions_nft.php';

// Check if NFT feature is enabled for the user
$user_id = $_SESSION['user_id'];
$user_settings = getUserSettings($user_id);
if (!$user_settings['show_nft']) {
    header('Location: dashboard.php');
    exit;
}

// Get all NFT categories
$categories = getNFTCategories();

// Get NFTs with filter
$category_filter = isset($_GET['category']) ? $_GET['category'] : 'all';
$search_term = isset($_GET['search']) ? $_GET['search'] : '';
$nfts = getNFTs($category_filter, $search_term);

// Page title
$page_title = "NFT Gallery";
include '../includes/header.php';
?>

<div class="container-fluid">
    <div class="row">
        <!-- Sidebar -->
        <?php include 'includes/sidebar.php'; ?>

        <!-- Main Content -->
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 mt-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">NFT Gallery</h1>
                <div class="btn-toolbar mb-2 mb-md-0">
                    <div class="btn-group me-2">
                        <a href="create_nft.php" class="btn btn-sm btn-primary">Create NFT</a>
                        <a href="my_nfts.php" class="btn btn-sm btn-outline-secondary">My NFTs</a>
                    </div>
                </div>
            </div>

            <!-- Filter and Search -->
            <div class="row mb-4">
                <div class="col-12">
                    <div class="card bg-dark text-white">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-8">
                                    <div class="btn-group mb-3 mb-md-0">
                                        <a href="nfts.php" class="btn <?php echo $category_filter == 'all' ? 'btn-primary' : 'btn-outline-secondary'; ?>">All Categories</a>
                                        <?php foreach ($categories as $category): ?>
                                            <a href="nfts.php?category=<?php echo $category['id']; ?>" class="btn <?php echo $category_filter == $category['id'] ? 'btn-primary' : 'btn-outline-secondary'; ?>"><?php echo htmlspecialchars($category['name']); ?></a>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <form action="nfts.php" method="GET" class="d-flex">
                                        <?php if ($category_filter != 'all'): ?>
                                            <input type="hidden" name="category" value="<?php echo $category_filter; ?>">
                                        <?php endif; ?>
                                        <input type="text" name="search" class="form-control" placeholder="Search NFTs by name or category..." value="<?php echo htmlspecialchars($search_term); ?>">
                                        <button type="submit" class="btn btn-primary ms-2">Search</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- NFT Gallery -->
            <div class="row">
                <?php if (empty($nfts)): ?>
                    <div class="col-12 text-center">
                        <div class="alert alert-info">
                            No NFTs found. Be the first to <a href="create_nft.php">create an NFT</a>!
                        </div>
                    </div>
                <?php else: ?>
                    <?php foreach ($nfts as $nft): ?>
                        <div class="col-md-4 col-lg-3 mb-4">
                            <div class="card bg-dark text-white h-100">
                                <a href="nft_details.php?id=<?php echo $nft['id']; ?>" class="text-decoration-none">
                                    <img src="<?php echo htmlspecialchars($nft['image']); ?>" class="card-img-top" alt="<?php echo htmlspecialchars($nft['name']); ?>" style="height: 200px; object-fit: cover;">
                                    <div class="card-body">
                                        <h5 class="card-title text-white"><?php echo htmlspecialchars($nft['name']); ?></h5>
                                        <p class="card-text text-muted">Price: <?php echo number_format($nft['price'], 4); ?> ETH</p>
                                    </div>
                                </a>
                                <div class="card-footer">
                                    <a href="nft_details.php?id=<?php echo $nft['id']; ?>" class="btn btn-primary w-100">Buy Now</a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </main>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
