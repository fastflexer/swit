<?php
session_start();
require_once '../config/config.php';
require_once '../includes/auth_check.php';
require_once '../includes/functions.php';

// Check if user is admin
requireAdmin();
requireOTPVerification();

$error = '';
$success = '';

// Get current settings
$stmt = $conn->prepare("SELECT * FROM settings WHERE id = 1");
$stmt->execute();
$settings = $stmt->get_result()->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update_website'])) {
        $websiteName = $_POST['website_name'] ?? '';
        $websiteTitle = $_POST['website_title'] ?? '';
        $websiteKeywords = $_POST['website_keywords'] ?? '';
        $websiteDescription = $_POST['website_description'] ?? '';
        $announcement = $_POST['announcement'] ?? '';
        $liveChatCode = $_POST['live_chat_code'] ?? '';
        $timezone = $_POST['timezone'] ?? 'UTC';
        
        // Update settings
        $stmt = $conn->prepare("UPDATE settings SET website_name = ?, website_title = ?, website_keywords = ?, website_description = ?, announcement = ?, live_chat_code = ?, timezone = ? WHERE id = 1");
        $stmt->bind_param("sssssss", $websiteName, $websiteTitle, $websiteKeywords, $websiteDescription, $announcement, $liveChatCode, $timezone);
        
        if ($stmt->execute()) {
            $success = "Website settings updated successfully";
        } else {
            $error = "Failed to update settings. Please try again.";
        }
    }
    
    // Handle logo upload
    if (isset($_FILES['logo']) && $_FILES['logo']['error'] === UPLOAD_ERR_OK) {
        $allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
        $maxSize = 2 * 1024 * 1024; // 2MB
        
        if (!in_array($_FILES['logo']['type'], $allowedTypes)) {
            $error = "Invalid file type. Only JPG, PNG, and GIF are allowed.";
        } elseif ($_FILES['logo']['size'] > $maxSize) {
            $error = "File size exceeds the limit of 2MB.";
        } else {
            $fileName = 'logo_' . time() . '.' . pathinfo($_FILES['logo']['name'], PATHINFO_EXTENSION);
            $uploadPath = '../uploads/logo/' . $fileName;
            
            if (move_uploaded_file($_FILES['logo']['tmp_name'], $uploadPath)) {
                $stmt = $conn->prepare("UPDATE settings SET logo = ? WHERE id = 1");
                $stmt->bind_param("s", $fileName);
                $stmt->execute();
                $success = "Logo uploaded successfully";
            } else {
                $error = "Failed to upload logo. Please try again.";
            }
        }
    }
    
    // Handle favicon upload
    if (isset($_FILES['favicon']) && $_FILES['favicon']['error'] === UPLOAD_ERR_OK) {
        $allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/x-icon'];
        $maxSize = 1 * 1024 * 1024; // 1MB
        
        if (!in_array($_FILES['favicon']['type'], $allowedTypes)) {
            $error = "Invalid file type for favicon. Only JPG, PNG, GIF, and ICO are allowed.";
        } elseif ($_FILES['favicon']['size'] > $maxSize) {
            $error = "Favicon size exceeds the limit of 1MB.";
        } else {
            $fileName = 'favicon_' . time() . '.' . pathinfo($_FILES['favicon']['name'], PATHINFO_EXTENSION);
            $uploadPath = '../uploads/logo/' . $fileName;
            
            if (move_uploaded_file($_FILES['favicon']['tmp_name'], $uploadPath)) {
                $stmt = $conn->prepare("UPDATE settings SET favicon = ? WHERE id = 1");
                $stmt->bind_param("s", $fileName);
                $stmt->execute();
                $success = "Favicon uploaded successfully";
            } else {
                $error = "Failed to upload favicon. Please try again.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Settings - <?php echo APP_NAME; ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <?php include 'includes/sidebar.php'; ?>
            
            <!-- Main Content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Settings</h1>
                </div>
                
                <?php if (!empty($error)): ?>
                    <div class="alert alert-danger"><?php echo $error; ?></div>
                <?php endif; ?>
                
                <?php if (!empty($success)): ?>
                    <div class="alert alert-success"><?php echo $success; ?></div>
                <?php endif; ?>
                
                <ul class="nav nav-tabs mb-4" id="settingsTabs" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="website-tab" data-bs-toggle="tab" data-bs-target="#website" type="button" role="tab" aria-controls="website" aria-selected="true">Website Information</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="preference-tab" data-bs-toggle="tab" data-bs-target="#preference" type="button" role="tab" aria-controls="preference" aria-selected="false">Preference</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="email-tab" data-bs-toggle="tab" data-bs-target="#email" type="button" role="tab" aria-controls="email" aria-selected="false">Email/Google Login/Captcha</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="payment-tab" data-bs-toggle="tab" data-bs-target="#payment" type="button" role="tab" aria-controls="payment" aria-selected="false">Payment Methods</button>
                    </li>
                </ul>
                
                <div class="tab-content" id="settingsTabsContent">
                    <!-- Website Information Tab -->
                    <div class="tab-pane fade show active" id="website" role="tabpanel" aria-labelledby="website-tab">
                        <div class="card">
                            <div class="card-body">
                                <form method="POST" action="" enctype="multipart/form-data">
                                    <div class="mb-3">
                                        <label for="website_name" class="form-label">Website Name</label>
                                        <input type="text" class="form-control" id="website_name" name="website_name" value="<?php echo $settings['website_name'] ?? 'JetFx Growth'; ?>">
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="website_title" class="form-label">Website Title</label>
                                        <input type="text" class="form-control" id="website_title" name="website_title" value="<?php echo $settings['website_title'] ?? 'Welcome to JetFx Growth'; ?>">
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="website_keywords" class="form-label">Website Keywords</label>
                                        <input type="text" class="form-control" id="website_keywords" name="website_keywords" value="<?php echo $settings['website_keywords'] ?? 'online trade, forex, cfd'; ?>">
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="website_description" class="form-label">Website Description</label>
                                        <textarea class="form-control" id="website_description" name="website_description" rows="3"><?php echo $settings['website_description'] ?? 'We are online'; ?></textarea>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="announcement" class="form-label">Announcement</label>
                                        <textarea class="form-control" id="announcement" name="announcement" rows="3"><?php echo $settings['announcement'] ?? 'Welcome to CryptLive Market'; ?></textarea>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="live_chat_code" class="form-label">Live chat widget Code</label>
                                        <textarea class="form-control" id="live_chat_code" name="live_chat_code" rows="3"><?php echo $settings['live_chat_code'] ?? 'tawk to codess'; ?></textarea>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="timezone" class="form-label">Timezone</label>
                                        <select class="form-select" id="timezone" name="timezone">
                                            <option value="UTC" <?php echo ($settings['timezone'] ?? 'UTC') === 'UTC' ? 'selected' : ''; ?>>UTC</option>
                                            <option value="America/New_York" <?php echo ($settings['timezone'] ?? '') === 'America/New_York' ? 'selected' : ''; ?>>America/New_York</option>
                                            <option value="Europe/London" <?php echo ($settings['timezone'] ?? '') === 'Europe/London' ? 'selected' : ''; ?>>Europe/London</option>
                                            <option value="Asia/Tokyo" <?php echo ($settings['timezone'] ?? '') === 'Asia/Tokyo' ? 'selected' : ''; ?>>Asia/Tokyo</option>
                                        </select>
                                    </div>
                                    
                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <label for="logo" class="form-label">Logo (Recommended size: max width, 200px and max height 100px.)</label>
                                            <input type="file" class="form-control" id="logo" name="logo">
                                        </div>
                                        
                                        <div class="col-md-6 mb-3">
                                            <label for="favicon" class="form-label">Favicon (Recommended type: png, size: max width, 32px and max height 32px.)</label>
                                            <input type="file" class="form-control" id="favicon" name="favicon">
                                        </div>
                                    </div>
                                    
                                    <div class="d-grid">
                                        <button type="submit" name="update_website" class="btn btn-primary">Update</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Other tabs would be implemented similarly -->
                    <div class="tab-pane fade" id="preference" role="tabpanel" aria-labelledby="preference-tab">
                        <div class="card">
                            <div class="card-body">
                                <h5>Preference Settings</h5>
                                <p>This section will contain preference settings.</p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="tab-pane fade" id="email" role="tabpanel" aria-labelledby="email-tab">
                        <div class="card">
                            <div class="card-body">
                                <h5>Email/Google Login/Captcha Settings</h5>
                                <p>This section will contain email, Google login, and captcha settings.</p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="tab-pane fade" id="payment" role="tabpanel" aria-labelledby="payment-tab">
                        <div class="card">
                            <div class="card-body">
                                <h5>Payment Methods Settings</h5>
                                <p>This section will contain payment methods settings.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
