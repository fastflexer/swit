<?php
session_start();
require_once '../config/config.php';
require_once '../includes/auth_check.php';
require_once '../includes/functions.php';

// Check if user is admin
requireAdmin();
requireOTPVerification();

// Check if loan ID and action are provided
if (!isset($_GET['id']) || empty($_GET['id']) || !isset($_GET['action']) || empty($_GET['action'])) {
    $_SESSION['loan_message'] = "Invalid request.";
    $_SESSION['loan_message_type'] = "danger";
    header("Location: manage_loans.php");
    exit;
}

$loanId = intval($_GET['id']);
$action = $_GET['action'];

// Get loan details
$loan = getLoanById($loanId);

// Check if loan exists and is pending
if (!$loan || $loan['status'] !== 'pending') {
    $_SESSION['loan_message'] = "Loan not found or not in pending status.";
    $_SESSION['loan_message_type'] = "danger";
    header("Location: manage_loans.php");
    exit;
}

// Get user details
$user = getUserById($loan['user_id']);

// Process loan based on action
if ($action === 'approve') {
    // Calculate due date (current date + duration days)
    $dueDate = date('Y-m-d', strtotime('+' . $loan['duration'] . ' days'));
    
    // Update loan status to approved
    $result = approveLoan($loanId, $dueDate);
    
    if ($result) {
        // Add loan amount to user's balance
        updateUserBalance($loan['user_id'], $loan['amount'], 'add');
        
        // Send email notification
        sendLoanApprovalNotification($user, $loan);
        
        $_SESSION['loan_message'] = "Loan has been approved successfully. The amount has been added to the user's balance.";
        $_SESSION['loan_message_type'] = "success";
    } else {
        $_SESSION['loan_message'] = "Failed to approve loan. Please try again.";
        $_SESSION['loan_message_type'] = "danger";
    }
} elseif ($action === 'reject') {
    // Update loan status to rejected
    $result = rejectLoan($loanId);
    
    if ($result) {
        // Send email notification
        sendLoanRejectionNotification($user, $loan);
        
        $_SESSION['loan_message'] = "Loan has been rejected successfully.";
        $_SESSION['loan_message_type'] = "success";
    } else {
        $_SESSION['loan_message'] = "Failed to reject loan. Please try again.";
        $_SESSION['loan_message_type'] = "danger";
    }
} else {
    $_SESSION['loan_message'] = "Invalid action.";
    $_SESSION['loan_message_type'] = "danger";
}

// Redirect back to manage loans page
header("Location: manage_loans.php");
exit;
?>
