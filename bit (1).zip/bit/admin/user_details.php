<?php
session_start();
require_once '../config/config.php';
require_once '../includes/auth_check.php';
require_once '../includes/functions.php';

// Check if user is admin
requireAdmin();
requireOTPVerification();

// Check if user ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: manage_users.php");
    exit();
}

$userId = $_GET['id'];

// Get user data
$user = getUserById($userId);

if (!$user) {
    header("Location: manage_users.php");
    exit();
}

// Handle user actions
$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        $action = $_POST['action'];
        
        switch ($action) {
            case 'block':
                $stmt = $conn->prepare("UPDATE users SET status = 'blocked' WHERE id = ?");
                $stmt->bind_param("i", $userId);
                if ($stmt->execute()) {
                    $success = "User has been blocked successfully";
                    $user['status'] = 'blocked';
                } else {
                    $error = "Failed to block user";
                }
                break;
                
            case 'activate':
                $stmt = $conn->prepare("UPDATE users SET status = 'active' WHERE id = ?");
                $stmt->bind_param("i", $userId);
                if ($stmt->execute()) {
                    $success = "User has been activated successfully";
                    $user['status'] = 'active';
                } else {
                    $error = "Failed to activate user";
                }
                break;
                
            case 'toggle_trade':
                $newTradeStatus = $user['trade_status'] == 'on' ? 'off' : 'on';
                $stmt = $conn->prepare("UPDATE users SET trade_status = ? WHERE id = ?");
                $stmt->bind_param("si", $newTradeStatus, $userId);
                if ($stmt->execute()) {
                    $success = "Trade status has been updated successfully";
                    $user['trade_status'] = $newTradeStatus;
                } else {
                    $error = "Failed to update trade status";
                }
                break;
                
            case 'credit_debit':
                $amount = $_POST['amount'] ?? 0;
                $type = $_POST['type'] ?? 'credit';
                $description = $_POST['description'] ?? '';
                
                if (empty($amount) || !is_numeric($amount) || $amount <= 0) {
                    $error = "Please enter a valid amount";
                } else {
                    if ($type == 'credit') {
                        $stmt = $conn->prepare("UPDATE users SET balance = balance + ? WHERE id = ?");
                        $stmt->bind_param("di", $amount, $userId);
                        if ($stmt->execute()) {
                            // Log transaction
                            $stmt = $conn->prepare("INSERT INTO transactions (user_id, type, amount, description, created_at) VALUES (?, 'credit', ?, ?, NOW())");
                            $stmt->bind_param("ids", $userId, $amount, $description);
                            $stmt->execute();
                            
                            $success = "Account credited successfully";
                            $user['balance'] += $amount;
                        } else {
                            $error = "Failed to credit account";
                        }
                    } else {
                        // Check if user has enough balance
                        if ($user['balance'] < $amount) {
                            $error = "User does not have enough balance";
                        } else {
                            $stmt = $conn->prepare("UPDATE users SET balance = balance - ? WHERE id = ?");
                            $stmt->bind_param("di", $amount, $userId);
                            if ($stmt->execute()) {
                                // Log transaction
                                $stmt = $conn->prepare("INSERT INTO transactions (user_id, type, amount, description, created_at) VALUES (?, 'debit', ?, ?, NOW())");
                                $stmt->bind_param("ids", $userId, $amount, $description);
                                $stmt->execute();
                                
                                $success = "Account debited successfully";
                                $user['balance'] -= $amount;
                            } else {
                                $error = "Failed to debit account";
                            }
                        }
                    }
                }
                break;
                
            case 'reset_password':
                // Generate a random password
                $newPassword = bin2hex(random_bytes(4)); // 8 characters
                $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
                
                $stmt = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
                $stmt->bind_param("si", $hashedPassword, $userId);
                if ($stmt->execute()) {
                    // Send email with new password
                    $subject = APP_NAME . " - Password Reset";
                    $message = "Your password has been reset by an administrator. Your new password is: " . $newPassword;
                    sendEmail($user['email'], $subject, $message);
                    
                    $success = "Password has been reset successfully. New password: " . $newPassword;
                } else {
                    $error = "Failed to reset password";
                }
                break;
                
            case 'clear_account':
                // Clear user's balance
                $stmt = $conn->prepare("UPDATE users SET balance = 0 WHERE id = ?");
                $stmt->bind_param("i", $userId);
                if ($stmt->execute()) {
                    $success = "Account has been cleared successfully";
                    $user['balance'] = 0;
                } else {
                    $error = "Failed to clear account";
                }
                break;
                
            case 'delete':
                $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
                $stmt->bind_param("i", $userId);
                if ($stmt->execute()) {
                    $success = "User has been deleted successfully";
                    header("Location: manage_users.php");
                    exit();
                } else {
                    $error = "Failed to delete user";
                }
                break;
                
            case 'verify_kyc':
                $stmt = $conn->prepare("UPDATE users SET kyc_verified = 'yes' WHERE id = ?");
                $stmt->bind_param("i", $userId);
                if ($stmt->execute()) {
                    $success = "KYC has been verified successfully";
                    $user['kyc_verified'] = 'yes';
                } else {
                    $error = "Failed to verify KYC";
                }
                break;
                
            case 'reject_kyc':
                $stmt = $conn->prepare("UPDATE users SET kyc_verified = 'rejected' WHERE id = ?");
                $stmt->bind_param("i", $userId);
                if ($stmt->execute()) {
                    $success = "KYC has been rejected";
                    $user['kyc_verified'] = 'rejected';
                } else {
                    $error = "Failed to reject KYC";
                }
                break;
        }
    }
}

// Get user's deposits
$stmt = $conn->prepare("SELECT * FROM deposits WHERE user_id = ? ORDER BY created_at DESC LIMIT 5");
$stmt->bind_param("i", $userId);
$stmt->execute();
$deposits = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Get user's withdrawals
$stmt = $conn->prepare("SELECT * FROM withdrawals WHERE user_id = ? ORDER BY created_at DESC LIMIT 5");
$stmt->bind_param("i", $userId);
$stmt->execute();
$withdrawals = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Get user's trading accounts
$stmt = $conn->prepare("SELECT * FROM trading_accounts WHERE user_id = ? ORDER BY created_at DESC");
$stmt->bind_param("i", $userId);
$stmt->execute();
$tradingAccounts = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Get user's investments
$stmt = $conn->prepare("SELECT i.*, p.name as plan_name FROM investments i JOIN investment_plans p ON i.plan_id = p.id WHERE i.user_id = ? ORDER BY i.created_at DESC");
$stmt->bind_param("i", $userId);
$stmt->execute();
$investments = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Get user's referrals
$stmt = $conn->prepare("SELECT * FROM users WHERE referred_by = ?");
$stmt->bind_param("i", $userId);
$stmt->execute();
$referrals = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Calculate total profit
$totalProfit = 0;
foreach ($investments as $investment) {
    $totalProfit += $investment['profit'] ?? 0;
}

// Calculate total referral bonus
$totalReferralBonus = 0;
foreach ($referrals as $referral) {
    $totalReferralBonus += $referral['referral_bonus'] ?? 0;
}

// Calculate total bonus
$totalBonus = 0;
$stmt = $conn->prepare("SELECT SUM(amount) as total FROM bonuses WHERE user_id = ?");
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result()->fetch_assoc();
$totalBonus = $result['total'] ?? 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Details - <?php echo APP_NAME; ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <style>
        .user-info-box {
            background-color: #f8f9fa;
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 20px;
        }
        .user-info-label {
            font-weight: bold;
            color: #6c757d;
        }
        .user-info-value {
            font-weight: 500;
        }
        .dropdown-menu {
            max-height: 300px;
            overflow-y: auto;
        }
        .dropdown-item.text-danger:hover {
            background-color: #f8d7da;
        }
        .dropdown-item.text-success:hover {
            background-color: #d4edda;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <?php include 'includes/sidebar.php'; ?>
            
            <!-- Main Content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2"><?php echo $user['first_name'] . ' ' . $user['last_name']; ?></h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <a href="manage_users.php" class="btn btn-sm btn-outline-secondary me-2">
                            <i class="fas fa-arrow-left"></i> Back
                        </a>
                        <div class="dropdown">
                            <button class="btn btn-sm btn-primary dropdown-toggle" type="button" id="actionsDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                                Actions
                            </button>
                            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="actionsDropdown">
                                <li><a class="dropdown-item" href="user_login_activity.php?id=<?php echo $userId; ?>">Login Activity</a></li>
                                <li>
                                    <form method="POST" action="">
                                        <input type="hidden" name="action" value="<?php echo $user['status'] === 'active' ? 'block' : 'activate'; ?>">
                                        <button type="submit" class="dropdown-item <?php echo $user['status'] === 'active' ? 'text-danger' : 'text-success'; ?>">
                                            <?php echo $user['status'] === 'active' ? 'Block' : 'Activate'; ?>
                                        </button>
                                    </form>
                                </li>
                                <li>
                                    <form method="POST" action="">
                                        <input type="hidden" name="action" value="toggle_trade">
                                        <button type="submit" class="dropdown-item">
                                            Turn <?php echo $user['trade_status'] === 'on' ? 'off' : 'on'; ?> trade
                                        </button>
                                    </form>
                                </li>
                                <li><a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#billingMessageModal">Billing Message</a></li>
                                <li><a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#creditDebitModal">Credit/Debit</a></li>
                                <li>
                                    <form method="POST" action="">
                                        <input type="hidden" name="action" value="reset_password">
                                        <button type="submit" class="dropdown-item" onclick="return confirm('Are you sure you want to reset the password?')">
                                            Reset Password
                                        </button>
                                    </form>
                                </li>
                                <li>
                                    <form method="POST" action="">
                                        <input type="hidden" name="action" value="clear_account">
                                        <button type="submit" class="dropdown-item" onclick="return confirm('Are you sure you want to clear this account? This will set the balance to zero.')">
                                            Clear Account
                                        </button>
                                    </form>
                                </li>
                                <li><a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#addTradingHistoryModal">Add Trading History</a></li>
                                <li><a class="dropdown-item" href="edit_user.php?id=<?php echo $userId; ?>">Edit</a></li>
                                <li><a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#addReferralModal">Add Referral</a></li>
                                <li><a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#sendEmailModal">Send Email</a></li>
                                <li><a class="dropdown-item text-success" href="login_as_user.php?id=<?php echo $userId; ?>">Login as <?php echo $user['first_name']; ?></a></li>
                                <li>
                                    <form method="POST" action="">
                                        <input type="hidden" name="action" value="delete">
                                        <button type="submit" class="dropdown-item text-danger" onclick="return confirm('Are you sure you want to delete this user? This action cannot be undone.')">
                                            Delete <?php echo $user['first_name']; ?>
                                        </button>
                                    </form>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                
                <?php if (!empty($error)): ?>
                    <div class="alert alert-danger"><?php echo $error; ?></div>
                <?php endif; ?>
                
                <?php if (!empty($success)): ?>
                    <div class="alert alert-success"><?php echo $success; ?></div>
                <?php endif; ?>
                
                <div class="row mb-4">
                    <div class="col-md-3">
                        <div class="card">
                            <div class="card-header">Account Balance</div>
                            <div class="card-body">
                                <h3 class="card-title">$<?php echo number_format($user['balance'], 2); ?></h3>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card">
                            <div class="card-header">Profit</div>
                            <div class="card-body">
                                <h3 class="card-title">$<?php echo number_format($totalProfit, 2); ?></h3>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card">
                            <div class="card-header">Referral Bonus</div>
                            <div class="card-body">
                                <h3 class="card-title">$<?php echo number_format($totalReferralBonus, 2); ?></h3>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card">
                            <div class="card-header">Bonus</div>
                            <div class="card-body">
                                <h3 class="card-title">$<?php echo number_format($totalBonus, 2); ?></h3>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="row mb-4">
                    <div class="col-md-3">
                        <div class="card">
                            <div class="card-header">User Account Status</div>
                            <div class="card-body">
                                <span class="badge bg-<?php echo $user['status'] === 'active' ? 'success' : 'danger'; ?>">
                                    <?php echo ucfirst($user['status']); ?>
                                </span>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card">
                            <div class="card-header">Inv. Plans</div>
                            <div class="card-body">
                                <?php if (empty($investments)): ?>
                                    <span class="text-muted">No Investment Plan</span>
                                <?php else: ?>
                                    <ul class="list-unstyled">
                                        <?php foreach ($investments as $investment): ?>
                                            <li><?php echo $investment['plan_name']; ?></li>
                                        <?php endforeach; ?>
                                    </ul>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card">
                            <div class="card-header">KYC</div>
                            <div class="card-body">
                                <?php if ($user['kyc_verified'] === 'yes'): ?>
                                    <span class="badge bg-success">Verified</span>
                                <?php elseif ($user['kyc_verified'] === 'rejected'): ?>
                                    <span class="badge bg-danger">Rejected</span>
                                <?php else: ?>
                                    <span class="badge bg-warning text-dark">Not Verified Yet</span>
                                    <div class="mt-2">
                                        <form method="POST" action="" class="d-inline">
                                            <input type="hidden" name="action" value="verify_kyc">
                                            <button type="submit" class="btn btn-sm btn-success">Verify</button>
                                        </form>
                                        <form method="POST" action="" class="d-inline">
                                            <input type="hidden" name="action" value="reject_kyc">
                                            <button type="submit" class="btn btn-sm btn-danger">Reject</button>
                                        </form>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card">
                            <div class="card-header">Trade Mode</div>
                            <div class="card-body">
                                <span class="badge bg-<?php echo $user['trade_status'] === 'on' ? 'success' : 'danger'; ?>">
                                    <?php echo ucfirst($user['trade_status'] ?? 'On'); ?>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="card mb-4">
                    <div class="card-header">
                        <h5 class="mb-0">USER INFORMATION</h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <div class="user-info-label">Fullname</div>
                                    <div class="user-info-value"><?php echo $user['first_name'] . ' ' . $user['last_name']; ?></div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <div class="user-info-label">Email Address</div>
                                    <div class="user-info-value"><?php echo $user['email']; ?></div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <div class="user-info-label">Mobile Number</div>
                                    <div class="user-info-value"><?php echo $user['phone']; ?></div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <div class="user-info-label">Date of birth</div>
                                    <div class="user-info-value"><?php echo $user['date_of_birth'] ?? 'Not provided'; ?></div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <div class="user-info-label">Nationality</div>
                                    <div class="user-info-value"><?php echo $user['nationality'] ?? 'Not provided'; ?></div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <div class="user-info-label">Registered</div>
                                    <div class="user-info-value"><?php echo date('D, M j, Y g:i A', strtotime($user['created_at'])); ?></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-6">
                        <div class="card mb-4">
                            <div class="card-header d-flex justify-content-between align-items-center">
                                <h5 class="mb-0">Recent Deposits</h5>
                                <a href="user_deposits.php?id=<?php echo $userId; ?>" class="btn btn-sm btn-primary">View All</a>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-hover">
                                        <thead>
                                            <tr>
                                                <th>Amount</th>
                                                <th>Method</th>
                                                <th>Status</th>
                                                <th>Date</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php if (empty($deposits)): ?>
                                            <tr>
                                                <td colspan="4" class="text-center">No deposits found</td>
                                            </tr>
                                            <?php else: ?>
                                            <?php foreach ($deposits as $deposit): ?>
                                            <tr>
                                                <td>$<?php echo number_format($deposit['amount'], 2); ?></td>
                                                <td><?php echo $deposit['payment_method']; ?></td>
                                                <td>
                                                    <span class="badge bg-<?php 
                                                        echo $deposit['status'] === 'processed' ? 'success' : 
                                                            ($deposit['status'] === 'pending' ? 'warning' : 'danger'); 
                                                    ?>">
                                                        <?php echo $deposit['status']; ?>
                                                    </span>
                                                </td>
                                                <td><?php echo date('M j, Y', strtotime($deposit['created_at'])); ?></td>
                                            </tr>
                                            <?php endforeach; ?>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <div class="card mb-4">
                            <div class="card-header d-flex justify-content-between align-items-center">
                                <h5 class="mb-0">Recent Withdrawals</h5>
                                <a href="user_withdrawals.php?id=<?php echo $userId; ?>" class="btn btn-sm btn-primary">View All</a>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-hover">
                                        <thead>
                                            <tr>
                                                <th>Amount</th>
                                                <th>Method</th>
                                                <th>Status</th>
                                                <th>Date</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php if (empty($withdrawals)): ?>
                                            <tr>
                                                <td colspan="4" class="text-center">No withdrawals found</td>
                                            </tr>
                                            <?php else: ?>
                                            <?php foreach ($withdrawals as $withdrawal): ?>
                                            <tr>
                                                <td>$<?php echo number_format($withdrawal['amount'], 2); ?></td>
                                                <td><?php echo $withdrawal['payment_method']; ?></td>
                                                <td>
                                                    <span class="badge bg-<?php 
                                                        echo $withdrawal['status'] === 'processed' ? 'success' : 
                                                            ($withdrawal['status'] === 'pending' ? 'warning' : 'danger'); 
                                                    ?>">
                                                        <?php echo $withdrawal['status']; ?>
                                                    </span>
                                                </td>
                                                <td><?php echo date('M j, Y', strtotime($withdrawal['created_at'])); ?></td>
                                            </tr>
                                            <?php endforeach; ?>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-12">
                        <div class="card mb-4">
                            <div class="card-header d-flex justify-content-between align-items-center">
                                <h5 class="mb-0">Trading Accounts</h5>
                                <a href="user_trading_accounts.php?id=<?php echo $userId; ?>" class="btn btn-sm btn-primary">View All</a>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-hover">
                                        <thead>
                                            <tr>
                                                <th>Account ID</th>
                                                <th>Type</th>
                                                <th>Currency</th>
                                                <th>Leverage</th>
                                                <th>Server</th>
                                                <th>Status</th>
                                                <th>Created</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php if (empty($tradingAccounts)): ?>
                                            <tr>
                                                <td colspan="7" class="text-center">No trading accounts found</td>
                                            </tr>
                                            <?php else: ?>
                                            <?php foreach ($tradingAccounts as $account): ?>
                                            <tr>
                                                <td><?php echo $account['account_id']; ?></td>
                                                <td><?php echo $account['account_type']; ?></td>
                                                <td><?php echo $account['currency']; ?></td>
                                                <td><?php echo $account['leverage']; ?></td>
                                                <td><?php echo $account['server']; ?></td>
                                                <td>
                                                    <span class="badge bg-<?php 
                                                        echo $account['status'] === 'active' ? 'success' : 
                                                            ($account['status'] === 'pending' ? 'warning' : 'danger'); 
                                                    ?>">
                                                        <?php echo $account['status']; ?>
                                                    </span>
                                                </td>
                                                <td><?php echo date('M j, Y', strtotime($account['created_at'])); ?></td>
                                            </tr>
                                            <?php endforeach; ?>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                  ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-12">
                        <div class="card mb-4">
                            <div class="card-header d-flex justify-content-between align-items-center">
                                <h5 class="mb-0">Investments</h5>
                                <a href="user_investments.php?id=<?php echo $userId; ?>" class="btn btn-sm btn-primary">View All</a>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-hover">
                                        <thead>
                                            <tr>
                                                <th>Plan</th>
                                                <th>Amount</th>
                                                <th>ROI</th>
                                                <th>Duration</th>
                                                <th>Status</th>
                                                <th>Start Date</th>
                                                <th>End Date</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php if (empty($investments)): ?>
                                            <tr>
                                                <td colspan="7" class="text-center">No investments found</td>
                                            </tr>
                                            <?php else: ?>
                                            <?php foreach ($investments as $investment): ?>
                                            <tr>
                                                <td><?php echo $investment['plan_name']; ?></td>
                                                <td>$<?php echo number_format($investment['amount'], 2); ?></td>
                                                <td><?php echo $investment['roi']; ?>%</td>
                                                <td><?php echo $investment['duration']; ?> days</td>
                                                <td>
                                                    <span class="badge bg-<?php 
                                                        echo $investment['status'] === 'active' ? 'success' : 
                                                            ($investment['status'] === 'pending' ? 'warning' : 'danger'); 
                                                    ?>">
                                                        <?php echo $investment['status']; ?>
                                                    </span>
                                                </td>
                                                <td><?php echo date('M j, Y', strtotime($investment['created_at'])); ?></td>
                                                <td><?php echo date('M j, Y', strtotime($investment['created_at'] . ' + ' . $investment['duration'] . ' days')); ?></td>
                                            </tr>
                                            <?php endforeach; ?>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>
    
    <!-- Credit/Debit Modal -->
    <div class="modal fade" id="creditDebitModal" tabindex="-1" aria-labelledby="creditDebitModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="creditDebitModalLabel">Credit/Debit Account</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form method="POST" action="">
                    <div class="modal-body">
                        <input type="hidden" name="action" value="credit_debit">
                        
                        <div class="mb-3">
                            <label for="type" class="form-label">Type</label>
                            <select class="form-select" id="type" name="type" required>
                                <option value="credit">Credit</option>
                                <option value="debit">Debit</option>
                            </select>
                        </div>
                        
                        <div class="mb-3">
                            <label for="amount" class="form-label">Amount</label>
                            <input type="number" class="form-control" id="amount" name="amount" step="0.01" min="0.01" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="description" class="form-label">Description</label>
                            <textarea class="form-control" id="description" name="description" rows="3"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Billing Message Modal -->
    <div class="modal fade" id="billingMessageModal" tabindex="-1" aria-labelledby="billingMessageModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="billingMessageModalLabel">Send Billing Message</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form method="POST" action="send_billing_message.php">
                    <div class="modal-body">
                        <input type="hidden" name="user_id" value="<?php echo $userId; ?>">
                        
                        <div class="mb-3">
                            <label for="subject" class="form-label">Subject</label>
                            <input type="text" class="form-control" id="subject" name="subject" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="message" class="form-label">Message</label>
                            <textarea class="form-control" id="message" name="message" rows="5" required></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Send Message</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Add Trading History Modal -->
    <div class="modal fade" id="addTradingHistoryModal" tabindex="-1" aria-labelledby="addTradingHistoryModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addTradingHistoryModalLabel">Add Trading History</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form method="POST" action="add_trading_history.php">
                    <div class="modal-body">
                        <input type="hidden" name="user_id" value="<?php echo $userId; ?>">
                        
                        <div class="mb-3">
                            <label for="account_id" class="form-label">Trading Account</label>
                            <select class="form-select" id="account_id" name="account_id" required>
                                <?php foreach ($tradingAccounts as $account): ?>
                                <option value="<?php echo $account['id']; ?>"><?php echo $account['account_id']; ?> (<?php echo $account['account_type']; ?>)</option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="mb-3">
                            <label for="symbol" class="form-label">Symbol</label>
                            <input type="text" class="form-control" id="symbol" name="symbol" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="trade_type" class="form-label">Type</label>
                            <select class="form-select" id="trade_type" name="trade_type" required>
                                <option value="buy">Buy</option>
                                <option value="sell">Sell</option>
                            </select>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="open_price" class="form-label">Open Price</label>
                                <input type="number" class="form-control" id="open_price" name="open_price" step="0.00001" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="close_price" class="form-label">Close Price</label>
                                <input type="number" class="form-control" id="close_price" name="close_price" step="0.00001" required>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="volume" class="form-label">Volume</label>
                                <input type="number" class="form-control" id="volume" name="volume" step="0.01" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="profit" class="form-label">Profit/Loss</label>
                                <input type="number" class="form-control" id="profit" name="profit" step="0.01" required>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="trade_date" class="form-label">Trade Date</label>
                            <input type="datetime-local" class="form-control" id="trade_date" name="trade_date" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Add Trade</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Add Referral Modal -->
    <div class="modal fade" id="addReferralModal" tabindex="-1" aria-labelledby="addReferralModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addReferralModalLabel">Add Referral</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form method="POST" action="add_referral.php">
                    <div class="modal-body">
                        <input type="hidden" name="user_id" value="<?php echo $userId; ?>">
                        
                        <div class="mb-3">
                            <label for="referral_email" class="form-label">Referral Email</label>
                            <input type="email" class="form-control" id="referral_email" name="referral_email" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="bonus_amount" class="form-label">Bonus Amount</label>
                            <input type="number" class="form-control" id="bonus_amount" name="bonus_amount" step="0.01" min="0">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Add Referral</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Send Email Modal -->
    <div class="modal fade" id="sendEmailModal" tabindex="-1" aria-labelledby="sendEmailModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="sendEmailModalLabel">Send Email</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form method="POST" action="send_email.php">
                    <div class="modal-body">
                        <input type="hidden" name="user_id" value="<?php echo $userId; ?>">
                        
                        <div class="mb-3">
                            <label for="email_subject" class="form-label">Subject</label>
                            <input type="text" class="form-control" id="email_subject" name="email_subject" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="email_message" class="form-label">Message</label>
                            <textarea class="form-control" id="email_message" name="email_message" rows="5" required></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Send Email</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
