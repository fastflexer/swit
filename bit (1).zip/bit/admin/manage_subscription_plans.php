<?php
require_once '../config/config.php';
require_once '../includes/auth_check.php';
require_once '../includes/admin_check.php';
require_once '../includes/functions.php';

// Get all subscription plans
$stmt = $conn->prepare("SELECT * FROM subscription_plans ORDER BY type, price ASC");
$stmt->execute();
$plans = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Process plan deletion
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_plan'])) {
    $planId = intval($_POST['plan_id']);
    
    // Check if plan has active subscriptions
    $stmt = $conn->prepare("SELECT COUNT(*) as count FROM subscriptions WHERE plan_id = ? AND status = 'active'");
    $stmt->bind_param("i", $planId);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    
    if ($result['count'] > 0) {
        $message = "Cannot delete plan with active subscriptions.";
        $messageType = "danger";
    } else {
        // Delete plan
        $stmt = $conn->prepare("DELETE FROM subscription_plans WHERE id = ?");
        $stmt->bind_param("i", $planId);
        
        if ($stmt->execute()) {
            $message = "Plan deleted successfully.";
            $messageType = "success";
            
            // Refresh plans list
            $stmt = $conn->prepare("SELECT * FROM subscription_plans ORDER BY type, price ASC");
            $stmt->execute();
            $plans = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        } else {
            $message = "Error deleting plan: " . $stmt->error;
            $messageType = "danger";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Subscription Plans - Admin Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <style>
        .badge-investment {
            background-color: #3498db;
            color: white;
        }
        .badge-signal {
            background-color: #2ecc71;
            color: white;
        }
        .table-responsive {
            overflow-x: auto;
        }
        @media (max-width: 768px) {
            .action-buttons {
                display: flex;
                flex-direction: column;
                gap: 5px;
            }
            .action-buttons .btn {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <?php include 'includes/sidebar.php'; ?>
            
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Manage Subscription Plans</h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <div class="btn-group me-2">
                            <a href="add_subscription_plan.php" class="btn btn-sm btn-outline-secondary">Add Plan</a>
                        </div>
                    </div>
                </div>
                
                <?php if (isset($message)): ?>
                    <div class="alert alert-<?php echo $messageType; ?> alert-dismissible fade show" role="alert">
                        <?php echo $message; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>
                
                <div class="card mb-4">
                    <div class="card-header">
                        <i class="fas fa-table me-1"></i>
                        All Subscription Plans
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-hover" id="plansTable">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Name</th>
                                        <th>Type</th>
                                        <th>Price</th>
                                        <th>Duration</th>
                                        <th>Features</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($plans as $plan): ?>
                                        <tr>
                                            <td><?php echo $plan['id']; ?></td>
                                            <td><?php echo htmlspecialchars($plan['name']); ?></td>
                                            <td>
                                                <?php if ($plan['type'] == 'investment'): ?>
                                                    <span class="badge badge-investment">Investment</span>
                                                <?php else: ?>
                                                    <span class="badge badge-signal">Signal</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if ($plan['type'] == 'investment'): ?>
                                                    Min: $<?php echo number_format($plan['min_amount'], 2); ?><br>
                                                    <?php if ($plan['max_amount'] > 0): ?>
                                                        Max: $<?php echo number_format($plan['max_amount'], 2); ?>
                                                    <?php else: ?>
                                                        Max: Unlimited
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    $<?php echo number_format($plan['price'], 2); ?>
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo $plan['duration']; ?> days</td>
                                            <td>
                                                <?php 
                                                if ($plan['type'] == 'investment') {
                                                    echo $plan['roi_rate'] . '% Daily ROI';
                                                } else {
                                                    $features = json_decode($plan['features'], true);
                                                    if (is_array($features) && !empty($features)) {
                                                        echo '<ul class="mb-0 ps-3">';
                                                        foreach (array_slice($features, 0, 2) as $feature) {
                                                            echo '<li>' . htmlspecialchars($feature) . '</li>';
                                                        }
                                                        if (count($features) > 2) {
                                                            echo '<li>...</li>';
                                                        }
                                                        echo '</ul>';
                                                    }
                                                }
                                                ?>
                                            </td>
                                            <td>
                                                <?php if ($plan['status'] == 'active'): ?>
                                                    <span class="badge bg-success">Active</span>
                                                <?php else: ?>
                                                    <span class="badge bg-danger">Inactive</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <div class="action-buttons">
                                                    <a href="edit_subscription_plan.php?id=<?php echo $plan['id']; ?>" class="btn btn-sm btn-primary">Edit</a>
                                                    <button type="button" class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#deleteModal<?php echo $plan['id']; ?>">Delete</button>
                                                </div>
                                            </td>
                                        </tr>
                                        
                                        <!-- Delete Modal -->
                                        <div class="modal fade" id="deleteModal<?php echo $plan['id']; ?>" tabindex="-1" aria-labelledby="deleteModalLabel<?php echo $plan['id']; ?>" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="deleteModalLabel<?php echo $plan['id']; ?>">Confirm Deletion</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        Are you sure you want to delete the plan "<?php echo htmlspecialchars($plan['name']); ?>"? This action cannot be undone.
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                                        <form method="POST">
                                                            <input type="hidden" name="plan_id" value="<?php echo $plan['id']; ?>">
                                                            <input type="hidden" name="delete_plan" value="1">
                                                            <button type="submit" class="btn btn-danger">Delete</button>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const datatablesSimple = document.getElementById('plansTable');
            if (datatablesSimple) {
                new simpleDatatables.DataTable(datatablesSimple);
            }
        });
    </script>
</body>
</html>
