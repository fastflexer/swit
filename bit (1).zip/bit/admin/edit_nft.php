<?php
require_once '../config/config.php';
require_once '../includes/auth_check.php';
require_once '../includes/admin_check.php';
require_once '../includes/functions.php';

// Check if NFT ID is provided
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header('Location: manage_nfts.php');
    exit;
}

$nftId = intval($_GET['id']);

// Get NFT details
$stmt = $conn->prepare("SELECT * FROM nfts WHERE id = ?");
$stmt->bind_param("i", $nftId);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    header('Location: manage_nfts.php');
    exit;
}

$nft = $result->fetch_assoc();

// Get all users for creator/owner selection
$stmt = $conn->prepare("SELECT id, username, first_name, last_name FROM users ORDER BY username ASC");
$stmt->execute();
$users = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Process form submission
$message = '';
$messageType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $description = trim($_POST['description']);
    $price = floatval($_POST['price']);
    $category = trim($_POST['category']);
    $creatorId = intval($_POST['creator_id']);
    $ownerId = intval($_POST['owner_id']);
    
    // Validate inputs
    if (empty($name) || empty($description) || $price <= 0 || empty($category) || $creatorId <= 0 || $ownerId <= 0) {
        $message = 'All fields are required and price must be greater than 0.';
        $messageType = 'danger';
    } else {
        $imageUrl = $nft['image_url']; // Keep existing image by default
        $uploadOk = 1;
        
        // Check if a new image is uploaded
        if (isset($_FILES["nft_image"]) && $_FILES["nft_image"]["error"] == 0) {
            $targetDir = "../uploads/nfts/";
            if (!file_exists($targetDir)) {
                mkdir($targetDir, 0777, true);
            }
            
            $fileName = basename($_FILES["nft_image"]["name"]);
            $targetFile = $targetDir . time() . '_' . $fileName;
            $imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));
            
            // Check if image file is a actual image
            $check = getimagesize($_FILES["nft_image"]["tmp_name"]);
            if ($check === false) {
                $message = "File is not an image.";
                $messageType = 'danger';
                $uploadOk = 0;
            }
            
            // Check file size (limit to 5MB)
            if ($_FILES["nft_image"]["size"] > 5000000) {
                $message = "Sorry, your file is too large.";
                $messageType = 'danger';
                $uploadOk = 0;
            }
            
            // Allow certain file formats
            if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif") {
                $message = "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
                $messageType = 'danger';
                $uploadOk = 0;
            }
            
            // If everything is ok, try to upload file
            if ($uploadOk == 1) {
                if (move_uploaded_file($_FILES["nft_image"]["tmp_name"], $targetFile)) {
                    // Delete old image if it exists
                    if (!empty($nft['image_url'])) {
                        $oldImagePath = '../' . $nft['image_url'];
                        if (file_exists($oldImagePath)) {
                            unlink($oldImagePath);
                        }
                    }
                    
                    $imageUrl = str_replace('../', '', $targetFile);
                } else {
                    $message = "Sorry, there was an error uploading your file.";
                    $messageType = 'danger';
                    $uploadOk = 0;
                }
            }
        }
        
        // If everything is ok, update NFT in database
        if ($uploadOk == 1) {
            $stmt = $conn->prepare("UPDATE nfts SET name = ?, description = ?, price = ?, category = ?, image_url = ?, creator_id = ?, owner_id = ? WHERE id = ?");
            $stmt->bind_param("ssdssiii", $name, $description, $price, $category, $imageUrl, $creatorId, $ownerId, $nftId);
            
            if ($stmt->execute()) {
                $message = "NFT updated successfully!";
                $messageType = 'success';
                
                // Refresh NFT data
                $stmt = $conn->prepare("SELECT * FROM nfts WHERE id = ?");
                $stmt->bind_param("i", $nftId);
                $stmt->execute();
                $nft = $stmt->get_result()->fetch_assoc();
            } else {
                $message = "Error: " . $stmt->error;
                $messageType = 'danger';
            }
        }
    }
}

// Get available categories
$categories = ['Art', 'Music', 'Photography', 'Sports', 'Collectibles', 'Virtual Worlds', 'Trading Cards', 'Utility', 'Domain Names'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit NFT - Admin Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <style>
        .form-container {
            max-width: 800px;
            margin: 0 auto;
        }
        .image-preview {
            width: 100%;
            height: 300px;
            border: 2px dashed #ddd;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 20px;
            overflow: hidden;
        }
        .image-preview img {
            max-width: 100%;
            max-height: 100%;
        }
        @media (max-width: 768px) {
            .image-preview {
                height: 200px;
            }
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <?php include 'includes/sidebar.php'; ?>
            
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Edit NFT</h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <div class="btn-group me-2">
                            <a href="manage_nfts.php" class="btn btn-sm btn-outline-secondary">Back to NFTs</a>
                        </div>
                    </div>
                </div>
                
                <?php if (!empty($message)): ?>
                    <div class="alert alert-<?php echo $messageType; ?> alert-dismissible fade show" role="alert">
                        <?php echo $message; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>
                
                <div class="card mb-4">
                    <div class="card-header">
                        <i class="fas fa-edit me-1"></i>
                        Edit NFT: <?php echo htmlspecialchars($nft['name']); ?>
                    </div>
                    <div class="card-body">
                        <div class="form-container">
                            <form method="POST" enctype="multipart/form-data">
                                <div class="mb-3">
                                    <label for="name" class="form-label">NFT Name</label>
                                    <input type="text" class="form-control" id="name" name="name" value="<?php echo htmlspecialchars($nft['name']); ?>" required>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="description" class="form-label">Description</label>
                                    <textarea class="form-control" id="description" name="description" rows="4" required><?php echo htmlspecialchars($nft['description']); ?></textarea>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="price" class="form-label">Price (ETH)</label>
                                    <input type="number" class="form-control" id="price" name="price" step="0.001" min="0.001" value="<?php echo $nft['price']; ?>" required>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="category" class="form-label">Category</label>
                                    <select class="form-select" id="category" name="category" required>
                                        <option value="">Select a category</option>
                                        <?php foreach ($categories as $category): ?>
                                            <option value="<?php echo $category; ?>" <?php echo ($nft['category'] == $category) ? 'selected' : ''; ?>><?php echo $category; ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="creator_id" class="form-label">Creator</label>
                                    <select class="form-select" id="creator_id" name="creator_id" required>
                                        <option value="">Select a creator</option>
                                        <?php foreach ($users as $user): ?>
                                            <option value="<?php echo $user['id']; ?>" <?php echo ($nft['creator_id'] == $user['id']) ? 'selected' : ''; ?>><?php echo htmlspecialchars($user['username'] . ' (' . $user['first_name'] . ' ' . $user['last_name'] . ')'); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="owner_id" class="form-label">Owner</label>
                                    <select class="form-select" id="owner_id" name="owner_id" required>
                                        <option value="">Select an owner</option>
                                        <?php foreach ($users as $user): ?>
                                            <option value="<?php echo $user['id']; ?>" <?php echo ($nft['owner_id'] == $user['id']) ? 'selected' : ''; ?>><?php echo htmlspecialchars($user['username'] . ' (' . $user['first_name'] . ' ' . $user['last_name'] . ')'); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="nft_image" class="form-label">NFT Image</label>
                                    <div class="image-preview" id="imagePreview">
                                        <?php if (!empty($nft['image_url'])): ?>
                                            <img src="<?php echo '../' . htmlspecialchars($nft['image_url']); ?>" alt="Current NFT Image" class="preview-img" style="display: block;">
                                        <?php else: ?>
                                            <span class="image-preview-text">No Image</span>
                                        <?php endif; ?>
                                    </div>
                                    <input class="form-control" type="file" id="nft_image" name="nft_image" accept="image/*">
                                    <div class="form-text">Leave empty to keep the current image.</div>
                                </div>
                                
                                <div class="d-grid gap-2">
                                    <button type="submit" class="btn btn-primary">Update NFT</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const imageInput = document.getElementById('nft_image');
            const imagePreview = document.getElementById('imagePreview');
            const previewImg = imagePreview.querySelector('.preview-img');
            
            imageInput.addEventListener('change', function() {
                const file = this.files[0];
                
                if (file) {
                    const reader = new FileReader();
                    
                    if (!previewImg) {
                        // If preview image doesn't exist, create it
                        const newPreviewImg = document.createElement('img');
                        newPreviewImg.classList.add('preview-img');
                        newPreviewImg.style.display = 'block';
                        
                        // Remove any existing content
                        imagePreview.innerHTML = '';
                        imagePreview.appendChild(newPreviewImg);
                        
                        reader.addEventListener("load", function() {
                            newPreviewImg.setAttribute("src", this.result);
                        });
                    } else {
                        // If preview image exists, update it
                        previewImg.style.display = 'block';
                        
                        // Remove any text nodes
                        const textNodes = imagePreview.querySelectorAll('.image-preview-text');
                        textNodes.forEach(node => node.remove());
                        
                        reader.addEventListener("load", function() {
                            previewImg.setAttribute("src", this.result);
                        });
                    }
                    
                    reader.readAsDataURL(file);
                }
            });
        });
    </script>
</body>
</html>
