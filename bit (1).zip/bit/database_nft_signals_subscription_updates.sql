-- NFT Tables
CREATE TABLE IF NOT EXISTS `nft_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `nft_categories` (`name`) VALUES
('Arts'),
('Collectibles'),
('Music'),
('Photography'),
('Sports'),
('Virtual Worlds');

CREATE TABLE IF NOT EXISTS `nfts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text,
  `price` decimal(18,8) NOT NULL,
  `image` varchar(255) NOT NULL,
  `category_id` int(11) NOT NULL,
  `creator_id` int(11) NOT NULL,
  `owner_id` int(11) NOT NULL,
  `token_id` varchar(255) NOT NULL,
  `status` enum('active','sold','inactive') NOT NULL DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `category_id` (`category_id`),
  KEY `creator_id` (`creator_id`),
  KEY `owner_id` (`owner_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `nft_bids` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nft_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `bid_amount` decimal(18,8) NOT NULL,
  `status` enum('pending','accepted','rejected','cancelled') NOT NULL DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `nft_id` (`nft_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `nft_transactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nft_id` int(11) NOT NULL,
  `seller_id` int(11) NOT NULL,
  `buyer_id` int(11) NOT NULL,
  `transaction_type` enum('sale','auction') NOT NULL,
  `amount` decimal(18,8) NOT NULL,
  `transaction_hash` varchar(255) DEFAULT NULL,
  `status` enum('pending','completed','failed') NOT NULL DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `nft_id` (`nft_id`),
  KEY `seller_id` (`seller_id`),
  KEY `buyer_id` (`buyer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Subscription Plans Tables
CREATE TABLE IF NOT EXISTS `subscription_plans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text,
  `roi_percentage` decimal(5,2) NOT NULL,
  `roi_period` enum('daily','weekly','monthly') NOT NULL DEFAULT 'daily',
  `min_amount` decimal(18,2) NOT NULL,
  `max_amount` decimal(18,2) NOT NULL,
  `duration_days` int(11) NOT NULL,
  `is_popular` tinyint(1) NOT NULL DEFAULT '0',
  `is_vip` tinyint(1) NOT NULL DEFAULT '0',
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `subscription_plans` (`name`, `description`, `roi_percentage`, `roi_period`, `min_amount`, `max_amount`, `duration_days`, `is_popular`, `is_vip`, `status`) VALUES
('Starter Plan', 'Popular starter investment plan', 7.00, 'daily', 50.00, 500.00, 7, 1, 0, 'active'),
('Basic Plan', 'Regular investment plan', 13.00, 'daily', 500.00, 2000.00, 14, 0, 0, 'active'),
('Premium Plan', 'Premium investment plan with VIP benefits', 35.00, 'daily', 5000.00, 10000.00, 30, 0, 1, 'active'),
('Elite Plan', 'Elite investment plan with VIP benefits', 55.00, 'daily', 10000.00, 1000000.00, 45, 0, 1, 'active');

CREATE TABLE IF NOT EXISTS `user_subscriptions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `plan_id` int(11) NOT NULL,
  `amount` decimal(18,2) NOT NULL,
  `status` enum('active','completed','cancelled','paused') NOT NULL DEFAULT 'active',
  `start_date` datetime NOT NULL,
  `end_date` datetime NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `plan_id` (`plan_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `subscription_earnings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `subscription_id` int(11) NOT NULL,
  `amount` decimal(18,2) NOT NULL,
  `date` date NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `subscription_id` (`subscription_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Signal Plans Tables
CREATE TABLE IF NOT EXISTS `signal_plans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text,
  `price` decimal(18,2) NOT NULL,
  `duration_days` int(11) NOT NULL,
  `features` text,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `signal_plans` (`name`, `description`, `price`, `duration_days`, `features`, `status`) VALUES
('Alpha Signals', 'Entry level signal plan', 99.00, 30, 'Signal General Trading Signal,High accuracy signals with risk control tools,Expert support 24/7 Priority support', 'active'),
('Titan Signals', 'Mid-tier signal plan', 149.00, 60, 'Signal General Trading Signal,Advanced technical analysis tools,Expert support 24/7 Priority support', 'active'),
('Quantum Edge Signals', 'Advanced signal plan', 199.00, 90, 'Signal General Trading Signal,AI-driven signals with deep market insights,Expert support 24/7 Priority support', 'active'),
('Elite Trader Signals', 'Premium signal plan', 249.00, 90, 'Signal General Trading Signal,Institutional-grade signals for experienced traders,Expert support 24/7 Priority support', 'active'),
('Velocity Pro Signals', 'Professional signal plan', 299.00, 90, 'Signal General Trading Signal,Real-time signals with high win rate,Expert support 24/7 Priority support', 'active'),
('Apex Master Signals', 'Master level signal plan', 399.00, 90, 'Signal General Trading Signal,Ultra-precision forex and crypto signals,Expert support 24/7 Priority support', 'active'),
('Genesis Prime Signals', 'Prime signal plan', 499.00, 90, 'Signal General Trading Signal,High-accuracy signals with low-risk trading strategies,Expert support 24/7 Priority support', 'active'),
('Legendary Investor Plan', 'Ultimate signal plan', 999.00, 90, 'Signal General Trading Signal,Ultimate membership: All premium signals, proprietary indicators, mentoring, AI-powered insights & personalization,Expert support 24/7 Priority support', 'active');

CREATE TABLE IF NOT EXISTS `user_signal_subscriptions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `plan_id` int(11) NOT NULL,
  `status` enum('active','expired','cancelled') NOT NULL DEFAULT 'active',
  `start_date` datetime NOT NULL,
  `end_date` datetime NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `plan_id` (`plan_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `trading_signals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text,
  `asset` varchar(50) NOT NULL,
  `direction` enum('buy','sell') NOT NULL,
  `entry_price` decimal(18,8) NOT NULL,
  `stop_loss` decimal(18,8) NOT NULL,
  `take_profit` decimal(18,8) NOT NULL,
  `min_plan_id` int(11) NOT NULL,
  `status` enum('active','expired','cancelled') NOT NULL DEFAULT 'active',
  `result` enum('pending','win','loss','cancelled') NOT NULL DEFAULT 'pending',
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `min_plan_id` (`min_plan_id`),
  KEY `created_by` (`created_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Update sidebar menu
ALTER TABLE `user_settings` ADD `show_nft` tinyint(1) NOT NULL DEFAULT '1' AFTER `show_copy_trade`;
ALTER TABLE `user_settings` ADD `show_signals` tinyint(1) NOT NULL DEFAULT '1' AFTER `show_nft`;
