<?php
session_start();
require_once '../config/config.php';
require_once '../includes/auth_check.php';
require_once '../includes/functions.php';

// Check if user is admin
requireAdmin();
requireOTPVerification();

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: manage_users.php");
    exit();
}

$userId = $_POST['user_id'] ?? 0;
$accountId = $_POST['account_id'] ?? 0;
$symbol = $_POST['symbol'] ?? '';
$tradeType = $_POST['trade_type'] ?? '';
$openPrice = $_POST['open_price'] ?? 0;
$closePrice = $_POST['close_price'] ?? 0;
$volume = $_POST['volume'] ?? 0;
$profit = $_POST['profit'] ?? 0;
$tradeDate = $_POST['trade_date'] ?? date('Y-m-d H:i:s');

// Validate input
if (empty($userId) || empty($accountId) || empty($symbol) || empty($tradeType) || empty($openPrice) || empty($closePrice) || empty($volume) || empty($tradeDate)) {
    $_SESSION['error'] = "All fields are required";
    header("Location: user_details.php?id=" . $userId);
    exit();
}

// Insert trade history
$stmt = $conn->prepare("INSERT INTO trade_history (user_id, account_id, symbol, type, open_price, close_price, volume, profit, trade_date, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())");
$stmt->bind_param("iissddds", $userId, $accountId, $symbol, $tradeType, $openPrice, $closePrice, $volume, $profit, $tradeDate);

if ($stmt->execute()) {
    // Update user balance if profit/loss
    if ($profit != 0) {
        $stmt = $conn->prepare("UPDATE users SET balance = balance + ? WHERE id = ?");
        $stmt->bind_param("di", $profit, $userId);
        $stmt->execute();
    }
    
    $_SESSION['success'] = "Trading history added successfully";
} else {
    $_SESSION['error'] = "Failed to add trading history";
}

// Redirect back to user details
header("Location: user_details.php?id=" . $userId);
exit();
?>
