<?php
session_start();
require_once '../config/config.php';
require_once '../includes/auth_check.php';
require_once '../includes/functions.php';

// Check if user is admin
requireAdmin();
requireOTPVerification();

// Check if user ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: manage_users.php");
    exit();
}

$userId = $_GET['id'];

// Get user data
$user = getUserById($userId);

if (!$user) {
    header("Location: manage_users.php");
    exit();
}

// Store admin session for later
$_SESSION['admin_id'] = $_SESSION['user_id'];
$_SESSION['admin_email'] = $_SESSION['user_email'];
$_SESSION['admin_role'] = $_SESSION['user_role'];

// Set user session
$_SESSION['user_id'] = $user['id'];
$_SESSION['user_email'] = $user['email'];
$_SESSION['user_role'] = $user['role'];
$_SESSION['otp_verified'] = true; // Skip OTP verification
$_SESSION['admin_login'] = true; // Flag to indicate admin is logged in as user

// Redirect to user dashboard
header("Location: ../user/dashboard.php");
exit();
?>
