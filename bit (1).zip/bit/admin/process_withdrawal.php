<?php
session_start();
require_once '../config/config.php';
require_once '../includes/functions.php';
require_once '../includes/admin_auth_check.php';

if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: withdrawals.php");
    exit();
}

$withdrawalId = $_GET['id'];
$action = $_GET['action'] ?? '';

if ($action !== 'approve' && $action !== 'reject') {
    header("Location: withdrawals.php");
    exit();
}

// Get withdrawal information
$stmt = $conn->prepare("SELECT w.*, u.id as user_id, u.full_name, u.email, u.balance FROM withdrawals w JOIN users u ON w.user_id = u.id WHERE w.id = ?");
$stmt->bind_param("i", $withdrawalId);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows !== 1) {
    header("Location: withdrawals.php");
    exit();
}

$withdrawal = $result->fetch_assoc();

// Check if withdrawal is already processed
if ($withdrawal['status'] !== 'pending') {
    $_SESSION['error'] = "This withdrawal has already been processed.";
    header("Location: withdrawals.php");
    exit();
}

// Process the withdrawal
if ($action === 'approve') {
    // Start transaction
    $conn->begin_transaction();
    
    try {
        // Update withdrawal status
        $stmt = $conn->prepare("UPDATE withdrawals SET status = 'processed', processed_at = NOW(), processed_by = ? WHERE id = ?");
        $stmt->bind_param("ii", $_SESSION['user_id'], $withdrawalId);
        $stmt->execute();
        
        // Add transaction record
        $stmt = $conn->prepare("INSERT INTO transactions (user_id, type, amount, description, created_at) VALUES (?, 'withdrawal', ?, 'Withdrawal via " . $withdrawal['payment_method'] . "', NOW())");
        $stmt->bind_param("id", $withdrawal['user_id'], $withdrawal['amount']);
        $stmt->execute();
        
        // Commit transaction
        $conn->commit();
        
        // Update withdrawal status for email notification
        $withdrawal['status'] = 'processed';
        
        // Send withdrawal notification email
        $user = [
            'full_name' => $withdrawal['full_name'],
            'email' => $withdrawal['email']
        ];
        sendWithdrawalNotification($user, $withdrawal);
        
        $_SESSION['success'] = "Withdrawal approved successfully.";
    } catch (Exception $e) {
        // Rollback transaction on error
        $conn->rollback();
        $_SESSION['error'] = "Failed to approve withdrawal: " . $e->getMessage();
    }
} else if ($action === 'reject') {
    // Start transaction
    $conn->begin_transaction();
    
    try {
        // Update withdrawal status
        $stmt = $conn->prepare("UPDATE withdrawals SET status = 'rejected', processed_at = NOW(), processed_by = ? WHERE id = ?");
        $stmt->bind_param("ii", $_SESSION['user_id'], $withdrawalId);
        $stmt->execute();
        
        // Refund the amount to user's balance
        $newBalance = $withdrawal['balance'] + $withdrawal['amount'];
        $stmt = $conn->prepare("UPDATE users SET balance = ? WHERE id = ?");
        $stmt->bind_param("di", $newBalance, $withdrawal['user_id']);
        $stmt->execute();
        
        // Add transaction record
        $stmt = $conn->prepare("INSERT INTO transactions (user_id, type, amount, description, created_at) VALUES (?, 'refund', ?, 'Refund for rejected withdrawal', NOW())");
        $stmt->bind_param("id", $withdrawal['user_id'], $withdrawal['amount']);
        $stmt->execute();
        
        // Commit transaction
        $conn->commit();
        
        // Update withdrawal status for email notification
        $withdrawal['status'] = 'rejected';
        
        // Send withdrawal notification email
        $user = [
            'full_name' => $withdrawal['full_name'],
            'email' => $withdrawal['email']
        ];
        sendWithdrawalNotification($user, $withdrawal);
        
        $_SESSION['success'] = "Withdrawal rejected and funds refunded successfully.";
    } catch (Exception $e) {
        // Rollback transaction on error
        $conn->rollback();
        $_SESSION['error'] = "Failed to reject withdrawal: " . $e->getMessage();
    }
}

header("Location: withdrawals.php");
exit();
?>
