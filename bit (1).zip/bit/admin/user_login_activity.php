<?php
session_start();
require_once '../config/config.php';
require_once '../includes/auth_check.php';
require_once '../includes/functions.php';

// Check if user is admin
requireAdmin();
requireOTPVerification();

// Check if user ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: manage_users.php");
    exit();
}

$userId = $_GET['id'];

// Get user data
$user = getUserById($userId);

if (!$user) {
    header("Location: manage_users.php");
    exit();
}

// Get login activity
$stmt = $conn->prepare("SELECT * FROM login_activity WHERE user_id = ? ORDER BY login_time DESC");
$stmt->bind_param("i", $userId);
$stmt->execute();
$loginActivity = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Activity - <?php echo APP_NAME; ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <?php include 'includes/sidebar.php'; ?>
            
            <!-- Main Content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Login Activity for <?php echo $user['first_name'] . ' ' . $user['last_name']; ?></h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <a href="user_details.php?id=<?php echo $userId; ?>" class="btn btn-sm btn-outline-secondary">
                            <i class="fas fa-arrow-left"></i> Back to User Details
                        </a>
                    </div>
                </div>
                
                <div class="card">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th>Login Time</th>
                                        <th>IP Address</th>
                                        <th>Device</th>
                                        <th>Browser</th>
                                        <th>Location</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (empty($loginActivity)): ?>
                                    <tr>
                                        <td colspan="6" class="text-center">No login activity found</td>
                                    </tr>
                                    <?php else: ?>
                                    <?php foreach ($loginActivity as $activity): ?>
                                    <tr>
                                        <td><?php echo date('D, M j, Y g:i A', strtotime($activity['login_time'])); ?></td>
                                        <td><?php echo $activity['ip_address']; ?></td>
                                        <td><?php echo $activity['device']; ?></td>
                                        <td><?php echo $activity['browser']; ?></td>
                                        <td><?php echo $activity['location']; ?></td>
                                        <td>
                                            <span class="badge bg-<?php echo $activity['status'] === 'success' ? 'success' : 'danger'; ?>">
                                                <?php echo ucfirst($activity['status']); ?>
                                            </span>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
