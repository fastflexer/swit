<?php
require_once '../config/config.php';
require_once '../includes/auth_check.php';
require_once '../includes/admin_check.php';
require_once '../includes/functions.php';

// Check if NFT ID is provided
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header('Location: manage_nfts.php');
    exit;
}

$nftId = intval($_GET['id']);

// Get NFT details
$stmt = $conn->prepare("SELECT n.*, u1.username as creator_username, u1.first_name as creator_first_name, u1.last_name as creator_last_name, u2.username as owner_username, u2.first_name as owner_first_name, u2.last_name as owner_last_name FROM nfts n JOIN users u1 ON n.creator_id = u1.id JOIN users u2 ON n.owner_id = u2.id WHERE n.id = ?");
$stmt->bind_param("i", $nftId);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    header('Location: manage_nfts.php');
    exit;
}

$nft = $result->fetch_assoc();

// Get NFT transaction history
$stmt = $conn->prepare("SELECT t.*, u1.username as seller_username, u2.username as buyer_username FROM nft_transactions t JOIN users u1 ON t.seller_id = u1.id JOIN users u2 ON t.buyer_id = u2.id WHERE t.nft_id = ? ORDER BY t.created_at DESC");
$stmt->bind_param("i", $nftId);
$stmt->execute();
$transactions = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Get NFT bid history
$stmt = $conn->prepare("SELECT b.*, u.username FROM nft_bids b JOIN users u ON b.user_id = u.id WHERE b.nft_id = ? ORDER BY b.amount DESC, b.created_at DESC");
$stmt->bind_param("i", $nftId);
$stmt->execute();
$bids = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NFT Details - Admin Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <style>
        .nft-image {
            max-width: 100%;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .detail-section {
            margin-bottom: 30px;
        }
        .table-responsive {
            margin-top: 20px;
        }
        @media (max-width: 768px) {
            .nft-details-container {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <?php include 'includes/sidebar.php'; ?>
            
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">NFT Details</h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <div class="btn-group me-2">
                            <a href="manage_nfts.php" class="btn btn-sm btn-outline-secondary">Back to NFTs</a>
                            <a href="edit_nft.php?id=<?php echo $nftId; ?>" class="btn btn-sm btn-primary">Edit NFT</a>
                        </div>
                    </div>
                </div>
                
                <div class="card mb-4">
                    <div class="card-header">
                        <i class="fas fa-info-circle me-1"></i>
                        NFT: <?php echo htmlspecialchars($nft['name']); ?>
                    </div>
                    <div class="card-body">
                        <div class="row nft-details-container">
                            <div class="col-md-4 mb-4">
                                <img src="<?php echo '../' . htmlspecialchars($nft['image_url']); ?>" class="nft-image" alt="<?php echo htmlspecialchars($nft['name']); ?>">
                            </div>
                            
                            <div class="col-md-8">
                                <div class="detail-section">
                                    <h3><?php echo htmlspecialchars($nft['name']); ?></h3>
                                    <p class="text-muted">Category: <?php echo htmlspecialchars($nft['category']); ?></p>
                                    
                                    <h5>Description</h5>
                                    <p><?php echo nl2br(htmlspecialchars($nft['description'])); ?></p>
                                </div>
                                
                                <div class="detail-section">
                                    <h5>Details</h5>
                                    <table class="table table-bordered">
                                        <tr>
                                            <th>ID</th>
                                            <td><?php echo $nft['id']; ?></td>
                                        </tr>
                                        <tr>
                                            <th>Price</th>
                                            <td><?php echo $nft['price']; ?> ETH</td>
                                        </tr>
                                        <tr>
                                            <th>Creator</th>
                                            <td><?php echo htmlspecialchars($nft['creator_first_name'] . ' ' . $nft['creator_last_name'] . ' (@' . $nft['creator_username'] . ')'); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Owner</th>
                                            <td><?php echo htmlspecialchars($nft['owner_first_name'] . ' ' . $nft['owner_last_name'] . ' (@' . $nft['owner_username'] . ')'); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Created</th>
                                            <td><?php echo date('F j, Y H:i:s', strtotime($nft['created_at'])); ?></td>
                                        </tr>
                                        <?php if ($nft['last_sold_at']): ?>
                                            <tr>
                                                <th>Last Sold</th>
                                                <td><?php echo date('F j, Y H:i:s', strtotime($nft['last_sold_at'])); ?> for <?php echo $nft['last_sold_price']; ?> ETH</td>
                                            </tr>
                                        <?php endif; ?>
                                    </table>
                                </div>
                            </div>
                        </div>
                        
                        <div class="row mt-4">
                            <div class="col-md-6">
                                <div class="card">
                                    <div class="card-header">
                                        <h5 class="mb-0">Transaction History</h5>
                                    </div>
                                    <div class="card-body">
                                        <?php if (empty($transactions)): ?>
                                            <p class="text-muted">No transactions yet.</p>
                                        <?php else: ?>
                                            <div class="table-responsive">
                                                <table class="table table-striped table-hover">
                                                    <thead>
                                                        <tr>
                                                            <th>Date</th>
                                                            <th>Seller</th>
                                                            <th>Buyer</th>
                                                            <th>Price (ETH)</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php foreach ($transactions as $transaction): ?>
                                                            <tr>
                                                                <td><?php echo date('M j, Y H:i', strtotime($transaction['created_at'])); ?></td>
                                                                <td><?php echo htmlspecialchars($transaction['seller_username']); ?></td>
                                                                <td><?php echo htmlspecialchars($transaction['buyer_username']); ?></td>
                                                                <td><?php echo $transaction['price']; ?></td>
                                                            </tr>
                                                        <?php endforeach; ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-md-6">
                                <div class="card">
                                    <div class="card-header">
                                        <h5 class="mb-0">Bid History</h5>
                                    </div>
                                    <div class="card-body">
                                        <?php if (empty($bids)): ?>
                                            <p class="text-muted">No bids yet.</p>
                                        <?php else: ?>
                                            <div class="table-responsive">
                                                <table class="table table-striped table-hover">
                                                    <thead>
                                                        <tr>
                                                            <th>Date</th>
                                                            <th>Bidder</th>
                                                            <th>Amount (ETH)</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php foreach ($bids as $bid): ?>
                                                            <tr>
                                                                <td><?php echo date('M j, Y H:i', strtotime($bid['created_at'])); ?></td>
                                                                <td><?php echo htmlspecialchars($bid['username']); ?></td>
                                                                <td><?php echo $bid['amount']; ?></td>
                                                            </tr>
                                                        <?php endforeach; ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
