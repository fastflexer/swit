<?php
// Database configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'jetfxgro_admin');
define('DB_PASS', 'LT!JGMR,D^c2');
define('DB_NAME', 'jetfxgro_bit');

// Email configuration for OTP
define('MAIL_HOST', 'mail.jetfxgrowth.online');
define('MAIL_PORT', 587);
define('MAIL_USERNAME', 'bitreply@jetfxgrowth.online');
define('MAIL_PASSWORD', '10@Jetfxgrowth10@');
define('MAIL_ENCRYPTION', 'tls');
define('MAIL_FROM_ADDRESS', 'bitreply@jetfxgrowth.online');
define('MAIL_FROM_NAME', 'JetFx Growth');

// Application configuration
define('APP_NAME', 'JetFx Growth');
define('APP_URL', 'http://jetfxgrowth.online/bit');
define('APP_TIMEZONE', 'UTC');
define('OTP_EXPIRY_MINUTES', 10);

// Connect to database
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Set timezone
date_default_timezone_set(APP_TIMEZONE);
?>
