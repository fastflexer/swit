<?php
require_once 'config/config.php';
require_once 'includes/functions.php';

/**
 * Get all signal plans
 * 
 * @return array Array of signal plans
 */
function getAllSignalPlans() {
    global $conn;
    
    $stmt = $conn->prepare("SELECT * FROM signal_plans WHERE status = 'active' ORDER BY price ASC");
    $stmt->execute();
    $result = $stmt->get_result();
    
    $plans = [];
    while ($row = $result->fetch_assoc()) {
        $plans[] = $row;
    }
    
    return $plans;
}

/**
 * Get signal plan by ID
 * 
 * @param int $id Plan ID
 * @return array|null Plan data or null if not found
 */
function getSignalPlanById($id) {
    global $conn;
    
    $stmt = $conn->prepare("SELECT * FROM signal_plans WHERE id = ?");
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        return $result->fetch_assoc();
    }
    
    return null;
}

/**
 * Create a new signal plan
 * 
 * @param array $data Plan data
 * @return int|bool New plan ID or false on failure
 */
function createSignalPlan($data) {
    global $conn;
    
    $stmt = $conn->prepare("INSERT INTO signal_plans (name, description, price, duration_days, features, status, created_at) 
                           VALUES (?, ?, ?, ?, ?, 'active', NOW())");
    $stmt->bind_param('ssdis', $data['name'], $data['description'], $data['price'], $data['duration_days'], $data['features']);
    
    if ($stmt->execute()) {
        return $conn->insert_id;
    }
    
    return false;
}

/**
 * Update a signal plan
 * 
 * @param int $id Plan ID
 * @param array $data Updated plan data
 * @return bool Success or failure
 */
function updateSignalPlan($id, $data) {
    global $conn;
    
    $stmt = $conn->prepare("UPDATE signal_plans SET name = ?, description = ?, price = ?, duration_days = ?, features = ?, status = ? WHERE id = ?");
    $stmt->bind_param('ssdissi', $data['name'], $data['description'], $data['price'], $data['duration_days'], $data['features'], $data['status'], $id);
    
    return $stmt->execute();
}

/**
 * Delete a signal plan
 * 
 * @param int $id Plan ID
 * @return bool Success or failure
 */
function deleteSignalPlan($id) {
    global $conn;
    
    $stmt = $conn->prepare("DELETE FROM signal_plans WHERE id = ?");
    $stmt->bind_param('i', $id);
    
    return $stmt->execute();
}

/**
 * Subscribe user to a signal plan
 * 
 * @param int $userId User ID
 * @param int $planId Plan ID
 * @return int|bool New subscription ID or false on failure
 */
function subscribeToSignalPlan($userId, $planId) {
    global $conn;
    
    // Get plan details
    $plan = getSignalPlanById($planId);
    if (!$plan) {
        return false;
    }
    
    // Calculate end date
    $endDate = date('Y-m-d H:i:s', strtotime("+{$plan['duration_days']} days"));
    
    // Start transaction
    $conn->begin_transaction();
    
    try {
        // Check if user already has an active subscription to this plan
        $stmt = $conn->prepare("SELECT * FROM signal_subscriptions WHERE user_id = ? AND plan_id = ? AND end_date > NOW()");
        $stmt->bind_param('ii', $userId, $planId);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            // Extend existing subscription
            $subscription = $result->fetch_assoc();
            $newEndDate = date('Y-m-d H:i:s', strtotime("{$subscription['end_date']} +{$plan['duration_days']} days"));
            
            $stmt = $conn->prepare("UPDATE signal_subscriptions SET end_date = ? WHERE id = ?");
            $stmt->bind_param('si', $newEndDate, $subscription['id']);
            $stmt->execute();
            
            $subscriptionId = $subscription['id'];
        } else {
            // Create new subscription
            $stmt = $conn->prepare("INSERT INTO signal_subscriptions (user_id, plan_id, start_date, end_date, status, created_at) 
                                   VALUES (?, ?, NOW(), ?, 'active', NOW())");
            $stmt->bind_param('iis', $userId, $planId, $endDate);
            $stmt->execute();
            
            $subscriptionId = $conn->insert_id;
        }
        
        // Record payment
        $stmt = $conn->prepare("INSERT INTO payments (user_id, amount, payment_type, status, reference_id, reference_type, created_at) 
                               VALUES (?, ?, 'signal_subscription', 'completed', ?, 'signal_plan', NOW())");
        $stmt->bind_param('idi', $userId, $plan['price'], $planId);
        $stmt->execute();
        
        // Commit transaction
        $conn->commit();
        return $subscriptionId;
    } catch (Exception $e) {
        // Rollback on error
        $conn->rollback();
        return false;
    }
}

/**
 * Get user's active signal subscriptions
 * 
 * @param int $userId User ID
 * @return array Array of subscriptions
 */
function getUserActiveSignalSubscriptions($userId) {
    global $conn;
    
    $stmt = $conn->prepare("SELECT s.*, p.name as plan_name, p.description as plan_description, p.features as plan_features 
                           FROM signal_subscriptions s
                           JOIN signal_plans p ON s.plan_id = p.id
                           WHERE s.user_id = ? AND s.end_date > NOW() AND s.status = 'active'
                           ORDER BY s.end_date DESC");
    $stmt->bind_param('i', $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $subscriptions = [];
    while ($row = $result->fetch_assoc()) {
        $subscriptions[] = $row;
    }
    
    return $subscriptions;
}

/**
 * Get user's signal subscription history
 * 
 * @param int $userId User ID
 * @return array Array of subscriptions
 */
function getUserSignalSubscriptionHistory($userId) {
    global $conn;
    
    $stmt = $conn->prepare("SELECT s.*, p.name as plan_name, p.description as plan_description, p.features as plan_features 
                           FROM signal_subscriptions s
                           JOIN signal_plans p ON s.plan_id = p.id
                           WHERE s.user_id = ?
                           ORDER BY s.created_at DESC");
    $stmt->bind_param('i', $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $subscriptions = [];
    while ($row = $result->fetch_assoc()) {
        $subscriptions[] = $row;
    }
    
    return $subscriptions;
}

/**
 * Check if user has active signal subscription
 * 
 * @param int $userId User ID
 * @return bool True if user has active subscription, false otherwise
 */
function hasActiveSignalSubscription($userId) {
    global $conn;
    
    $stmt = $conn->prepare("SELECT COUNT(*) as count FROM signal_subscriptions 
                           WHERE user_id = ? AND end_date > NOW() AND status = 'active'");
    $stmt->bind_param('i', $userId);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    
    return $result['count'] > 0;
}

/**
 * Get all signals
 * 
 * @param int $limit Optional limit
 * @param int $offset Optional offset
 * @return array Array of signals
 */
function getAllSignals($limit = null, $offset = null) {
    global $conn;
    
    $sql = "SELECT * FROM signals WHERE status = 'active' ORDER BY created_at DESC";
    
    if ($limit !== null) {
        $sql .= " LIMIT ?";
        if ($offset !== null) {
            $sql .= " OFFSET ?";
        }
    }
    
    $stmt = $conn->prepare($sql);
    
    if ($limit !== null) {
        if ($offset !== null) {
            $stmt->bind_param('ii', $limit, $offset);
        } else {
            $stmt->bind_param('i', $limit);
        }
    }
    
    $stmt->execute();
    $result = $stmt->get_result();
    
    $signals = [];
    while ($row = $result->fetch_assoc()) {
        $signals[] = $row;
    }
    
    return $signals;
}

/**
 * Create a new signal
 * 
 * @param array $data Signal data
 * @return int|bool New signal ID or false on failure
 */
function createSignal($data) {
    global $conn;
    
    $stmt = $conn->prepare("INSERT INTO signals (title, content, asset, entry_price, target_price, stop_loss, time_frame, status, created_at) 
                           VALUES (?, ?, ?, ?, ?, ?, ?, 'active', NOW())");
    $stmt->bind_param('sssddds', $data['title'], $data['content'], $data['asset'], $data['entry_price'], $data['target_price'], $data['stop_loss'], $data['time_frame']);
    
    if ($stmt->execute()) {
        return $conn->insert_id;
    }
    
    return false;
}

/**
 * Update a signal
 * 
 * @param int $id Signal ID
 * @param array $data Updated signal data
 * @return bool Success or failure
 */
function updateSignal($id, $data) {
    global $conn;
    
    $stmt = $conn->prepare("UPDATE signals SET title = ?, content = ?, asset = ?, entry_price = ?, target_price = ?, stop_loss = ?, time_frame = ?, status = ? WHERE id = ?");
    $stmt->bind_param('sssdddssi', $data['title'], $data['content'], $data['asset'], $data['entry_price'], $data['target_price'], $data['stop_loss'], $data['time_frame'], $data['status'], $id);
    
    return $stmt->execute();
}

/**
 * Delete a signal
 * 
 * @param int $id Signal ID
 * @return bool Success or failure
 */
function deleteSignal($id) {
    global $conn;
    
    $stmt = $conn->prepare("DELETE FROM signals WHERE id = ?");
    $stmt->bind_param('i', $id);
    
    return $stmt->execute();
}

/**
 * Get signal by ID
 * 
 * @param int $id Signal ID
 * @return array|null Signal data or null if not found
 */
function getSignalById($id) {
    global $conn;
    
    $stmt = $conn->prepare("SELECT * FROM signals WHERE id = ?");
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        return $result->fetch_assoc();
    }
    
    return null;
}
?>
